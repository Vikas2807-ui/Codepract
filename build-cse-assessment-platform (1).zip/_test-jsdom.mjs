import { JSDOM, VirtualConsole } from 'jsdom';
import { readFileSync } from 'fs';

let html = readFileSync('./dist/index.html', 'utf8');
// extract inline module script
const m = html.match(/<script[^>]*type="module"[^>]*>([\s\S]*?)<\/script>/i);
const scriptCode = m ? m[1] : '';
// remove the script + style from html
html = html.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, '');

const vc = new VirtualConsole();
vc.on('error', () => {}); vc.on('warn', () => {});
const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true, url: 'http://localhost/', virtualConsole: vc });
const { window } = dom;
window.matchMedia = () => ({ matches: false, addListener(){}, removeListener(){}, addEventListener(){}, removeEventListener(){} });
window.scrollTo = () => {};
const errors = [];
try {
  window.eval(scriptCode);
} catch (e) { errors.push('EVAL: ' + (e.stack||e.message)); }

await new Promise((r) => setTimeout(r, 1200));
const txt = () => window.document.body.textContent || '';
const buttons = () => [...window.document.querySelectorAll('button')];
const click = (el) => el && el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
const log = [];
log.push('scriptCode length: ' + scriptCode.length);
log.push('1. mounted: ' + txt().includes('CSE Career Test'));
click(buttons().find((x) => x.textContent.includes('Start MCQ Test')));
await new Promise((r) => setTimeout(r, 400));
log.push('2. setup shown: ' + txt().includes('Choose Assessment'));
click(buttons().find((x) => x.textContent.trim().startsWith('Start Test')));
await new Promise((r) => setTimeout(r, 700));
log.push('3. quiz Q1 shown: ' + txt().includes('Question 1'));
const radios = () => [...window.document.querySelectorAll('[role=radio]')];
log.push('4. radio count: ' + radios().length);
log.push('5. radio0 checked before: ' + radios()[0]?.getAttribute('aria-checked'));
click(radios()[0]);
await new Promise((r) => setTimeout(r, 300));
log.push('6. radio0 checked AFTER: ' + radios()[0]?.getAttribute('aria-checked'));
log.push('7. "1 answered": ' + /1 answered/.test(txt()));
const nb = buttons().find((x) => x.textContent.trim().startsWith('Next'));
log.push('8. Next disabled=' + nb?.disabled);
click(nb);
await new Promise((r) => setTimeout(r, 300));
log.push('9. Q2 shown: ' + txt().includes('Question 2'));
log.push('ERRORS: ' + (errors.length ? errors.slice(0,2).join(' || ') : 'none'));
console.log('=== RESULT ===\n' + log.join('\n'));
