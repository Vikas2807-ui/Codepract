import { useRef, useEffect, useState } from "react";

export function CodeEditor({
  value,
  onChange,
  language,
  readOnly = false,
}: {
  value: string;
  onChange?: (v: string) => void;
  language?: string;
  readOnly?: boolean;
}) {
  const taRef = useRef<HTMLTextAreaElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);
  const [lineCount, setLineCount] = useState(1);

  useEffect(() => {
    setLineCount(Math.max(1, value.split("\n").length));
  }, [value]);

  const syncScroll = () => {
    if (gutterRef.current && taRef.current) {
      gutterRef.current.scrollTop = taRef.current.scrollTop;
    }
  };

  const handleKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (readOnly) return;
    const ta = e.currentTarget;
    if (e.key === "Tab") {
      e.preventDefault();
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const newVal = value.substring(0, start) + "    " + value.substring(end);
      onChange?.(newVal);
      requestAnimationFrame(() => {
        ta.selectionStart = ta.selectionEnd = start + 4;
      });
    }
    // auto-indent on Enter (keep previous line indentation)
    if (e.key === "Enter") {
      const start = ta.selectionStart;
      const before = value.substring(0, start);
      const lineStart = before.lastIndexOf("\n") + 1;
      const currentLine = before.substring(lineStart);
      const indentMatch = currentLine.match(/^(\s*)/);
      let indent = indentMatch ? indentMatch[1] : "";
      // extra indent after block openers
      if (/[:{(]\s*$/.test(currentLine.trimEnd()) || currentLine.trimEnd().endsWith("{")) {
        indent += "    ";
      }
      if (indent) {
        e.preventDefault();
        const newVal = value.substring(0, start) + "\n" + indent + value.substring(ta.selectionEnd);
        onChange?.(newVal);
        requestAnimationFrame(() => {
          ta.selectionStart = ta.selectionEnd = start + 1 + indent.length;
        });
      }
    }
  };

  return (
    <div className="relative flex overflow-hidden rounded-xl border border-slate-700 bg-[#0d1117] font-mono text-[13px] leading-6">
      <div className="flex items-center justify-between border-b border-slate-700 bg-[#161b22] px-3 py-1.5 absolute inset-x-0 top-0 z-10">
        <span className="text-xs font-semibold text-slate-400">{language || "code"}</span>
        <span className="text-[10px] uppercase tracking-wider text-slate-500">{readOnly ? "read only" : "editor"}</span>
      </div>
      <div
        ref={gutterRef}
        className="select-none overflow-hidden pt-11 pb-3 pl-3 pr-2 text-right text-slate-600"
        aria-hidden
      >
        {Array.from({ length: lineCount }, (_, i) => (
          <div key={i}>{i + 1}</div>
        ))}
      </div>
      <textarea
        ref={taRef}
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        onKeyDown={handleKey}
        onScroll={syncScroll}
        readOnly={readOnly}
        spellCheck={false}
        autoCapitalize="off"
        autoCorrect="off"
        aria-label="Code editor"
        className="min-h-[300px] flex-1 resize-y bg-transparent pt-11 pb-3 pr-3 text-slate-100 caret-indigo-400 outline-none placeholder:text-slate-600"
        style={{ tabSize: 4 }}
      />
    </div>
  );
}
