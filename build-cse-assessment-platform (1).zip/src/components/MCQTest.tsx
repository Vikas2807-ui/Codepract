import { useEffect, useMemo, useRef, useState } from "react";
import { useApp } from "../context/AppContext";
import { Button, Card, DifficultyBadge } from "./ui";
import { cn } from "../utils/cn";
import type { MCQQuestion, MCQAnswerState, TestConfig } from "../data/types";
import { buildMCQTest } from "../lib/engine";
import { buildMCQResult } from "../lib/results";
import { useCountdown, formatTime } from "../hooks/useCountdown";
import { saveResult, saveActiveTest, loadActiveTest, clearActiveTest } from "../lib/storage";
import { Toasts, useToasts } from "./Toasts";

interface Persisted {
  kind: "mcq";
  runId: string;
  config: TestConfig;
  questions: MCQQuestion[];
  answers: MCQAnswerState[];
  current: number;
  timeLeft: number;
}

function readConfig(): TestConfig | null {
  try {
    const raw = sessionStorage.getItem("csect_run_config");
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function readRunId(): string {
  return sessionStorage.getItem("csect_run_id") || "";
}

export function MCQTest() {
  const { navigate, setLastResult, setReviewData, refreshResults, setPractiCtx } = useApp();
  const { toasts, push } = useToasts();
  const config = useMemo(() => readConfig(), []);
  const runId = useMemo(() => readRunId(), []);

  const [questions, setQuestions] = useState<MCQQuestion[]>([]);
  const [answers, setAnswers] = useState<MCQAnswerState[]>([]);
  const [current, setCurrent] = useState(0);
  const [showPalette, setShowPalette] = useState(false);
  const [confirmSubmit, setConfirmSubmit] = useState(false);
  const [initialTime, setInitialTime] = useState(0);
  const submittedRef = useRef(false);

  // Build or restore the test
  useEffect(() => {
    if (!config) {
      navigate("home");
      return;
    }
    // Restore ONLY when the saved in-progress test belongs to THIS run (same
    // runId). A deliberate "Start Test" always creates a new runId, so a
    // leftover/unfinished previous test is never restored — you get brand-new
    // questions. On an accidental page refresh the runId (in sessionStorage)
    // is unchanged, so the matching saved test is restored.
    const saved = loadActiveTest<Persisted>();
    const validSaved =
      !!runId &&
      !!saved &&
      saved.runId === runId &&
      saved.kind === "mcq" &&
      JSON.stringify(saved.config) === JSON.stringify(config) &&
      Array.isArray(saved.questions) &&
      saved.questions.length > 0 &&
      Array.isArray(saved.answers) &&
      saved.answers.length === saved.questions.length &&
      typeof saved.current === "number" &&
      saved.current >= 0 &&
      saved.current < saved.questions.length &&
      saved.questions.every(
        (qq) => qq && Array.isArray(qq.options) && qq.options.length > 0 && typeof qq.correctIndex === "number"
      );

    if (validSaved) {
      setQuestions(saved.questions);
      setAnswers(saved.answers);
      setCurrent(Math.min(saved.current, saved.questions.length - 1));
      setInitialTime(saved.timeLeft);
      push("Restored your in-progress test.", "info");
    } else {
      // Discard any stale/corrupted saved state before building fresh.
      clearActiveTest();
      const qs = buildMCQTest(config);
      setQuestions(qs);
      setAnswers(qs.map(() => ({ selectedIndex: null, markedForReview: false })));
      setInitialTime(config.timerMinutes * 60);
      clearActiveTest();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const doSubmit = () => {
    if (submittedRef.current) return;
    submittedRef.current = true;
    const result = buildMCQResult(config!, questions, answers);
    saveResult(result);
    refreshResults();
    setLastResult(result);
    setReviewData({ mode: "mcq", questions, answers });
    clearActiveTest();
    navigate("result");
  };

  const { secondsLeft } = useCountdown({
    initialSeconds: initialTime,
    active: questions.length > 0 && config?.timerMinutes !== 0,
    onExpire: () => {
      push("Time's up! Auto-submitting your test.", "error");
      setTimeout(doSubmit, 400);
    },
    onWarning: (s) => {
      const label = s >= 600 ? "10 minutes" : s >= 300 ? "5 minutes" : "1 minute";
      push(`${label} remaining.`, "warning");
    },
  });

  // persist progress
  useEffect(() => {
    if (!config || !runId || questions.length === 0 || submittedRef.current) return;
    const state: Persisted = { kind: "mcq", runId, config, questions, answers, current, timeLeft: config.timerMinutes === 0 ? 0 : secondsLeft };
    saveActiveTest(state);
  }, [answers, current, secondsLeft, questions, config, runId]);

  // anti-accident
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (!submittedRef.current) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, []);

  // Keep current index within bounds if questions change.
  useEffect(() => {
    if (questions.length > 0 && current > questions.length - 1) {
      setCurrent(questions.length - 1);
    }
  }, [questions.length, current]);

  // Tell PRACTI which question the user is viewing so it can help in-context.
  useEffect(() => {
    if (questions.length === 0) return;
    const idx = Math.max(0, Math.min(current, questions.length - 1));
    const cq = questions[idx];
    const ans = answers[idx];
    if (cq) {
      setPractiCtx({
        kind: "mcq",
        question: cq,
        selectedIndex: ans ? ans.selectedIndex : null,
      });
    }
  }, [current, questions, answers, setPractiCtx]);

  // Reset PRACTI context when leaving the test.
  useEffect(() => {
    return () => setPractiCtx({ kind: "none" });
  }, [setPractiCtx]);

  if (!config || questions.length === 0) {
    return <div className="py-20 text-center text-slate-500">Loading test…</div>;
  }

  // Safety: never let current/answers desync crash the quiz.
  const safeCurrent = Math.max(0, Math.min(current, questions.length - 1));
  const q = questions[safeCurrent];
  const a = answers[safeCurrent] ?? { selectedIndex: null, markedForReview: false };
  if (!q) {
    return <div className="py-20 text-center text-slate-500">Loading test…</div>;
  }
  const answeredCount = answers.filter((x) => x && x.selectedIndex !== null).length;
  const reviewCount = answers.filter((x) => x && x.markedForReview).length;

  const setAnswer = (idx: number) => {
    setAnswers((prev) => prev.map((x, i) => (i === safeCurrent ? { ...x, selectedIndex: idx } : x)));
  };
  const clearAnswer = () => {
    setAnswers((prev) => prev.map((x, i) => (i === safeCurrent ? { ...x, selectedIndex: null } : x)));
  };
  const toggleReview = () => {
    setAnswers((prev) => prev.map((x, i) => (i === safeCurrent ? { ...x, markedForReview: !x.markedForReview } : x)));
  };

  const paletteStatus = (i: number) => {
    const ans = answers[i] ?? { selectedIndex: null, markedForReview: false };
    if (i === safeCurrent) return "current";
    if (ans.markedForReview) return "review";
    if (ans.selectedIndex !== null) return "answered";
    return "unanswered";
  };

  return (
    <div className="min-h-[calc(100vh-57px)] bg-slate-50 dark:bg-slate-950">
      <Toasts toasts={toasts} />
      {/* Test top bar */}
      <div className="sticky top-[57px] z-30 border-b border-slate-200 bg-white/90 backdrop-blur dark:border-slate-700 dark:bg-slate-900/90">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-2.5 sm:px-6">
          <div className="min-w-0">
            <div className="truncate text-sm font-bold text-slate-900 dark:text-white">
              {config.subject === "All Subjects" ? "Core CS Assessment" : `${config.subject} Test`}
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400">
              Q {current + 1} / {questions.length} · {answeredCount} answered
            </div>
          </div>
          <div className="flex items-center gap-2">
            {config.timerMinutes !== 0 && (
              <div className={cn(
                "flex items-center gap-1.5 rounded-lg px-3 py-1.5 font-mono text-sm font-bold tabular-nums",
                secondsLeft <= 60 ? "bg-rose-100 text-rose-700 dark:bg-rose-500/20 dark:text-rose-300" : secondsLeft <= 300 ? "bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300" : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200"
              )}>
                ⏱ {formatTime(secondsLeft)}
              </div>
            )}
            <Button size="sm" variant="outline" className="lg:hidden" onClick={() => setShowPalette((v) => !v)}>
              Palette
            </Button>
            <Button size="sm" variant="success" onClick={() => setConfirmSubmit(true)}>
              Submit
            </Button>
          </div>
        </div>
      </div>

      <div className="mx-auto grid max-w-7xl gap-5 px-4 py-5 sm:px-6 lg:grid-cols-[1fr_300px]">
        {/* Question */}
        <div>
          <Card className="p-5 sm:p-7">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600 dark:bg-slate-700 dark:text-slate-300">
                Question {current + 1}
              </span>
              <DifficultyBadge difficulty={q.difficulty} />
              <span className="rounded-full bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300">
                {q.subject}
              </span>
              <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                {q.topic}
              </span>
            </div>

            <p className="mt-5 text-base font-medium leading-relaxed text-slate-900 dark:text-white sm:text-lg">
              {q.question}
            </p>
            {q.code && (
              <pre className="mt-4 overflow-x-auto rounded-xl bg-slate-900 p-4 text-sm leading-relaxed text-slate-100 dark:bg-slate-950">
                <code>{q.code}</code>
              </pre>
            )}

            <div className="mt-6 space-y-3" role="radiogroup" aria-label="Answer options">
              {q.options.map((opt, i) => {
                const selected = a.selectedIndex === i;
                return (
                  <button
                    key={i}
                    role="radio"
                    aria-checked={selected}
                    onClick={() => setAnswer(i)}
                    className={cn(
                      "flex w-full items-start gap-3 rounded-xl border p-3.5 text-left transition-all sm:p-4",
                      selected
                        ? "border-indigo-500 bg-indigo-50 ring-2 ring-indigo-500/20 dark:border-indigo-400 dark:bg-indigo-500/10"
                        : "border-slate-200 bg-white hover:border-indigo-300 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/50 dark:hover:border-indigo-500/50"
                    )}
                  >
                    <span className={cn(
                      "flex h-7 w-7 shrink-0 items-center justify-center rounded-full border text-sm font-bold",
                      selected ? "border-indigo-500 bg-indigo-600 text-white" : "border-slate-300 text-slate-500 dark:border-slate-600 dark:text-slate-400"
                    )}>
                      {String.fromCharCode(65 + i)}
                    </span>
                    <span className="pt-0.5 text-sm text-slate-800 dark:text-slate-100">{opt}</span>
                  </button>
                );
              })}
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-2 border-t border-slate-200 pt-5 dark:border-slate-700">
              <Button variant="ghost" size="sm" onClick={clearAnswer} disabled={a.selectedIndex === null}>
                Clear Answer
              </Button>
              <Button variant={a.markedForReview ? "secondary" : "outline"} size="sm" onClick={toggleReview}>
                {a.markedForReview ? "★ Marked" : "☆ Mark for Review"}
              </Button>
              <div className="ml-auto flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setCurrent((c) => Math.max(0, c - 1))} disabled={current === 0}>
                  ← Previous
                </Button>
                {current < questions.length - 1 ? (
                  <Button size="sm" onClick={() => setCurrent((c) => Math.min(questions.length - 1, c + 1))}>
                    Next →
                  </Button>
                ) : (
                  <Button size="sm" variant="success" onClick={() => setConfirmSubmit(true)}>
                    Finish →
                  </Button>
                )}
              </div>
            </div>
          </Card>
        </div>

        {/* Palette (desktop sidebar) */}
        <div className={cn("lg:block", showPalette ? "block" : "hidden")}>
          <Card className="p-5 lg:sticky lg:top-[110px]">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Question Palette</h3>
            <div className="mt-4 grid grid-cols-6 gap-2 sm:grid-cols-8 lg:grid-cols-5">
              {questions.map((_, i) => {
                const st = paletteStatus(i);
                return (
                  <button
                    key={i}
                    onClick={() => { setCurrent(i); setShowPalette(false); }}
                    className={cn(
                      "flex h-9 w-full items-center justify-center rounded-lg text-sm font-semibold transition-all",
                      st === "current" && "bg-indigo-600 text-white ring-2 ring-indigo-400 ring-offset-1 dark:ring-offset-slate-800",
                      st === "answered" && "bg-emerald-500 text-white",
                      st === "review" && "bg-violet-500 text-white",
                      st === "unanswered" && "bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300"
                    )}
                    aria-label={`Go to question ${i + 1}, ${st}`}
                  >
                    {i + 1}
                  </button>
                );
              })}
            </div>
            <div className="mt-5 space-y-2 text-xs text-slate-500 dark:text-slate-400">
              <Legend color="bg-emerald-500" label={`Answered (${answeredCount})`} />
              <Legend color="bg-slate-300 dark:bg-slate-600" label={`Not answered (${questions.length - answeredCount})`} />
              <Legend color="bg-violet-500" label={`Marked for review (${reviewCount})`} />
              <Legend color="bg-indigo-600" label="Current question" />
            </div>
            <Button variant="success" className="mt-5 w-full" onClick={() => setConfirmSubmit(true)}>
              Submit Test
            </Button>
          </Card>
        </div>
      </div>

      {/* Submit confirmation */}
      {confirmSubmit && (
        <Modal onClose={() => setConfirmSubmit(false)}>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">Submit test?</h3>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            You answered <b>{answeredCount}</b> of <b>{questions.length}</b> questions.
            {answeredCount < questions.length && ` ${questions.length - answeredCount} unanswered.`}
            {reviewCount > 0 && ` ${reviewCount} marked for review.`}
          </p>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Your final score is calculated after submission. This cannot be undone.</p>
          <div className="mt-5 flex justify-end gap-3">
            <Button variant="outline" onClick={() => setConfirmSubmit(false)}>Keep Working</Button>
            <Button variant="success" onClick={doSubmit}>Submit Now</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className={cn("h-3.5 w-3.5 rounded", color)} />
      <span>{label}</span>
    </div>
  );
}

export function Modal({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md animate-fade-in rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-700 dark:bg-slate-800">
        {children}
      </div>
    </div>
  );
}
