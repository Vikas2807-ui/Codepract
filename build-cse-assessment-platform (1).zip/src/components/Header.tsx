import { useApp } from "../context/AppContext";
import { cn } from "../utils/cn";

export function Header() {
  const { navigate, view, theme, toggleTheme } = useApp();

  const inTest = view === "mcq-test" || view === "coding-test";

  const navItems: { label: string; view: Parameters<typeof navigate>[0] }[] = [
    { label: "Home", view: "home" },
    { label: "Practice", view: "practice" },
    { label: "Interview", view: "interview" },
    { label: "Dashboard", view: "dashboard" },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/80 backdrop-blur-xl dark:border-slate-700/60 dark:bg-slate-900/80">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <button
          onClick={() => !inTest && navigate("home")}
          className="group flex items-center gap-2.5 rounded-lg focus-visible:outline-2 focus-visible:outline-indigo-500"
          aria-label="CODEPRACT home"
        >
          <span className="relative flex h-9 w-9 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-indigo-500 via-violet-600 to-fuchsia-600 text-white shadow-md shadow-indigo-500/30 transition-transform duration-300 group-hover:scale-105 group-hover:rotate-3">
            <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
              <polyline points="16 18 22 12 16 6" />
              <polyline points="8 6 2 12 8 18" />
            </svg>
          </span>
          <span className="text-left leading-tight">
            <span className="block text-sm font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-base">
              CODE<span className="bg-gradient-to-r from-indigo-600 to-fuchsia-600 bg-clip-text text-transparent dark:from-indigo-400 dark:to-fuchsia-400">PRACT</span>
            </span>
            <span className="hidden text-[10px] font-medium uppercase tracking-[0.2em] text-slate-400 sm:block">Technical Assessment</span>
          </span>
        </button>

        {!inTest ? (
          <nav className="flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.view}
                onClick={() => navigate(item.view)}
                className={cn(
                  "rounded-lg px-2.5 py-1.5 text-sm font-medium transition-colors sm:px-3",
                  view === item.view
                    ? "bg-indigo-50 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
                )}
              >
                {item.label}
              </button>
            ))}
            <ThemeToggle theme={theme} onToggle={toggleTheme} />
          </nav>
        ) : (
          <div className="flex items-center gap-2">
            <span className="hidden items-center gap-2 rounded-full bg-rose-50 px-3 py-1 text-xs font-semibold text-rose-600 dark:bg-rose-500/15 dark:text-rose-300 sm:inline-flex">
              <span className="h-2 w-2 animate-pulse rounded-full bg-rose-500" /> Test in progress
            </span>
            <ThemeToggle theme={theme} onToggle={toggleTheme} />
          </div>
        )}
      </div>
    </header>
  );
}

function ThemeToggle({ theme, onToggle }: { theme: "light" | "dark"; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
      className="ml-1 flex h-9 w-9 items-center justify-center rounded-lg text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
    >
      {theme === "dark" ? (
        <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41" />
        </svg>
      ) : (
        <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
        </svg>
      )}
    </button>
  );
}
