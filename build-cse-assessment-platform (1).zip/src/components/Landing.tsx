import { useApp } from "../context/AppContext";
import { Button, Card } from "./ui";
import { PRESETS } from "../data/subjects";

const FEATURES = [
  { icon: "📚", title: "Practice by subject", desc: "Focus on a single CS subject or take an all-subjects assessment." },
  { icon: "🏢", title: "Company-style questions", desc: "Screening-oriented problems modeled on fresher hiring rounds." },
  { icon: "⚡", title: "Instant test feedback", desc: "Immediate scoring, explanations and test-case results." },
  { icon: "📊", title: "Performance analytics", desc: "Topic & difficulty breakdowns plus progress over time." },
  { icon: "🎚️", title: "Difficulty levels", desc: "Easy, Medium, Hard, Mixed and balanced Company Screening mode." },
  { icon: "⏱️", title: "Timed assessments", desc: "Real exam pressure with auto-submit and time warnings." },
];

export function Landing() {
  const { navigate, setPendingConfig, results } = useApp();

  const startCoding = () => {
    setPendingConfig({ mode: "coding" });
    navigate("setup");
  };
  const startMCQ = () => {
    setPendingConfig({ mode: "mcq" });
    navigate("setup");
  };

  return (
    <div className="animate-fade-in">
      {/* Hero */}
      <section className="relative overflow-hidden">
        {/* technical background */}
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-b from-indigo-50 via-white to-white dark:from-slate-950 dark:via-slate-900 dark:to-slate-950" />
          <div
            className="absolute inset-0 opacity-[0.35] dark:opacity-25"
            style={{
              backgroundImage:
                "linear-gradient(to right, rgba(99,102,241,0.12) 1px, transparent 1px), linear-gradient(to bottom, rgba(99,102,241,0.12) 1px, transparent 1px)",
              backgroundSize: "44px 44px",
              maskImage: "radial-gradient(ellipse 75% 65% at 50% 25%, black, transparent)",
              WebkitMaskImage: "radial-gradient(ellipse 75% 65% at 50% 25%, black, transparent)",
            }}
          />
          <div className="animate-glow absolute -right-20 top-0 h-80 w-80 rounded-full bg-fuchsia-300/30 blur-3xl dark:bg-fuchsia-600/20" />
          <div className="animate-glow absolute -left-20 top-32 h-80 w-80 rounded-full bg-indigo-300/30 blur-3xl dark:bg-indigo-600/20" style={{ animationDelay: "3s" }} />
        </div>

        <div className="mx-auto max-w-7xl px-4 pb-10 pt-16 sm:px-6 sm:pt-24">
          {/* 3D animated wordmark */}
          <div className="flex justify-center [perspective:1200px]">
            <div className="animate-hero3d relative">
              {/* orbital rings */}
              <div className="animate-spin-slow pointer-events-none absolute left-1/2 top-1/2 h-[140%] w-[140%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-indigo-300/40 dark:border-indigo-500/20" />
              <div className="animate-spin-slower pointer-events-none absolute left-1/2 top-1/2 h-[175%] w-[175%] -translate-x-1/2 -translate-y-1/2 rounded-[45%] border border-fuchsia-300/30 dark:border-fuchsia-500/15" />
              <h1
                className="animate-shimmer relative select-none text-center text-5xl font-black leading-none tracking-tighter sm:text-7xl md:text-8xl"
                style={{ transform: "translateZ(60px)" }}
              >
                <span className="animate-gradient bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-600 bg-clip-text text-transparent drop-shadow-[0_8px_24px_rgba(99,102,241,0.35)] dark:from-indigo-400 dark:via-violet-400 dark:to-fuchsia-400">
                  CODEPRACT
                </span>
              </h1>
            </div>
          </div>

          <div className="mx-auto mt-10 max-w-3xl text-center">
            <span className="reveal-up inline-flex items-center gap-2 rounded-full border border-indigo-200 bg-white/70 px-4 py-1.5 text-xs font-semibold text-indigo-700 shadow-sm backdrop-blur dark:border-indigo-500/30 dark:bg-slate-800/50 dark:text-indigo-300" style={{ animationDelay: "0.1s" }}>
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" />
              Practice. Assess. Get hired.
            </span>
            <p className="reveal-up mx-auto mt-5 max-w-2xl text-lg font-semibold text-slate-800 dark:text-slate-100 sm:text-xl" style={{ animationDelay: "0.2s" }}>
              The technical-assessment platform for CSE freshers.
            </p>
            <p className="reveal-up mx-auto mt-3 max-w-2xl text-base text-slate-500 dark:text-slate-400" style={{ animationDelay: "0.3s" }}>
              Master coding, core computer-science and problem-solving with company-style tests, instant feedback and your own AI tutor.
            </p>
          </div>

          {/* Two primary options */}
          <div className="mx-auto mt-14 grid max-w-4xl gap-5 sm:grid-cols-2">
            <div className="reveal-up" style={{ animationDelay: "0.4s" }}>
              <Card hover className="group lift flex h-full flex-col p-7">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-blue-600 text-2xl font-bold text-white shadow-lg shadow-indigo-500/30 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6">
                  {"</>"}
                </div>
                <h3 className="mt-5 text-xl font-bold text-slate-900 dark:text-white">Code Test</h3>
                <p className="mt-2 flex-1 text-sm text-slate-500 dark:text-slate-400">
                  Write real programs and test your coding ability across Python, C, C++, Java and SQL.
                </p>
                <Button size="lg" className="mt-6 w-full" onClick={startCoding}>
                  Start Coding Test
                </Button>
              </Card>
            </div>

            <div className="reveal-up" style={{ animationDelay: "0.5s" }}>
              <Card hover className="group lift flex h-full flex-col p-7">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-600 text-2xl text-white shadow-lg shadow-violet-500/30 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6">
                  🧠
                </div>
                <h3 className="mt-5 text-xl font-bold text-slate-900 dark:text-white">Core CS / Non-Coding Test</h3>
                <p className="mt-2 flex-1 text-sm text-slate-500 dark:text-slate-400">
                  Test your knowledge of CSE subjects through company-style MCQs across 16 subjects.
                </p>
                <Button size="lg" variant="secondary" className="mt-6 w-full" onClick={startMCQ}>
                  Start MCQ Test
                </Button>
              </Card>
            </div>
          </div>

          <p className="reveal-up mt-6 text-center text-xs text-slate-400" style={{ animationDelay: "0.6s" }}>
            No sign-up required — start a test instantly. Your progress is saved on this device.
          </p>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <h2 className="text-center text-sm font-semibold uppercase tracking-widest text-indigo-600 dark:text-indigo-400">
          Everything you need to prepare
        </h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <div key={f.title} className="reveal-up" style={{ animationDelay: `${0.05 * i}s` }}>
              <Card className="lift group h-full p-6" hover>
                <div className="text-2xl transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:scale-110">{f.icon}</div>
                <h3 className="mt-3 font-semibold text-slate-900 dark:text-white">{f.title}</h3>
                <p className="mt-1.5 text-sm text-slate-500 dark:text-slate-400">{f.desc}</p>
              </Card>
            </div>
          ))}
        </div>
      </section>

      {/* Presets */}
      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6">
        <div className="rounded-3xl border border-slate-200 bg-gradient-to-br from-slate-50 to-indigo-50/50 p-6 dark:border-slate-700/60 dark:from-slate-800/50 dark:to-slate-900 sm:p-8">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white sm:text-2xl">Company-style test presets</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            These describe the assessment format only — they are not affiliated with any specific company.
          </p>
          <div className="mt-6 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {PRESETS.map((p) => (
              <button
                key={p.name}
                onClick={() => {
                  setPendingConfig({
                    mode: p.config.mode,
                    count: p.config.count,
                    difficulty: p.config.difficulty as never,
                    timerMinutes: p.config.timer,
                    preset: p.name,
                  });
                  navigate("setup");
                }}
                className="group rounded-2xl border border-slate-200 bg-white p-5 text-left transition-all hover:border-indigo-400 hover:shadow-md dark:border-slate-700 dark:bg-slate-800/60 dark:hover:border-indigo-500"
              >
                <div className="flex items-center justify-between">
                  <span className="rounded-lg bg-indigo-100 px-2 py-0.5 text-xs font-semibold uppercase text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300">
                    {p.config.mode === "coding" ? "Coding" : "MCQ"}
                  </span>
                  <span className="text-slate-300 transition-transform group-hover:translate-x-1 dark:text-slate-600">→</span>
                </div>
                <h3 className="mt-3 font-semibold text-slate-900 dark:text-white">{p.name}</h3>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{p.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {results.length > 0 && (
          <div className="mt-6 flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-700 dark:bg-slate-800/60">
            <div>
              <p className="text-sm font-semibold text-slate-900 dark:text-white">You have {results.length} completed test{results.length > 1 ? "s" : ""}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">View your analytics and progress over time.</p>
            </div>
            <Button variant="outline" onClick={() => navigate("dashboard")}>Open Dashboard</Button>
          </div>
        )}
      </section>

      <footer className="mt-4 border-t border-slate-200 dark:border-slate-800">
        <div className="mx-auto flex max-w-7xl flex-col items-center gap-4 px-4 py-10 text-center sm:px-6">
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500 via-violet-600 to-fuchsia-600 text-white shadow-md shadow-indigo-500/30">
              <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
                <polyline points="16 18 22 12 16 6" />
                <polyline points="8 6 2 12 8 18" />
              </svg>
            </span>
            <span className="text-base font-extrabold tracking-tight text-slate-900 dark:text-white">
              CODE<span className="bg-gradient-to-r from-indigo-600 to-fuchsia-600 bg-clip-text text-transparent dark:from-indigo-400 dark:to-fuchsia-400">PRACT</span>
            </span>
          </div>
          <p className="max-w-xl text-xs text-slate-400">
            A practice platform for technical-assessment preparation. Your progress is stored locally on your device.
          </p>

          <div className="mt-2 flex flex-col items-center gap-1 border-t border-slate-200 pt-6 dark:border-slate-800">
            <p className="text-xs uppercase tracking-[0.2em] text-slate-400">Designed &amp; developed by</p>
            <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">Vikas Katkoju</p>
            <a
              href="mailto:vikascharykatkoju@gmail.com"
              className="text-sm font-medium text-indigo-600 transition-colors hover:text-fuchsia-600 hover:underline dark:text-indigo-400 dark:hover:text-fuchsia-400"
            >
              vikascharykatkoju@gmail.com
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
