import { useState } from "react";
import { useApp } from "../context/AppContext";
import { Button, Card, DifficultyBadge } from "./ui";
import { cn } from "../utils/cn";
import { SUBJECTS, CODING_LANGUAGES, TIMER_OPTIONS } from "../data/subjects";
import type { TestConfig, TestMode } from "../data/types";
import { availableMCQCount, availableCodingCount } from "../lib/engine";
import { clearActiveTest } from "../lib/storage";

const DIFFICULTIES: { key: TestConfig["difficulty"]; label: string; desc: string }[] = [
  { key: "Easy", label: "Easy", desc: "Fundamentals & warm-up" },
  { key: "Medium", label: "Medium", desc: "Standard screening level" },
  { key: "Hard", label: "Hard", desc: "Challenging problems" },
  { key: "Mixed", label: "Mixed", desc: "Even blend of all levels" },
  { key: "Company Screening", label: "Company Screening", desc: "Balanced easy → hard set" },
];

export function Setup() {
  const { pendingConfig, navigate } = useApp();
  const initialMode = (pendingConfig?.mode as TestMode) || "coding";

  const [mode, setMode] = useState<TestMode>(initialMode);
  const [language, setLanguage] = useState<string>(pendingConfig?.language || "Python");
  const [subject, setSubject] = useState<string>(pendingConfig?.subject || "All Subjects");
  const [difficulty, setDifficulty] = useState<TestConfig["difficulty"]>(
    (pendingConfig?.difficulty as TestConfig["difficulty"]) || "Company Screening"
  );
  const [count, setCount] = useState<number>(
    pendingConfig?.count || (initialMode === "coding" ? 10 : 50)
  );
  const [timer, setTimer] = useState<number>(
    pendingConfig?.timerMinutes ?? (initialMode === "coding" ? 60 : 45)
  );

  const codingCounts = [5, 10, 15, 20];
  const mcqCounts = [10, 25, 50, 75, 100];

  // Rule: every single-subject MCQ quiz is fixed at 25 questions. Only the mock
  // test (All Subjects) lets the user choose the number of questions.
  const isSubjectQuiz = mode === "mcq" && subject !== "All Subjects";

  const available =
    mode === "coding" ? availableCodingCount(language) : availableMCQCount(subject);
  const effectiveCount = isSubjectQuiz
    ? Math.min(25, available)
    : Math.min(count, available);

  const startTest = () => {
    const config: TestConfig = {
      mode,
      language: mode === "coding" ? language : undefined,
      subject: mode === "mcq" ? subject : "All Subjects",
      difficulty,
      count: effectiveCount,
      timerMinutes: timer,
      preset: pendingConfig?.preset,
    };
    // A deliberately-started test must ALWAYS get fresh questions. We stamp this
    // run with a unique ID. The test component only restores a saved in-progress
    // test when its stored runId matches the current one — which happens solely
    // on an accidental page refresh (sessionStorage survives reloads). Any
    // previous, unfinished test has a different runId and is therefore ignored,
    // guaranteeing brand-new questions every time you start from this screen.
    const runId = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    clearActiveTest();
    sessionStorage.setItem("csect_run_config", JSON.stringify(config));
    sessionStorage.setItem("csect_run_id", runId);
    navigate(mode === "coding" ? "coding-test" : "mcq-test");
  };

  return (
    <div className="mx-auto max-w-4xl animate-fade-in px-4 py-8 sm:px-6">
      <button onClick={() => navigate("home")} className="mb-4 text-sm font-medium text-slate-500 hover:text-indigo-600 dark:text-slate-400">
        ← Back to home
      </button>
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white sm:text-3xl">Choose Assessment</h1>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
        Configure your test. Clear instructions are shown before you begin.
      </p>

      {/* Mode */}
      <Section num={1} title="Assessment Type">
        <div className="grid gap-3 sm:grid-cols-2">
          <SelectTile active={mode === "coding"} onClick={() => { setMode("coding"); setCount(10); setTimer(60); }}>
            <div className="text-lg font-semibold">Coding Test</div>
            <div className="text-sm opacity-80">Write real programs & solve problems.</div>
          </SelectTile>
          <SelectTile active={mode === "mcq"} onClick={() => { setMode("mcq"); setCount(50); setTimer(45); }}>
            <div className="text-lg font-semibold">Core CS / MCQ Test</div>
            <div className="text-sm opacity-80">Company-style multiple-choice questions.</div>
          </SelectTile>
        </div>
      </Section>

      {/* Language or Subject */}
      {mode === "coding" ? (
        <Section num={2} title="Programming Language">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {CODING_LANGUAGES.map((l) => (
              <SelectTile key={l.name} active={language === l.name} onClick={() => setLanguage(l.name)}>
                <div className="flex items-center gap-2 text-lg font-semibold">
                  <span>{l.icon}</span> {l.name}
                  {l.db && <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold uppercase text-amber-700 dark:bg-amber-500/20 dark:text-amber-300">DB</span>}
                </div>
                <div className="text-xs opacity-80">{l.desc}</div>
              </SelectTile>
            ))}
          </div>
        </Section>
      ) : (
        <Section num={2} title="Subject Selection" sub="Pick All Subjects or focus on a single subject. Single-subject mode never mixes subjects.">
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
            <SelectTile active={subject === "All Subjects"} onClick={() => setSubject("All Subjects")} compact>
              <div className="font-semibold">All Subjects</div>
              <div className="text-xs opacity-70">{availableMCQCount("All Subjects")} questions</div>
            </SelectTile>
            {SUBJECTS.map((s) => (
              <SelectTile key={s} active={subject === s} onClick={() => setSubject(s)} compact>
                <div className="text-sm font-semibold leading-tight">{s}</div>
                <div className="text-xs opacity-70">{availableMCQCount(s)} questions</div>
              </SelectTile>
            ))}
          </div>
        </Section>
      )}

      {/* Difficulty */}
      <Section num={3} title="Difficulty">
        <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
          {DIFFICULTIES.map((d) => (
            <SelectTile key={d.key} active={difficulty === d.key} onClick={() => setDifficulty(d.key)} compact>
              <div className="flex items-center gap-2">
                {(d.key === "Easy" || d.key === "Medium" || d.key === "Hard") && <DifficultyBadge difficulty={d.key} />}
                <span className="font-semibold">{d.label}</span>
              </div>
              <div className="mt-0.5 text-xs opacity-75">{d.desc}</div>
            </SelectTile>
          ))}
        </div>
      </Section>

      {/* Count */}
      <Section num={4} title="Number of Questions">
        {isSubjectQuiz ? (
          <div>
            <div className="inline-flex items-center gap-2 rounded-xl border border-indigo-500 bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm">
              🔒 25 questions (fixed)
            </div>
            <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
              Single-subject quizzes always contain 25 questions. Choose <b>All Subjects</b> (mock test) to pick a custom number.
            </p>
          </div>
        ) : (
          <>
            <div className="flex flex-wrap gap-2.5">
              {(mode === "coding" ? codingCounts : mcqCounts).map((c) => (
                <button
                  key={c}
                  onClick={() => setCount(c)}
                  className={cn(
                    "min-w-[64px] rounded-xl border px-4 py-2.5 text-sm font-semibold transition-all",
                    count === c
                      ? "border-indigo-500 bg-indigo-600 text-white shadow-sm"
                      : "border-slate-300 bg-white text-slate-700 hover:border-indigo-400 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200"
                  )}
                >
                  {c}
                </button>
              ))}
            </div>
            {mode === "mcq" && (
              <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
                This is the <b>mock test</b> (all subjects mixed) — pick any number of questions.
              </p>
            )}
            {effectiveCount < count && (
              <p className="mt-2 text-xs text-amber-600 dark:text-amber-400">
                Only {available} questions are available — the test will use {effectiveCount}.
              </p>
            )}
          </>
        )}
      </Section>

      {/* Timer */}
      <Section num={5} title="Timer">
        <div className="flex flex-wrap gap-2.5">
          {TIMER_OPTIONS.map((t) => (
            <button
              key={t.value}
              onClick={() => setTimer(t.value)}
              className={cn(
                "rounded-xl border px-4 py-2.5 text-sm font-semibold transition-all",
                timer === t.value
                  ? "border-indigo-500 bg-indigo-600 text-white shadow-sm"
                  : "border-slate-300 bg-white text-slate-700 hover:border-indigo-400 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200"
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
      </Section>

      {/* Instructions */}
      <Card className="mt-8 border-indigo-200 bg-indigo-50/50 p-5 dark:border-indigo-500/30 dark:bg-indigo-500/5">
        <h3 className="flex items-center gap-2 font-semibold text-slate-900 dark:text-white">
          <span>📋</span> Instructions before you begin
        </h3>
        <ul className="mt-3 space-y-1.5 text-sm text-slate-600 dark:text-slate-300">
          <li>• This test has <b>{effectiveCount}</b> {mode === "coding" ? "coding problems" : "MCQs"} — {mode === "coding" ? `in ${language}` : subject === "All Subjects" ? "across all subjects" : `on ${subject} only`}.</li>
          <li>• Difficulty: <b>{difficulty}</b>. {timer === 0 ? "This test is untimed." : `You have ${timer} minutes; the test auto-submits when time runs out.`}</li>
          <li>• Your answers, code and progress are saved automatically — you won't lose work on navigation or refresh.</li>
          {mode === "mcq" ? (
            <li>• Use the question palette, mark questions for review, and submit when ready.</li>
          ) : (
            <li>• Write the complete program. Use Run to check samples and Submit to evaluate against all test cases.</li>
          )}
          <li>• Your final score is calculated only after you submit the whole test.</li>
        </ul>
      </Card>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-end">
        <Button variant="outline" size="lg" onClick={() => navigate("home")}>Cancel</Button>
        <Button size="lg" onClick={startTest} disabled={effectiveCount === 0}>
          Start Test →
        </Button>
      </div>
    </div>
  );
}

function Section({ num, title, sub, children }: { num: number; title: string; sub?: string; children: React.ReactNode }) {
  return (
    <div className="mt-8">
      <div className="mb-3 flex items-center gap-2.5">
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-indigo-600 text-xs font-bold text-white">{num}</span>
        <h2 className="text-lg font-bold text-slate-900 dark:text-white">{title}</h2>
      </div>
      {sub && <p className="mb-3 -mt-1 pl-9 text-sm text-slate-500 dark:text-slate-400">{sub}</p>}
      <div className="pl-0 sm:pl-9">{children}</div>
    </div>
  );
}

function SelectTile({
  active,
  onClick,
  children,
  compact,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
  compact?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "rounded-xl border text-left transition-all focus-visible:outline-2 focus-visible:outline-indigo-500",
        compact ? "p-3" : "p-4",
        active
          ? "border-indigo-500 bg-indigo-50 text-indigo-900 ring-2 ring-indigo-500/20 dark:border-indigo-400 dark:bg-indigo-500/10 dark:text-white"
          : "border-slate-300 bg-white text-slate-700 hover:border-indigo-400 hover:bg-slate-50 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200 dark:hover:border-indigo-500"
      )}
    >
      {children}
    </button>
  );
}
