import { useMemo, useState } from "react";
import { useApp } from "../context/AppContext";
import { Button, Card } from "./ui";
import { cn } from "../utils/cn";
import { shuffle } from "../lib/engine";

interface IQ {
  category: string;
  question: string;
  keyPoints: string[];
  model: string;
}

const INTERVIEW_BANK: IQ[] = [
  { category: "CS Fundamentals", question: "Explain the difference between a process and a thread.", keyPoints: ["process", "thread", "memory", "address space", "share", "lightweight", "stack"], model: "A process is an independent program in execution with its own address space; a thread is a lightweight unit within a process that shares the code, data and heap but has its own stack and registers. Threads are cheaper to create and switch between." },
  { category: "CS Fundamentals", question: "What is the difference between stack and heap memory?", keyPoints: ["stack", "heap", "automatic", "dynamic", "lifo", "allocation", "fast"], model: "The stack stores function call frames and local variables with automatic LIFO allocation (fast, limited size). The heap is used for dynamic allocation controlled by the programmer, larger but slower and prone to fragmentation and leaks." },
  { category: "OOP", question: "Explain the four pillars of OOP with a brief example.", keyPoints: ["encapsulation", "inheritance", "polymorphism", "abstraction"], model: "Encapsulation bundles data with methods and hides internal state; Abstraction exposes only essential features; Inheritance lets a class reuse another's behavior; Polymorphism lets one interface behave differently (overloading/overriding)." },
  { category: "OOP", question: "What is the difference between an abstract class and an interface?", keyPoints: ["abstract", "interface", "multiple", "implementation", "instantiate", "method"], model: "An abstract class can have both implemented and abstract methods and state, and supports single inheritance. An interface (classically) only declares a contract; a class can implement many interfaces, enabling multiple inheritance of type." },
  { category: "SQL", question: "What is the difference between WHERE and HAVING clauses?", keyPoints: ["where", "having", "group", "aggregate", "filter", "row"], model: "WHERE filters individual rows before grouping and cannot use aggregate functions. HAVING filters groups after GROUP BY and can use aggregates like COUNT or AVG." },
  { category: "SQL", question: "Explain database normalization and why it matters.", keyPoints: ["normalization", "redundancy", "anomaly", "1nf", "2nf", "3nf", "integrity"], model: "Normalization organizes tables to reduce redundancy and avoid update/insert/delete anomalies by progressively applying normal forms (1NF atomic values, 2NF no partial dependency, 3NF no transitive dependency), improving data integrity." },
  { category: "Coding", question: "How would you detect a cycle in a linked list? Explain your approach.", keyPoints: ["cycle", "two pointer", "slow", "fast", "floyd", "meet"], model: "Use Floyd's cycle detection: move a slow pointer one step and a fast pointer two steps. If they meet, there's a cycle; if fast reaches null, there is none. It runs in O(n) time and O(1) space." },
  { category: "Coding", question: "Explain how you would find the first non-repeating character in a string.", keyPoints: ["hash", "map", "frequency", "count", "two pass", "order"], model: "Do two passes: first build a frequency map of characters, then scan the string in order and return the first character whose count is 1. O(n) time, O(k) space." },
  { category: "Problem Solving", question: "You have a list of 1 million integers and must find duplicates efficiently. How?", keyPoints: ["hash", "set", "o(n)", "space", "sort", "memory"], model: "Use a hash set: iterate once, and if a value already exists in the set it's a duplicate — O(n) time, O(n) space. If memory is constrained, sort first (O(n log n)) and scan adjacent elements." },
  { category: "Problem Solving", question: "How would you design a URL shortener at a high level?", keyPoints: ["hash", "database", "unique", "base62", "id", "redirect", "cache"], model: "Generate a unique short key (e.g., base62 of an auto-increment ID or a hash), store the mapping in a database, and on lookup redirect to the original URL. Add caching for hot links and handle collisions/expiry." },
  { category: "CS Fundamentals", question: "What happens when you type a URL and press Enter?", keyPoints: ["dns", "tcp", "http", "ip", "request", "response", "render"], model: "The browser resolves the domain via DNS, opens a TCP connection (and TLS for HTTPS), sends an HTTP request, the server responds, and the browser parses HTML/CSS/JS to render the page." },
  { category: "OOP", question: "Explain the difference between method overloading and overriding.", keyPoints: ["overloading", "overriding", "compile", "runtime", "signature", "inheritance"], model: "Overloading is multiple methods with the same name but different parameters, resolved at compile time. Overriding redefines a parent method with the same signature in a subclass, resolved at runtime (dynamic dispatch)." },
];

const CATEGORIES = ["All", "Coding", "CS Fundamentals", "SQL", "OOP", "Problem Solving"];

export function Interview() {
  const { navigate } = useApp();
  const [category, setCategory] = useState("All");
  const [started, setStarted] = useState(false);

  if (started) return <InterviewRunner category={category} onExit={() => setStarted(false)} />;

  return (
    <div className="mx-auto max-w-3xl animate-fade-in px-4 py-8 sm:px-6">
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white sm:text-3xl">Technical Interview Mode</h1>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
        Answer one open-ended question at a time and get instant feedback on your explanation. Optional and unscored — great for verbal interview prep.
      </p>

      <Card className="mt-6 p-5">
        <h2 className="font-bold text-slate-900 dark:text-white">Choose a category</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button key={c} onClick={() => setCategory(c)}
              className={cn("rounded-lg border px-3.5 py-2 text-sm font-semibold",
                category === c ? "border-indigo-500 bg-indigo-600 text-white" : "border-slate-300 bg-white text-slate-700 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200")}>
              {c}
            </button>
          ))}
        </div>
        <Button className="mt-5" onClick={() => setStarted(true)}>Start Interview</Button>
      </Card>

      <div className="mt-4 text-center">
        <button onClick={() => navigate("home")} className="text-sm text-slate-400 hover:text-indigo-600">← Back to home</button>
      </div>
    </div>
  );
}

function InterviewRunner({ category, onExit }: { category: string; onExit: () => void }) {
  const questions = useMemo(() => {
    const pool = category === "All" ? INTERVIEW_BANK : INTERVIEW_BANK.filter((q) => q.category === category);
    return shuffle(pool);
  }, [category]);

  const [idx, setIdx] = useState(0);
  const [answer, setAnswer] = useState("");
  const [feedback, setFeedback] = useState<{ covered: string[]; missing: string[]; score: number } | null>(null);

  if (questions.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <p className="text-slate-500">No questions in this category.</p>
        <Button className="mt-4" onClick={onExit}>Back</Button>
      </div>
    );
  }

  const q = questions[idx % questions.length];

  const evaluate = () => {
    const text = answer.toLowerCase();
    const covered = q.keyPoints.filter((k) => text.includes(k.toLowerCase()));
    const missing = q.keyPoints.filter((k) => !text.includes(k.toLowerCase()));
    const score = Math.round((covered.length / q.keyPoints.length) * 100);
    setFeedback({ covered, missing, score });
  };

  const next = () => {
    setIdx((i) => i + 1);
    setAnswer("");
    setFeedback(null);
  };

  return (
    <div className="mx-auto max-w-3xl animate-fade-in px-4 py-8 sm:px-6">
      <div className="flex items-center justify-between">
        <button onClick={onExit} className="text-sm font-medium text-slate-500 hover:text-indigo-600 dark:text-slate-400">← Exit interview</button>
        <span className="text-sm font-semibold text-slate-400">Question {idx + 1}</span>
      </div>

      <Card className="mt-5 p-5 sm:p-6">
        <span className="rounded-full bg-violet-100 px-2.5 py-0.5 text-xs font-semibold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300">{q.category}</span>
        <h2 className="mt-3 text-lg font-semibold text-slate-900 dark:text-white">🎤 {q.question}</h2>

        <textarea
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          placeholder="Type your explanation here, as if answering an interviewer aloud…"
          className="mt-4 h-40 w-full resize-y rounded-xl border border-slate-300 bg-white p-3.5 text-sm text-slate-800 focus-visible:outline-2 focus-visible:outline-indigo-500 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-100"
        />

        <div className="mt-3 flex flex-wrap gap-2">
          <Button onClick={evaluate} disabled={answer.trim().length < 10}>🤖 Get AI Feedback</Button>
          <Button variant="outline" onClick={next}>Skip / Next →</Button>
        </div>

        {feedback && (
          <div className="mt-5 animate-fade-in space-y-3">
            <div className={cn("rounded-xl p-4",
              feedback.score >= 70 ? "bg-emerald-50 dark:bg-emerald-500/10" : feedback.score >= 40 ? "bg-amber-50 dark:bg-amber-500/10" : "bg-rose-50 dark:bg-rose-500/10")}>
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 dark:text-white">Coverage of key points</span>
                <span className={cn("text-lg font-bold", feedback.score >= 70 ? "text-emerald-600" : feedback.score >= 40 ? "text-amber-600" : "text-rose-600")}>{feedback.score}%</span>
              </div>
              <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
                {feedback.score >= 70 ? "Strong answer — you touched on most of the important concepts." :
                 feedback.score >= 40 ? "Decent start, but you missed some key ideas an interviewer looks for." :
                 "Your answer is missing several core concepts. Review the model answer below."}
              </p>
            </div>
            {feedback.covered.length > 0 && (
              <p className="text-sm text-emerald-700 dark:text-emerald-400"><b>✓ Mentioned:</b> {feedback.covered.join(", ")}</p>
            )}
            {feedback.missing.length > 0 && (
              <p className="text-sm text-rose-700 dark:text-rose-400"><b>✗ Consider mentioning:</b> {feedback.missing.join(", ")}</p>
            )}
            <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-600 dark:bg-slate-800/50 dark:text-slate-300">
              <b className="text-slate-900 dark:text-white">Model answer:</b> {q.model}
            </div>
            <div className="flex justify-end">
              <Button onClick={next}>Next Question →</Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
