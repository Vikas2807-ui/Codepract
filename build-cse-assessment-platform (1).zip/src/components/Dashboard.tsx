import { useMemo } from "react";
import { useApp } from "../context/AppContext";
import { Button, Card, Stat, ProgressBar } from "./ui";
import { cn } from "../utils/cn";
import { clearResults } from "../lib/storage";
import { computeWeakTopics } from "../lib/analysis";

export function Dashboard() {
  const { results, navigate, refreshResults, setPendingConfig } = useApp();

  const stats = useMemo(() => {
    if (results.length === 0) return null;
    const scores = results.map((r) => r.accuracy);
    const avg = Math.round(scores.reduce((s, x) => s + x, 0) / scores.length);
    const high = Math.max(...scores);
    const coding = results.filter((r) => r.mode === "coding");
    const mcq = results.filter((r) => r.mode === "mcq");
    const codingAcc = coding.length ? Math.round(coding.reduce((s, r) => s + r.accuracy, 0) / coding.length) : 0;
    const mcqAcc = mcq.length ? Math.round(mcq.reduce((s, r) => s + r.accuracy, 0) / mcq.length) : 0;

    // subject aggregation
    const subjAgg: Record<string, { correct: number; total: number }> = {};
    results.forEach((r) => {
      r.topicPerf.forEach((t) => {
        const key = r.config.subject !== "All Subjects" ? r.config.subject : t.topic;
        if (!subjAgg[key]) subjAgg[key] = { correct: 0, total: 0 };
        subjAgg[key].correct += t.correct;
        subjAgg[key].total += t.total;
      });
    });
    const subjArr = Object.entries(subjAgg)
      .filter(([, v]) => v.total >= 2)
      .map(([k, v]) => ({ name: k, pct: Math.round((v.correct / v.total) * 100) }))
      .sort((a, b) => b.pct - a.pct);
    const strongest = subjArr[0]?.name || "—";
    const weakest = subjArr[subjArr.length - 1]?.name || "—";

    return { avg, high, codingCount: coding.length, mcqCount: mcq.length, codingAcc, mcqAcc, strongest, weakest };
  }, [results]);

  const progress = useMemo(() => [...results].reverse().slice(-8), [results]);
  const weakTopics = useMemo(() => computeWeakTopics(results).slice(0, 5), [results]);

  const handleClear = () => {
    if (confirm("Clear all test history? This cannot be undone.")) {
      clearResults();
      refreshResults();
    }
  };

  if (results.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <div className="text-5xl">📊</div>
        <h1 className="mt-4 text-2xl font-bold text-slate-900 dark:text-white">No tests completed yet</h1>
        <p className="mt-2 text-slate-500 dark:text-slate-400">Take your first assessment to unlock analytics and progress tracking.</p>
        <div className="mt-6 flex justify-center gap-3">
          <Button onClick={() => { setPendingConfig({ mode: "coding" }); navigate("setup"); }}>Start Coding Test</Button>
          <Button variant="secondary" onClick={() => { setPendingConfig({ mode: "mcq" }); navigate("setup"); }}>Start MCQ Test</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl animate-fade-in px-4 py-8 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white sm:text-3xl">Dashboard</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">Your performance across {results.length} completed test{results.length > 1 ? "s" : ""}.</p>
        </div>
        <Button variant="outline" size="sm" onClick={handleClear}>Clear History</Button>
      </div>

      {/* Performance stats */}
      {stats && (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
          <Stat label="Avg Score" value={`${stats.avg}%`} />
          <Stat label="Highest" value={`${stats.high}%`} />
          <Stat label="Tests Done" value={results.length} />
          <Stat label="Coding Acc." value={`${stats.codingAcc}%`} />
          <Stat label="MCQ Acc." value={`${stats.mcqAcc}%`} />
          <Stat label="Strongest" value={<span className="text-base leading-tight">{trunc(stats.strongest)}</span>} />
          <Stat label="Weakest" value={<span className="text-base leading-tight">{trunc(stats.weakest)}</span>} />
        </div>
      )}

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        {/* Progress chart */}
        <Card className="p-5">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">Progress Over Time</h2>
          <p className="text-xs text-slate-400">Accuracy of your last {progress.length} tests</p>
          <div className="mt-6 flex h-44 items-end justify-between gap-2">
            {progress.map((r, i) => (
              <div key={r.id} className="group flex flex-1 flex-col items-center gap-1">
                <span className="text-[10px] font-bold text-slate-400 opacity-0 transition-opacity group-hover:opacity-100">{r.accuracy}%</span>
                <div className="flex w-full flex-1 items-end">
                  <div
                    className={cn("w-full rounded-t-md transition-all",
                      r.accuracy >= 75 ? "bg-emerald-500" : r.accuracy >= 50 ? "bg-amber-500" : "bg-rose-500")}
                    style={{ height: `${Math.max(6, r.accuracy)}%` }}
                    title={`${r.accuracy}%`}
                  />
                </div>
                <span className="text-[10px] font-medium text-slate-400">T{i + 1}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Weak areas */}
        <Card className="p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Weak Areas</h2>
            <Button size="sm" variant="outline" onClick={() => navigate("practice")}>Practice These</Button>
          </div>
          <div className="mt-4 space-y-3">
            {weakTopics.length === 0 && <p className="text-sm text-slate-400">Take more tests to identify weak areas.</p>}
            {weakTopics.map((t) => (
              <div key={t.topic}>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <span className="font-medium text-slate-700 dark:text-slate-300">{t.topic}</span>
                  <span className={cn("font-semibold", t.pct >= 75 ? "text-emerald-500" : t.pct >= 50 ? "text-amber-500" : "text-rose-500")}>{t.pct}%</span>
                </div>
                <ProgressBar value={t.pct} />
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* My Tests */}
      <Card className="mt-5 p-5">
        <h2 className="text-lg font-bold text-slate-900 dark:text-white">My Tests</h2>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[560px] text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-xs uppercase text-slate-400 dark:border-slate-700">
                <th className="pb-2 font-semibold">Date</th>
                <th className="pb-2 font-semibold">Type</th>
                <th className="pb-2 font-semibold">Focus</th>
                <th className="pb-2 font-semibold">Difficulty</th>
                <th className="pb-2 text-right font-semibold">Score</th>
              </tr>
            </thead>
            <tbody>
              {results.map((r) => (
                <tr key={r.id} className="border-b border-slate-100 last:border-0 dark:border-slate-800">
                  <td className="py-2.5 text-slate-500 dark:text-slate-400">{new Date(r.date).toLocaleDateString()} {new Date(r.date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</td>
                  <td className="py-2.5">
                    <span className={cn("rounded-md px-2 py-0.5 text-xs font-semibold",
                      r.mode === "coding" ? "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300" : "bg-violet-100 text-violet-700 dark:bg-violet-500/15 dark:text-violet-300")}>
                      {r.mode === "coding" ? "Coding" : "MCQ"}
                    </span>
                  </td>
                  <td className="py-2.5 text-slate-700 dark:text-slate-200">{r.mode === "coding" ? r.config.language : r.config.subject}</td>
                  <td className="py-2.5 text-slate-500 dark:text-slate-400">{String(r.config.difficulty)}</td>
                  <td className="py-2.5 text-right">
                    <span className={cn("font-bold", r.accuracy >= 75 ? "text-emerald-500" : r.accuracy >= 50 ? "text-amber-500" : "text-rose-500")}>
                      {r.correct}/{r.total} · {r.accuracy}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function trunc(s: string) {
  return s.length > 16 ? s.slice(0, 15) + "…" : s;
}
