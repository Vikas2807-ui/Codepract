import { useEffect, useRef, useState } from "react";
import { useApp } from "../context/AppContext";
import { askPracti, practiGreeting, type ChatMessage } from "../lib/practi";
import { cn } from "../utils/cn";

/* Render a small subset of markdown-ish formatting (**bold**, `code`, line
 * breaks) safely as React nodes — no dangerouslySetInnerHTML. */
function RichText({ text }: { text: string }) {
  const lines = text.split("\n");
  return (
    <>
      {lines.map((line, li) => (
        <span key={li}>
          {renderInline(line)}
          {li < lines.length - 1 && <br />}
        </span>
      ))}
    </>
  );
}

function renderInline(line: string) {
  // split on **bold** and `code`
  const parts = line.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return parts.map((p, i) => {
    if (p.startsWith("**") && p.endsWith("**")) {
      return (
        <strong key={i} className="font-semibold text-slate-900 dark:text-white">
          {p.slice(2, -2)}
        </strong>
      );
    }
    if (p.startsWith("`") && p.endsWith("`")) {
      return (
        <code key={i} className="rounded bg-slate-200 px-1 py-0.5 font-mono text-[0.85em] text-indigo-700 dark:bg-slate-700 dark:text-indigo-300">
          {p.slice(1, -1)}
        </code>
      );
    }
    return <span key={i}>{p}</span>;
  });
}

const QUICK_PROMPTS: Record<string, string[]> = {
  mcq: ["Explain this question", "Give me a hint", "Explain the answer"],
  coding: ["Explain the problem", "Give me a hint", "Show the approach"],
  none: ["What is a hash table?", "Difference between TCP and UDP", "Explain normalization"],
};

export function Practi() {
  const { practiCtx } = useApp();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [typing, setTyping] = useState(false);
  const [unread, setUnread] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(0);
  const greetedCtxRef = useRef<string>("");

  const nextId = () => `m${++idRef.current}`;

  // Seed a greeting the first time the panel opens.
  useEffect(() => {
    if (open && messages.length === 0) {
      setMessages([{ id: nextId(), role: "practi", text: practiGreeting(practiCtx) }]);
    }
    if (open) setUnread(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  // When the user moves to a new question while the panel is open, PRACTI
  // proactively offers help about the new context.
  useEffect(() => {
    const key =
      practiCtx.kind === "mcq"
        ? "mcq:" + practiCtx.question.id
        : practiCtx.kind === "coding"
        ? "coding:" + practiCtx.question.id
        : "none";
    if (key === greetedCtxRef.current) return;
    greetedCtxRef.current = key;
    if (!open || messages.length === 0) return;
    if (practiCtx.kind === "mcq") {
      pushPracti(`📘 New question loaded (${practiCtx.question.subject} · ${practiCtx.question.topic}). Ask me to "explain this question" or for a "hint".`);
    } else if (practiCtx.kind === "coding") {
      pushPracti(`💻 Now on **${practiCtx.question.title}** (${practiCtx.question.language}). Want the "approach" or a "hint"?`);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [practiCtx]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    // Guard: not all environments implement Element.scrollTo.
    if (typeof el.scrollTo === "function") {
      el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
    } else {
      el.scrollTop = el.scrollHeight;
    }
  }, [messages, typing]);

  function pushPracti(text: string) {
    setMessages((m) => [...m, { id: nextId(), role: "practi", text }]);
    if (!open) setUnread(true);
  }

  function send(text: string) {
    const q = text.trim();
    if (!q) return;
    setMessages((m) => [...m, { id: nextId(), role: "user", text: q }]);
    setInput("");
    setTyping(true);
    // Small delay to feel conversational.
    const answer = askPracti(q, practiCtx);
    const delay = Math.min(900, 300 + answer.length * 2);
    setTimeout(() => {
      setTyping(false);
      setMessages((m) => [...m, { id: nextId(), role: "practi", text: answer }]);
    }, delay);
  }

  const quick = QUICK_PROMPTS[practiCtx.kind] ?? QUICK_PROMPTS.none;

  return (
    <>
      {/* Floating launcher */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Open PRACTI assistant"
          className="group fixed bottom-5 right-5 z-50 flex items-center gap-2 rounded-full bg-gradient-to-br from-indigo-600 to-violet-600 px-4 py-3 text-white shadow-xl shadow-indigo-600/30 transition-transform hover:scale-105 active:scale-95"
        >
          <span className="relative flex h-6 w-6 items-center justify-center">
            <PractiFace />
            {unread && (
              <span className="absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full bg-rose-400 ring-2 ring-indigo-600" />
            )}
          </span>
          <span className="text-sm font-bold tracking-wide">PRACTI</span>
        </button>
      )}

      {/* Chat panel */}
      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-end p-0 sm:bottom-5 sm:right-5 sm:inset-auto sm:p-0">
          {/* mobile scrim */}
          <div
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm sm:hidden"
            onClick={() => setOpen(false)}
          />
          <div className="relative flex h-[85vh] w-full flex-col overflow-hidden rounded-t-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-700 dark:bg-slate-900 sm:h-[560px] sm:w-[380px] sm:rounded-2xl">
            {/* header */}
            <div className="flex items-center justify-between gap-3 bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-3 text-white">
              <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white/15">
                  <PractiFace />
                </span>
                <div className="leading-tight">
                  <div className="text-sm font-bold">PRACTI</div>
                  <div className="flex items-center gap-1 text-[11px] text-indigo-100">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-300" /> Study assistant · online
                  </div>
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                aria-label="Close PRACTI"
                className="rounded-lg p-1.5 text-indigo-100 transition-colors hover:bg-white/15 hover:text-white"
              >
                <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
                  <path d="M6 6l12 12M18 6L6 18" />
                </svg>
              </button>
            </div>

            {/* messages */}
            <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto bg-slate-50 px-3 py-4 dark:bg-slate-950">
              {messages.map((m) => (
                <div key={m.id} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                  {m.role === "practi" && (
                    <span className="mr-2 mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 text-white">
                      <PractiFace small />
                    </span>
                  )}
                  <div
                    className={cn(
                      "max-w-[80%] whitespace-pre-wrap rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed",
                      m.role === "user"
                        ? "rounded-br-md bg-indigo-600 text-white"
                        : "rounded-bl-md bg-white text-slate-700 shadow-sm ring-1 ring-slate-200 dark:bg-slate-800 dark:text-slate-200 dark:ring-slate-700"
                    )}
                  >
                    <RichText text={m.text} />
                  </div>
                </div>
              ))}
              {typing && (
                <div className="flex justify-start">
                  <span className="mr-2 mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 text-white">
                    <PractiFace small />
                  </span>
                  <div className="flex items-center gap-1 rounded-2xl rounded-bl-md bg-white px-4 py-3 shadow-sm ring-1 ring-slate-200 dark:bg-slate-800 dark:ring-slate-700">
                    <Dot /> <Dot d={150} /> <Dot d={300} />
                  </div>
                </div>
              )}
            </div>

            {/* quick prompts */}
            <div className="flex flex-wrap gap-1.5 border-t border-slate-200 bg-white px-3 py-2 dark:border-slate-700 dark:bg-slate-900">
              {quick.map((p) => (
                <button
                  key={p}
                  onClick={() => send(p)}
                  className="rounded-full border border-indigo-200 bg-indigo-50 px-2.5 py-1 text-xs font-medium text-indigo-700 transition-colors hover:bg-indigo-100 dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-300 dark:hover:bg-indigo-500/20"
                >
                  {p}
                </button>
              ))}
            </div>

            {/* input */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                send(input);
              }}
              className="flex items-center gap-2 border-t border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900"
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask PRACTI anything…"
                aria-label="Message PRACTI"
                className="flex-1 rounded-full border border-slate-300 bg-slate-50 px-4 py-2 text-sm text-slate-800 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-100 dark:focus:ring-indigo-500/30"
              />
              <button
                type="submit"
                disabled={!input.trim()}
                aria-label="Send"
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-indigo-600 text-white transition-colors hover:bg-indigo-500 disabled:opacity-40"
              >
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" />
                </svg>
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}

function Dot({ d = 0 }: { d?: number }) {
  return (
    <span
      className="h-2 w-2 animate-bounce rounded-full bg-slate-400 dark:bg-slate-500"
      style={{ animationDelay: `${d}ms` }}
    />
  );
}

/* A tiny friendly robot face icon. */
function PractiFace({ small = false }: { small?: boolean }) {
  const s = small ? 16 : 20;
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" aria-hidden>
      <rect x="4" y="7" width="16" height="12" rx="4" fill="currentColor" opacity="0.18" />
      <rect x="4" y="7" width="16" height="12" rx="4" stroke="currentColor" strokeWidth="1.6" />
      <circle cx="9.5" cy="13" r="1.6" fill="currentColor" />
      <circle cx="14.5" cy="13" r="1.6" fill="currentColor" />
      <path d="M12 7V3.5M12 3.5a1.3 1.3 0 100-.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <circle cx="12" cy="3" r="1.3" fill="currentColor" />
    </svg>
  );
}
