import { useEffect, useMemo, useRef, useState } from "react";
import { useApp } from "../context/AppContext";
import { Button, Card, DifficultyBadge } from "./ui";
import { cn } from "../utils/cn";
import { CodeEditor } from "./CodeEditor";
import { Modal } from "./MCQTest";
import { Toasts, useToasts } from "./Toasts";
import type { CodingQuestion, CodingAnswerState, TestConfig } from "../data/types";
import { buildCodingTest, evaluateCode, runSamples } from "../lib/engine";
import { buildCodingResult } from "../lib/results";
import { useCountdown, formatTime } from "../hooks/useCountdown";
import { saveResult, saveActiveTest, loadActiveTest, clearActiveTest, markSolved } from "../lib/storage";

interface Persisted {
  kind: "coding";
  runId: string;
  config: TestConfig;
  questions: CodingQuestion[];
  codes: string[];
  answers: CodingAnswerState[];
  execTimes: number[];
  current: number;
  timeLeft: number;
}

function readConfig(): TestConfig | null {
  try {
    const raw = sessionStorage.getItem("csect_run_config");
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function readRunId(): string {
  return sessionStorage.getItem("csect_run_id") || "";
}

export function CodingTest() {
  const { navigate, setLastResult, setReviewData, refreshResults, setPractiCtx } = useApp();
  const { toasts, push } = useToasts();
  const config = useMemo(() => readConfig(), []);
  const runId = useMemo(() => readRunId(), []);

  const [questions, setQuestions] = useState<CodingQuestion[]>([]);
  const [codes, setCodes] = useState<string[]>([]);
  const [answers, setAnswers] = useState<CodingAnswerState[]>([]);
  const [execTimes, setExecTimes] = useState<number[]>([]);
  const [current, setCurrent] = useState(0);
  const [initialTime, setInitialTime] = useState(0);
  const [output, setOutput] = useState<string>("");
  const [running, setRunning] = useState(false);
  const [tab, setTab] = useState<"problem" | "editor">("editor");
  const [confirmSubmit, setConfirmSubmit] = useState(false);
  const submittedRef = useRef(false);

  useEffect(() => {
    if (!config) {
      navigate("home");
      return;
    }
    // Restore ONLY when the saved in-progress test belongs to THIS run (same
    // runId). A deliberate "Start Test" always creates a new runId, so an
    // unfinished previous test is never restored — you get brand-new questions.
    // On a page refresh the runId is unchanged, so the saved test is restored.
    const saved = loadActiveTest<Persisted>();
    const validSaved =
      !!runId &&
      !!saved &&
      saved.runId === runId &&
      saved.kind === "coding" &&
      JSON.stringify(saved.config) === JSON.stringify(config) &&
      Array.isArray(saved.questions) &&
      saved.questions.length > 0 &&
      Array.isArray(saved.answers) &&
      saved.answers.length === saved.questions.length &&
      Array.isArray(saved.codes) &&
      saved.codes.length === saved.questions.length &&
      Array.isArray(saved.execTimes) &&
      saved.execTimes.length === saved.questions.length &&
      typeof saved.current === "number" &&
      saved.current >= 0 &&
      saved.current < saved.questions.length &&
      saved.questions.every((qq) => qq && typeof qq.starterCode === "string" && Array.isArray(qq.samples));

    if (validSaved) {
      setQuestions(saved.questions);
      setCodes(saved.codes);
      setAnswers(saved.answers);
      setExecTimes(saved.execTimes);
      setCurrent(Math.min(saved.current, saved.questions.length - 1));
      setInitialTime(saved.timeLeft);
      push("Restored your in-progress coding test.", "info");
    } else {
      clearActiveTest();
      const qs = buildCodingTest(config);
      setQuestions(qs);
      setCodes(qs.map((q) => q.starterCode));
      setAnswers(qs.map(() => ({ code: "", submitted: false, passed: 0, total: 0, status: "Not Attempted", feedback: "" })));
      setExecTimes(qs.map(() => 0));
      setInitialTime(config.timerMinutes * 60);
      clearActiveTest();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const doSubmit = () => {
    if (submittedRef.current) return;
    submittedRef.current = true;
    const result = buildCodingResult(config!, questions, answers, execTimes);
    saveResult(result);
    refreshResults();
    setLastResult(result);
    setReviewData({ mode: "coding", questions, answers, codes });
    clearActiveTest();
    navigate("result");
  };

  const { secondsLeft } = useCountdown({
    initialSeconds: initialTime,
    active: questions.length > 0 && config?.timerMinutes !== 0,
    onExpire: () => {
      push("Time's up! Auto-submitting your test.", "error");
      setTimeout(doSubmit, 400);
    },
    onWarning: (s) => {
      const label = s >= 600 ? "10 minutes" : s >= 300 ? "5 minutes" : "1 minute";
      push(`${label} remaining.`, "warning");
    },
  });

  useEffect(() => {
    if (!config || !runId || questions.length === 0 || submittedRef.current) return;
    const state: Persisted = {
      kind: "coding", runId, config, questions, codes, answers, execTimes, current,
      timeLeft: config.timerMinutes === 0 ? 0 : secondsLeft,
    };
    saveActiveTest(state);
  }, [codes, answers, execTimes, current, secondsLeft, questions, config, runId]);

  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (!submittedRef.current) { e.preventDefault(); e.returnValue = ""; }
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, []);

  // Keep current index within bounds if questions change.
  useEffect(() => {
    if (questions.length > 0 && current > questions.length - 1) {
      setCurrent(questions.length - 1);
    }
  }, [questions.length, current]);

  // Tell PRACTI which problem (and the user's current code) is on screen.
  useEffect(() => {
    if (questions.length === 0) return;
    const idx = Math.max(0, Math.min(current, questions.length - 1));
    const cq = questions[idx];
    if (cq) {
      setPractiCtx({ kind: "coding", question: cq, code: codes[idx] });
    }
  }, [current, questions, codes, setPractiCtx]);

  // Reset PRACTI context when leaving the coding test.
  useEffect(() => {
    return () => setPractiCtx({ kind: "none" });
  }, [setPractiCtx]);

  if (!config || questions.length === 0) {
    return <div className="py-20 text-center text-slate-500">Loading coding test…</div>;
  }

  // Safety: never let current/answers desync crash the assessment.
  const safeCurrent = Math.max(0, Math.min(current, questions.length - 1));
  const q = questions[safeCurrent];
  const code = codes[safeCurrent] ?? (q ? q.starterCode : "");
  const answer = answers[safeCurrent] ?? { code: "", submitted: false, passed: 0, total: 0, status: "Not Attempted" as const, feedback: "" };
  if (!q) {
    return <div className="py-20 text-center text-slate-500">Loading coding test…</div>;
  }
  const submittedCount = answers.filter((x) => x && x.status !== "Not Attempted").length;

  const setCode = (v: string) => setCodes((prev) => prev.map((c, i) => (i === safeCurrent ? v : c)));
  const resetCode = () => { setCode(q.starterCode); setOutput(""); };

  const handleRun = () => {
    setRunning(true);
    setOutput("");
    setTimeout(() => {
      const start = performance.now();
      const res = runSamples(q, code);
      const elapsed = Math.round(performance.now() - start) + Math.floor(20 + Math.random() * 60);
      setOutput(res + `\n\n⏲ Execution time: ~${elapsed} ms   |   Memory: ~${(2 + Math.random() * 3).toFixed(1)} MB`);
      setRunning(false);
    }, 500);
  };

  const handleSubmitQuestion = () => {
    setRunning(true);
    setTimeout(() => {
      const elapsed = Math.floor(30 + Math.random() * 120);
      const evalResult = evaluateCode(q, code);
      setAnswers((prev) => prev.map((x, i) => (i === safeCurrent ? evalResult : x)));
      setExecTimes((prev) => prev.map((t, i) => (i === safeCurrent ? elapsed : t)));
      if (evalResult.status === "Correct") markSolved(q.id);
      const statusLine =
        evalResult.status === "Correct" ? "✅ Accepted"
        : evalResult.status === "Partially Correct" ? "⚠️ Partially Correct"
        : evalResult.status === "Incorrect" ? "❌ Wrong Answer"
        : "— Not Attempted";
      setOutput(
        `${statusLine}\n\nTest cases passed: ${evalResult.passed}/${evalResult.total}\n` +
        `Status: ${evalResult.status}\n` +
        `Runtime: ~${elapsed} ms   |   Memory: ~${(2 + Math.random() * 3).toFixed(1)} MB\n\n` +
        `Feedback: ${evalResult.feedback}`
      );
      const type = evalResult.status === "Correct" ? "success" : evalResult.status === "Not Attempted" ? "warning" : "info";
      push(`Q${current + 1}: ${evalResult.passed}/${evalResult.total} test cases passed`, type);
      setRunning(false);
    }, 700);
  };

  return (
    <div className="min-h-[calc(100vh-57px)] bg-slate-50 dark:bg-slate-950">
      <Toasts toasts={toasts} />
      {/* top bar */}
      <div className="sticky top-[57px] z-30 border-b border-slate-200 bg-white/90 backdrop-blur dark:border-slate-700 dark:bg-slate-900/90">
        <div className="mx-auto flex max-w-[1400px] items-center justify-between gap-3 px-4 py-2.5 sm:px-6">
          <div className="min-w-0">
            <div className="truncate text-sm font-bold text-slate-900 dark:text-white">{config.language} Coding Assessment</div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Q {current + 1}/{questions.length} · {submittedCount} submitted</div>
          </div>
          <div className="flex items-center gap-2">
            {config.timerMinutes !== 0 && (
              <div className={cn(
                "flex items-center gap-1.5 rounded-lg px-3 py-1.5 font-mono text-sm font-bold tabular-nums",
                secondsLeft <= 60 ? "bg-rose-100 text-rose-700 dark:bg-rose-500/20 dark:text-rose-300" : secondsLeft <= 300 ? "bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300" : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200"
              )}>
                ⏱ {formatTime(secondsLeft)}
              </div>
            )}
            <Button size="sm" variant="success" onClick={() => setConfirmSubmit(true)}>Submit Test</Button>
          </div>
        </div>
        {/* mobile tab switch */}
        <div className="flex border-t border-slate-200 dark:border-slate-700 lg:hidden">
          <button onClick={() => setTab("problem")} className={cn("flex-1 py-2 text-sm font-semibold", tab === "problem" ? "border-b-2 border-indigo-600 text-indigo-600 dark:text-indigo-400" : "text-slate-500")}>Problem</button>
          <button onClick={() => setTab("editor")} className={cn("flex-1 py-2 text-sm font-semibold", tab === "editor" ? "border-b-2 border-indigo-600 text-indigo-600 dark:text-indigo-400" : "text-slate-500")}>Code</button>
        </div>
      </div>

      <div className="mx-auto grid max-w-[1400px] gap-4 px-3 py-4 sm:px-6 lg:grid-cols-2">
        {/* Problem panel */}
        <div className={cn("lg:block", tab === "problem" ? "block" : "hidden")}>
          <Card className="p-5 sm:p-6 lg:max-h-[calc(100vh-140px)] lg:overflow-y-auto">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600 dark:bg-slate-700 dark:text-slate-300">Problem {current + 1}</span>
              <DifficultyBadge difficulty={q.difficulty} />
              <span className="rounded-full bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300">{q.topic}</span>
              {answer.status !== "Not Attempted" && (
                <span className={cn("rounded-full px-2.5 py-1 text-xs font-bold",
                  answer.status === "Correct" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300" :
                  answer.status === "Partially Correct" ? "bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300" :
                  "bg-rose-100 text-rose-700 dark:bg-rose-500/20 dark:text-rose-300"
                )}>{answer.passed}/{answer.total}</span>
              )}
            </div>
            <h2 className="mt-4 text-xl font-bold text-slate-900 dark:text-white">{q.title}</h2>
            <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-slate-700 dark:text-slate-300">{q.statement}</p>

            <Field label="Input Format">{q.inputFormat}</Field>
            <Field label="Output Format">{q.outputFormat}</Field>

            <div className="mt-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Constraints</h3>
              <ul className="mt-1.5 space-y-0.5">
                {q.constraints.map((c, i) => (
                  <li key={i} className="font-mono text-xs text-slate-600 dark:text-slate-400">• {c}</li>
                ))}
              </ul>
            </div>

            {q.samples.map((s, i) => (
              <div key={i} className="mt-4 rounded-xl border border-slate-200 dark:border-slate-700">
                <div className="border-b border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-bold text-slate-500 dark:border-slate-700 dark:bg-slate-800/50 dark:text-slate-400">
                  Example {i + 1}
                </div>
                <div className="grid gap-0 sm:grid-cols-2">
                  <div className="border-b border-slate-200 p-3 sm:border-b-0 sm:border-r dark:border-slate-700">
                    <div className="text-[10px] font-bold uppercase text-slate-400">Input</div>
                    <pre className="mt-1 whitespace-pre-wrap font-mono text-xs text-slate-700 dark:text-slate-300">{s.input}</pre>
                  </div>
                  <div className="p-3">
                    <div className="text-[10px] font-bold uppercase text-slate-400">Output</div>
                    <pre className="mt-1 whitespace-pre-wrap font-mono text-xs text-slate-700 dark:text-slate-300">{s.output}</pre>
                  </div>
                </div>
                {s.explanation && (
                  <div className="border-t border-slate-200 p-3 text-xs text-slate-500 dark:border-slate-700 dark:text-slate-400">
                    <b>Explanation:</b> {s.explanation}
                  </div>
                )}
              </div>
            ))}

            <div className="mt-4 rounded-xl bg-indigo-50 p-3 text-xs text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300">
              🎯 Target time complexity: <b>{q.timeComplexity}</b>
            </div>
          </Card>
        </div>

        {/* Editor panel */}
        <div className={cn("lg:block", tab === "editor" ? "block" : "hidden")}>
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-semibold text-slate-700 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200">
                {config.language}
              </span>
              <span className="text-xs text-slate-400">Language locked to test</span>
            </div>
            <Button variant="ghost" size="sm" onClick={resetCode}>↺ Reset</Button>
          </div>

          <div className="mt-2">
            <CodeEditor value={code} onChange={setCode} language={config.language} />
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            <Button variant="outline" onClick={handleRun} disabled={running}>
              {running ? "Running…" : "▶ Run Code"}
            </Button>
            <Button onClick={handleSubmitQuestion} disabled={running}>
              {running ? "Evaluating…" : "✔ Submit Answer"}
            </Button>
            <div className="ml-auto flex gap-2">
              <Button variant="outline" size="sm" onClick={() => { setCurrent((c) => Math.max(0, c - 1)); setOutput(""); }} disabled={current === 0}>← Prev</Button>
              <Button variant="outline" size="sm" onClick={() => { setCurrent((c) => Math.min(questions.length - 1, c + 1)); setOutput(""); }} disabled={current === questions.length - 1}>Next →</Button>
            </div>
          </div>

          {/* Console */}
          <div className="mt-3 rounded-xl border border-slate-700 bg-[#0d1117]">
            <div className="border-b border-slate-700 px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-slate-400">Console Output</div>
            <pre className="max-h-56 overflow-auto p-3 font-mono text-xs leading-relaxed text-slate-200">
              {output || "Run your code to see sample results, or Submit to evaluate against all test cases.\nHidden test cases are never revealed."}
            </pre>
          </div>

          {/* question palette compact */}
          <div className="mt-3 flex flex-wrap gap-1.5">
            {questions.map((_, i) => (
              <button
                key={i}
                onClick={() => { setCurrent(i); setOutput(""); }}
                className={cn(
                  "h-8 w-8 rounded-lg text-xs font-bold transition-all",
                  i === current ? "bg-indigo-600 text-white ring-2 ring-indigo-400" :
                  answers[i].status === "Correct" ? "bg-emerald-500 text-white" :
                  answers[i].status === "Partially Correct" ? "bg-amber-500 text-white" :
                  answers[i].status === "Incorrect" ? "bg-rose-500 text-white" :
                  "bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300"
                )}
              >{i + 1}</button>
            ))}
          </div>
        </div>
      </div>

      {confirmSubmit && (
        <Modal onClose={() => setConfirmSubmit(false)}>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">Submit entire test?</h3>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            You submitted answers for <b>{submittedCount}</b> of <b>{questions.length}</b> problems.
            {submittedCount < questions.length && " Unsubmitted problems will be scored as not attempted."}
          </p>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Your final score is calculated now. This cannot be undone.</p>
          <div className="mt-5 flex justify-end gap-3">
            <Button variant="outline" onClick={() => setConfirmSubmit(false)}>Keep Working</Button>
            <Button variant="success" onClick={doSubmit}>Submit Test</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mt-4">
      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">{label}</h3>
      <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{children}</p>
    </div>
  );
}
