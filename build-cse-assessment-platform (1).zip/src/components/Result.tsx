import { useMemo, useState } from "react";
import { useApp } from "../context/AppContext";
import { Button, Card, ProgressBar, Stat, DifficultyBadge } from "./ui";
import { cn } from "../utils/cn";
import { analyzeResult } from "../lib/analysis";
import type { TopicPerf } from "../data/types";

export function Result() {
  const { lastResult, navigate, reviewData } = useApp();
  const [showAI, setShowAI] = useState(false);

  const analysis = useMemo(() => (lastResult ? analyzeResult(lastResult) : null), [lastResult]);

  if (!lastResult) {
    return (
      <div className="py-20 text-center">
        <p className="text-slate-500">No result to display.</p>
        <Button className="mt-4" onClick={() => navigate("home")}>Go Home</Button>
      </div>
    );
  }

  const r = lastResult;
  const scoreColor = r.accuracy >= 75 ? "text-emerald-500" : r.accuracy >= 50 ? "text-amber-500" : "text-rose-500";
  const circumference = 2 * Math.PI * 52;

  return (
    <div className="mx-auto max-w-5xl animate-fade-in px-4 py-8 sm:px-6">
      <div className="text-center">
        <span className="inline-flex items-center gap-2 rounded-full bg-indigo-50 px-3 py-1 text-xs font-semibold text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300">
          {r.mode === "coding" ? "Coding Assessment" : "Core CS Assessment"} · Completed
        </span>
        <h1 className="mt-3 text-3xl font-bold text-slate-900 dark:text-white">Your Result</h1>
      </div>

      {/* Score hero */}
      <Card className="mt-6 overflow-hidden p-0">
        <div className="grid gap-0 md:grid-cols-[auto_1fr]">
          <div className="flex flex-col items-center justify-center gap-2 border-b border-slate-200 bg-gradient-to-br from-indigo-50 to-violet-50 p-8 dark:border-slate-700 dark:from-slate-800 dark:to-slate-800/50 md:border-b-0 md:border-r">
            <div className="relative h-32 w-32">
              <svg className="h-32 w-32 -rotate-90" viewBox="0 0 120 120">
                <circle cx="60" cy="60" r="52" fill="none" strokeWidth="12" className="stroke-slate-200 dark:stroke-slate-700" />
                <circle
                  cx="60" cy="60" r="52" fill="none" strokeWidth="12" strokeLinecap="round"
                  className={r.accuracy >= 75 ? "stroke-emerald-500" : r.accuracy >= 50 ? "stroke-amber-500" : "stroke-rose-500"}
                  strokeDasharray={circumference}
                  strokeDashoffset={circumference - (circumference * r.accuracy) / 100}
                  style={{ transition: "stroke-dashoffset 1s ease-out" }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className={cn("text-3xl font-extrabold", scoreColor)}>{r.scoreOutOf10.toFixed(1)}</span>
                <span className="text-xs font-medium text-slate-400">out of 10</span>
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-slate-900 dark:text-white">{r.accuracy}%</div>
              <div className="text-xs text-slate-500">Accuracy</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 p-6 sm:grid-cols-4">
            <Stat label="Questions" value={r.total} />
            <Stat label="Correct" value={<span className="text-emerald-500">{r.correct}</span>} />
            <Stat label="Incorrect" value={<span className="text-rose-500">{r.incorrect}</span>} />
            <Stat label="Unattempted" value={<span className="text-slate-400">{r.unattempted}</span>} />
            {r.mode === "coding" && (
              <>
                <Stat label="Test Cases" value={`${r.testCasesPassed}/${r.testCasesTotal}`} />
                <Stat label="Avg Runtime" value={`${r.avgExecMs} ms`} />
                <Stat label="Score" value={`${r.correct}/${r.total}`} sub="fully solved" />
                <Stat label="Difficulty" value={String(r.config.difficulty).replace("Company Screening", "Screening")} />
              </>
            )}
          </div>
        </div>
      </Card>

      {/* Technical Performance bands */}
      {analysis && (
        <div className="mt-6">
          <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">Technical Performance</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {analysis.performanceBands.map((b) => (
              <Card key={b.label} className="p-4">
                <div className="text-sm font-medium text-slate-500 dark:text-slate-400">{b.label}</div>
                <div className={cn("mt-1 text-lg font-bold",
                  b.band === "Strong" ? "text-emerald-500" :
                  b.band === "Good" ? "text-indigo-500" :
                  b.band === "Needs Practice" ? "text-amber-500" : "text-rose-500"
                )}>{b.band}</div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Topic + Difficulty */}
      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <Card className="p-5">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">Topic Performance</h2>
          <div className="mt-4 space-y-3">
            {[...r.topicPerf].sort((a, b) => (b.correct / b.total) - (a.correct / a.total)).map((t) => (
              <PerfRow key={t.topic} tp={t} />
            ))}
            {r.topicPerf.length === 0 && <p className="text-sm text-slate-400">No topic data.</p>}
          </div>
        </Card>
        <Card className="p-5">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">Difficulty Performance</h2>
          <div className="mt-4 space-y-4">
            {r.difficultyPerf.map((d) => {
              const pct = d.total ? Math.round((d.correct / d.total) * 100) : 0;
              return (
                <div key={d.difficulty}>
                  <div className="mb-1.5 flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2"><DifficultyBadge difficulty={d.difficulty} /></span>
                    <span className="font-semibold text-slate-700 dark:text-slate-300">{pct}% ({d.correct}/{d.total})</span>
                  </div>
                  <ProgressBar value={pct} />
                </div>
              );
            })}
            {r.difficultyPerf.length === 0 && <p className="text-sm text-slate-400">No difficulty data.</p>}
          </div>
        </Card>
      </div>

      {/* AI Analysis */}
      <Card className="mt-6 border-violet-200 bg-gradient-to-br from-violet-50/50 to-indigo-50/30 p-5 dark:border-violet-500/30 dark:from-violet-500/5 dark:to-indigo-500/5">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="flex items-center gap-2 text-lg font-bold text-slate-900 dark:text-white">
              <span>🤖</span> AI Performance Analysis
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">Personalized insights generated from your actual answers.</p>
          </div>
          {!showAI && <Button onClick={() => setShowAI(true)}>Generate</Button>}
        </div>

        {showAI && analysis && (
          <div className="mt-5 grid gap-4 animate-fade-in md:grid-cols-3">
            <AnalysisCol title="Your Strengths" icon="💪" color="emerald" items={analysis.strengths} />
            <AnalysisCol title="Areas to Improve" icon="🎯" color="amber" items={analysis.improvements} />
            <AnalysisCol title="Recommended Practice" icon="📌" color="indigo" items={analysis.recommendations} />
          </div>
        )}
      </Card>

      {/* Actions */}
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        {reviewData ? (
          <Button size="lg" onClick={() => navigate("review")}>Review Answers</Button>
        ) : null}
        <Button size="lg" variant="outline" onClick={() => navigate("dashboard")}>View Dashboard</Button>
        <Button size="lg" variant="secondary" onClick={() => navigate("setup")}>Take Another Test</Button>
        <Button size="lg" variant="ghost" onClick={() => navigate("home")}>Home</Button>
      </div>
    </div>
  );
}

function PerfRow({ tp }: { tp: TopicPerf }) {
  const pct = tp.total ? Math.round((tp.correct / tp.total) * 100) : 0;
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-sm">
        <span className="font-medium text-slate-700 dark:text-slate-300">{tp.topic}</span>
        <span className={cn("font-semibold", pct >= 75 ? "text-emerald-500" : pct >= 50 ? "text-amber-500" : "text-rose-500")}>{pct}%</span>
      </div>
      <ProgressBar value={pct} />
    </div>
  );
}

function AnalysisCol({ title, icon, color, items }: { title: string; icon: string; color: string; items: string[] }) {
  const colors: Record<string, string> = {
    emerald: "text-emerald-600 dark:text-emerald-400",
    amber: "text-amber-600 dark:text-amber-400",
    indigo: "text-indigo-600 dark:text-indigo-400",
  };
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-800/50">
      <h3 className={cn("flex items-center gap-1.5 text-sm font-bold", colors[color])}>
        <span>{icon}</span> {title}
      </h3>
      <ul className="mt-3 space-y-2">
        {items.map((it, i) => (
          <li key={i} className="text-sm leading-snug text-slate-600 dark:text-slate-300">• {it}</li>
        ))}
      </ul>
    </div>
  );
}
