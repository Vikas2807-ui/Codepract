import { useEffect, useMemo, useState } from "react";
import { useApp } from "../context/AppContext";
import { Button, Card, DifficultyBadge } from "./ui";
import { cn } from "../utils/cn";
import { CodeEditor } from "./CodeEditor";
import { SUBJECTS, CODING_LANGUAGES } from "../data/subjects";
import { getSubjectPool } from "../data/mcqPool";
import { CODING_BANK } from "../data/codingBank";
import { shuffle, randomizeOptions, evaluateCode, runSamples } from "../lib/engine";
import { computeWeakTopics } from "../lib/analysis";
import type { MCQQuestion, CodingQuestion, Difficulty } from "../data/types";
import { markSolved } from "../lib/storage";

export function Practice() {
  const { results } = useApp();
  const [mode, setMode] = useState<"mcq" | "coding">("mcq");
  const [subject, setSubject] = useState<string>("All Subjects");
  const [language, setLanguage] = useState<string>("Python");
  const [diff, setDiff] = useState<Difficulty | "Any">("Any");
  const [started, setStarted] = useState(false);
  const [weakMode, setWeakMode] = useState(false);

  const weakTopics = useMemo(() => computeWeakTopics(results).filter((t) => t.pct < 60).map((t) => t.topic), [results]);

  const startNormal = () => { setWeakMode(false); setStarted(true); };
  const startWeak = () => { setWeakMode(true); setMode("mcq"); setStarted(true); };

  if (started) {
    return (
      <PracticeRunner
        mode={mode}
        subject={subject}
        language={language}
        diff={diff}
        weakTopics={weakMode ? weakTopics : null}
        onExit={() => setStarted(false)}
      />
    );
  }

  return (
    <div className="mx-auto max-w-3xl animate-fade-in px-4 py-8 sm:px-6">
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white sm:text-3xl">Practice Mode</h1>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
        Unlimited questions with immediate explanations, retry and no timer. Nothing is scored — just learn.
      </p>

      {weakTopics.length > 0 && (
        <Card className="mt-6 border-amber-200 bg-amber-50/50 p-5 dark:border-amber-500/30 dark:bg-amber-500/5">
          <h2 className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">🎯 Practice Weak Areas</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Based on your history, focus on: <b>{weakTopics.slice(0, 4).join(", ")}</b>
          </p>
          <Button className="mt-3" onClick={startWeak}>Practice Weak Areas</Button>
        </Card>
      )}

      <Card className="mt-6 p-5">
        <h2 className="font-bold text-slate-900 dark:text-white">Custom Practice</h2>
        <div className="mt-4 flex gap-2">
          <ToggleBtn active={mode === "mcq"} onClick={() => setMode("mcq")}>MCQ</ToggleBtn>
          <ToggleBtn active={mode === "coding"} onClick={() => setMode("coding")}>Coding</ToggleBtn>
        </div>

        {mode === "mcq" ? (
          <div className="mt-4">
            <Label>Subject</Label>
            <select value={subject} onChange={(e) => setSubject(e.target.value)} className={selectCls}>
              <option>All Subjects</option>
              {SUBJECTS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
        ) : (
          <div className="mt-4">
            <Label>Language</Label>
            <select value={language} onChange={(e) => setLanguage(e.target.value)} className={selectCls}>
              {CODING_LANGUAGES.map((l) => <option key={l.name}>{l.name}</option>)}
            </select>
          </div>
        )}

        <div className="mt-4">
          <Label>Difficulty</Label>
          <div className="mt-1 flex flex-wrap gap-2">
            {(["Any", "Easy", "Medium", "Hard"] as const).map((d) => (
              <button key={d} onClick={() => setDiff(d)}
                className={cn("rounded-lg border px-3 py-1.5 text-sm font-semibold",
                  diff === d ? "border-indigo-500 bg-indigo-600 text-white" : "border-slate-300 bg-white text-slate-700 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200")}>
                {d}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-5 flex gap-3">
          <Button onClick={startNormal}>Start Practice</Button>
          <Button variant="outline" onClick={startNormal}>🎲 Random Question</Button>
        </div>
      </Card>
    </div>
  );
}

function PracticeRunner({
  mode, subject, language, diff, weakTopics, onExit,
}: {
  mode: "mcq" | "coding";
  subject: string;
  language: string;
  diff: Difficulty | "Any";
  weakTopics: string[] | null;
  onExit: () => void;
}) {
  const pool = useMemo(() => {
    if (mode === "mcq") {
      // Use the full generated pool (thousands of questions) so practice is rich.
      let p = getSubjectPool(weakTopics && weakTopics.length ? "All Subjects" : subject);
      if (weakTopics && weakTopics.length) p = p.filter((q) => weakTopics.includes(q.topic));
      if (diff !== "Any") p = p.filter((q) => q.difficulty === diff);
      return shuffle(p);
    } else {
      let p = CODING_BANK.filter((q) => q.language === language);
      if (diff !== "Any") p = p.filter((q) => q.difficulty === diff);
      return shuffle(p);
    }
  }, [mode, subject, language, diff, weakTopics]);

  const [idx, setIdx] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [correct, setCorrect] = useState(0);

  if (pool.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <p className="text-slate-500">No questions match this selection.</p>
        <Button className="mt-4" onClick={onExit}>Back</Button>
      </div>
    );
  }

  const item = pool[idx % pool.length];
  const next = () => setIdx((i) => i + 1);

  return (
    <div className="mx-auto max-w-3xl animate-fade-in px-4 py-8 sm:px-6">
      <div className="flex items-center justify-between">
        <button onClick={onExit} className="text-sm font-medium text-slate-500 hover:text-indigo-600 dark:text-slate-400">← Exit practice</button>
        <span className="text-sm font-semibold text-slate-500 dark:text-slate-400">Solved {correct}/{attempts}</span>
      </div>

      {mode === "mcq" ? (
        <MCQPractice
          key={idx}
          question={item as MCQQuestion}
          onAnswer={(ok) => { setAttempts((a) => a + 1); if (ok) setCorrect((c) => c + 1); }}
          onNext={next}
        />
      ) : (
        <CodingPractice
          key={idx}
          question={item as CodingQuestion}
          onAnswer={(ok) => { setAttempts((a) => a + 1); if (ok) setCorrect((c) => c + 1); }}
          onNext={next}
        />
      )}
    </div>
  );
}

function MCQPractice({ question, onAnswer, onNext }: { question: MCQQuestion; onAnswer: (ok: boolean) => void; onNext: () => void }) {
  const q = useMemo(() => randomizeOptions(question), [question]);
  const [selected, setSelected] = useState<number | null>(null);
  const [revealed, setRevealed] = useState(false);
  const { setPractiCtx } = useApp();

  // Keep PRACTI aware of the current practice question + whether it's revealed.
  useEffect(() => {
    setPractiCtx({ kind: "mcq", question: q, selectedIndex: selected, revealed });
  }, [q, selected, revealed, setPractiCtx]);
  useEffect(() => () => setPractiCtx({ kind: "none" }), [setPractiCtx]);

  const submit = (i: number) => {
    if (revealed) return;
    setSelected(i);
    setRevealed(true);
    onAnswer(i === q.correctIndex);
  };

  return (
    <Card className="mt-5 p-5 sm:p-6">
      <div className="flex flex-wrap items-center gap-2">
        <DifficultyBadge difficulty={q.difficulty} />
        <span className="rounded-full bg-indigo-50 px-2.5 py-0.5 text-xs font-semibold text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300">{q.subject}</span>
        <span className="text-xs text-slate-400">{q.topic}</span>
      </div>
      <p className="mt-4 text-base font-medium text-slate-900 dark:text-white">{q.question}</p>
      {q.code && <pre className="mt-3 overflow-x-auto rounded-lg bg-slate-900 p-3 text-xs text-slate-100"><code>{q.code}</code></pre>}
      <div className="mt-5 space-y-2.5">
        {q.options.map((opt, i) => {
          const isAnswer = i === q.correctIndex;
          const isSel = i === selected;
          return (
            <button key={i} onClick={() => submit(i)} disabled={revealed}
              className={cn("flex w-full items-center gap-3 rounded-xl border p-3.5 text-left text-sm transition-all",
                !revealed && "hover:border-indigo-300 hover:bg-slate-50 dark:hover:border-indigo-500/50 border-slate-200 dark:border-slate-700",
                revealed && isAnswer && "border-emerald-400 bg-emerald-50 dark:border-emerald-500/40 dark:bg-emerald-500/10",
                revealed && isSel && !isAnswer && "border-rose-400 bg-rose-50 dark:border-rose-500/40 dark:bg-rose-500/10",
                revealed && !isAnswer && !isSel && "border-slate-200 opacity-60 dark:border-slate-700"
              )}>
              <span className="font-bold text-slate-500">{String.fromCharCode(65 + i)}</span>
              <span className="text-slate-800 dark:text-slate-200">{opt}</span>
              {revealed && isAnswer && <span className="ml-auto text-xs font-bold text-emerald-600 dark:text-emerald-400">✓</span>}
              {revealed && isSel && !isAnswer && <span className="ml-auto text-xs font-bold text-rose-600 dark:text-rose-400">✗</span>}
            </button>
          );
        })}
      </div>
      {revealed && (
        <div className="mt-4 animate-fade-in rounded-xl bg-slate-50 p-4 text-sm text-slate-600 dark:bg-slate-800/50 dark:text-slate-300">
          <b className="text-slate-900 dark:text-white">Explanation:</b> {q.explanation}
        </div>
      )}
      <div className="mt-5 flex justify-end gap-2">
        {revealed && <Button variant="outline" onClick={() => { setSelected(null); setRevealed(false); }}>↺ Retry</Button>}
        <Button onClick={onNext}>Next Question →</Button>
      </div>
    </Card>
  );
}

function CodingPractice({ question: q, onAnswer, onNext }: { question: CodingQuestion; onAnswer: (ok: boolean) => void; onNext: () => void }) {
  const [code, setCode] = useState(q.starterCode);
  const [output, setOutput] = useState("");
  const [done, setDone] = useState(false);
  const { setPractiCtx } = useApp();

  // Keep PRACTI aware of the current coding practice problem + code.
  useEffect(() => {
    setPractiCtx({ kind: "coding", question: q, code });
  }, [q, code, setPractiCtx]);
  useEffect(() => () => setPractiCtx({ kind: "none" }), [setPractiCtx]);

  const run = () => setOutput(runSamples(q, code));
  const submit = () => {
    const res = evaluateCode(q, code);
    setOutput(`${res.status} — ${res.passed}/${res.total} test cases\n\n${res.feedback}`);
    if (!done) { onAnswer(res.status === "Correct"); setDone(true); }
    if (res.status === "Correct") markSolved(q.id);
  };

  return (
    <Card className="mt-5 p-5 sm:p-6">
      <div className="flex flex-wrap items-center gap-2">
        <DifficultyBadge difficulty={q.difficulty} />
        <span className="text-xs text-slate-400">{q.language} · {q.topic}</span>
      </div>
      <h2 className="mt-3 text-lg font-bold text-slate-900 dark:text-white">{q.title}</h2>
      <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">{q.statement}</p>
      <div className="mt-3 rounded-lg border border-slate-200 p-3 text-xs dark:border-slate-700">
        <b>Example:</b> Input <code className="rounded bg-slate-100 px-1 dark:bg-slate-800">{q.samples[0].input.replace(/\n/g, " / ")}</code> → Output <code className="rounded bg-slate-100 px-1 dark:bg-slate-800">{q.samples[0].output}</code>
      </div>
      <div className="mt-3">
        <CodeEditor value={code} onChange={setCode} language={q.language} />
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <Button variant="outline" onClick={run}>▶ Run</Button>
        <Button onClick={submit}>✔ Submit</Button>
        <Button variant="ghost" onClick={() => { setCode(q.starterCode); setOutput(""); }}>↺ Reset</Button>
      </div>
      {output && (
        <pre className="mt-3 whitespace-pre-wrap rounded-lg bg-slate-900 p-3 text-xs text-slate-100">{output}</pre>
      )}
      {done && (
        <div className="mt-3 animate-fade-in rounded-lg bg-indigo-50 p-3 text-sm text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300">
          <b>Better approach:</b> {q.betterApproach}
        </div>
      )}
      <div className="mt-4 flex justify-end">
        <Button onClick={onNext}>Next Question →</Button>
      </div>
    </Card>
  );
}

function ToggleBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={cn("rounded-lg px-4 py-2 text-sm font-semibold transition-colors",
      active ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300")}>
      {children}
    </button>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <label className="text-xs font-bold uppercase tracking-wider text-slate-400">{children}</label>;
}

const selectCls = "mt-1 w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm font-medium text-slate-700 focus-visible:outline-2 focus-visible:outline-indigo-500 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200";
