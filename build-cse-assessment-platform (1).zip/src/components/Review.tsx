import { useState } from "react";
import { useApp } from "../context/AppContext";
import { Button, Card, DifficultyBadge } from "./ui";
import { cn } from "../utils/cn";
import { CodeEditor } from "./CodeEditor";
import type { MCQQuestion, MCQAnswerState, CodingQuestion, CodingAnswerState } from "../data/types";

type MCQReview = { mode: "mcq"; questions: MCQQuestion[]; answers: MCQAnswerState[] };
type CodingReview = { mode: "coding"; questions: CodingQuestion[]; answers: CodingAnswerState[]; codes: string[] };

export function Review() {
  const { reviewData, navigate } = useApp();
  const [filter, setFilter] = useState<"all" | "correct" | "incorrect">("all");

  if (!reviewData) {
    return (
      <div className="py-20 text-center">
        <p className="text-slate-500">Nothing to review.</p>
        <Button className="mt-4" onClick={() => navigate("home")}>Go Home</Button>
      </div>
    );
  }

  const data = reviewData as MCQReview | CodingReview;

  return (
    <div className="mx-auto max-w-4xl animate-fade-in px-4 py-8 sm:px-6">
      <button onClick={() => navigate("result")} className="mb-4 text-sm font-medium text-slate-500 hover:text-indigo-600 dark:text-slate-400">
        ← Back to result
      </button>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Review Answers</h1>
        {data.mode === "mcq" && (
          <div className="flex gap-1.5">
            {(["all", "correct", "incorrect"] as const).map((f) => (
              <button key={f} onClick={() => setFilter(f)}
                className={cn("rounded-lg px-3 py-1.5 text-sm font-semibold capitalize",
                  filter === f ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300")}>
                {f}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="mt-6 space-y-4">
        {data.mode === "mcq"
          ? data.questions.map((q, i) => {
              const a = data.answers[i];
              const attempted = a.selectedIndex !== null;
              const isCorrect = attempted && a.selectedIndex === q.correctIndex;
              if (filter === "correct" && !isCorrect) return null;
              if (filter === "incorrect" && isCorrect) return null;
              return <MCQReviewCard key={q.id} index={i} q={q} a={a} attempted={attempted} isCorrect={isCorrect} />;
            })
          : data.questions.map((q, i) => (
              <CodingReviewCard key={q.id} index={i} q={q} a={(data as CodingReview).answers[i]} code={(data as CodingReview).codes[i]} />
            ))}
      </div>

      <div className="mt-8 flex justify-center gap-3">
        <Button variant="outline" onClick={() => navigate("result")}>Back to Result</Button>
        <Button onClick={() => navigate("setup")}>Take Another Test</Button>
      </div>
    </div>
  );
}

function MCQReviewCard({ index, q, a, attempted, isCorrect }: { index: number; q: MCQQuestion; a: MCQAnswerState; attempted: boolean; isCorrect: boolean }) {
  return (
    <Card className="p-5">
      <div className="flex flex-wrap items-center gap-2">
        <span className="rounded-lg bg-slate-100 px-2 py-0.5 text-xs font-bold text-slate-600 dark:bg-slate-700 dark:text-slate-300">Q{index + 1}</span>
        <DifficultyBadge difficulty={q.difficulty} />
        <span className="rounded-full bg-indigo-50 px-2 py-0.5 text-xs font-semibold text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300">{q.subject}</span>
        <span className="text-xs text-slate-400">{q.topic}</span>
        <span className={cn("ml-auto rounded-full px-2.5 py-0.5 text-xs font-bold",
          !attempted ? "bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400" :
          isCorrect ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300" :
          "bg-rose-100 text-rose-700 dark:bg-rose-500/20 dark:text-rose-300"
        )}>{!attempted ? "Unattempted" : isCorrect ? "Correct" : "Incorrect"}</span>
      </div>
      <p className="mt-3 font-medium text-slate-900 dark:text-white">{q.question}</p>
      {q.code && <pre className="mt-3 overflow-x-auto rounded-lg bg-slate-900 p-3 text-xs text-slate-100"><code>{q.code}</code></pre>}
      <div className="mt-3 space-y-2">
        {q.options.map((opt, i) => {
          const isAnswer = i === q.correctIndex;
          const isUser = i === a.selectedIndex;
          return (
            <div key={i} className={cn("flex items-center gap-2 rounded-lg border p-2.5 text-sm",
              isAnswer ? "border-emerald-400 bg-emerald-50 dark:border-emerald-500/40 dark:bg-emerald-500/10" :
              isUser ? "border-rose-400 bg-rose-50 dark:border-rose-500/40 dark:bg-rose-500/10" :
              "border-slate-200 dark:border-slate-700"
            )}>
              <span className="font-bold text-slate-500">{String.fromCharCode(65 + i)}</span>
              <span className="text-slate-800 dark:text-slate-200">{opt}</span>
              {isAnswer && <span className="ml-auto text-xs font-bold text-emerald-600 dark:text-emerald-400">✓ Correct</span>}
              {isUser && !isAnswer && <span className="ml-auto text-xs font-bold text-rose-600 dark:text-rose-400">Your answer</span>}
            </div>
          );
        })}
      </div>
      <div className="mt-3 rounded-lg bg-slate-50 p-3 text-sm text-slate-600 dark:bg-slate-800/50 dark:text-slate-300">
        <b className="text-slate-900 dark:text-white">Explanation:</b> {q.explanation}
      </div>
    </Card>
  );
}

function CodingReviewCard({ index, q, a, code }: { index: number; q: CodingQuestion; a: CodingAnswerState; code: string }) {
  const [showCode, setShowCode] = useState(false);
  const failedCategory =
    a.status === "Not Attempted" ? "Not attempted" :
    a.status === "Correct" ? "None — all categories passed" :
    a.passed < a.total * 0.5 ? "Core logic / main test cases" : "Edge cases (empty, negative, duplicate or boundary inputs)";

  return (
    <Card className="p-5">
      <div className="flex flex-wrap items-center gap-2">
        <span className="rounded-lg bg-slate-100 px-2 py-0.5 text-xs font-bold text-slate-600 dark:bg-slate-700 dark:text-slate-300">P{index + 1}</span>
        <DifficultyBadge difficulty={q.difficulty} />
        <span className="text-xs text-slate-400">{q.topic}</span>
        <span className={cn("ml-auto rounded-full px-2.5 py-0.5 text-xs font-bold",
          a.status === "Not Attempted" ? "bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400" :
          a.status === "Correct" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300" :
          a.status === "Partially Correct" ? "bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300" :
          "bg-rose-100 text-rose-700 dark:bg-rose-500/20 dark:text-rose-300"
        )}>{a.status === "Not Attempted" ? "Not attempted" : `${a.passed}/${a.total} passed`}</span>
      </div>
      <h3 className="mt-3 font-bold text-slate-900 dark:text-white">{q.title}</h3>

      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        <InfoBox label="Status">{a.status}</InfoBox>
        <InfoBox label="Failed test-case category">{failedCategory}</InfoBox>
      </div>

      {a.feedback && (
        <div className="mt-3 rounded-lg bg-slate-50 p-3 text-sm text-slate-600 dark:bg-slate-800/50 dark:text-slate-300">
          <b className="text-slate-900 dark:text-white">Feedback:</b> {a.feedback}
        </div>
      )}
      <div className="mt-3 rounded-lg bg-indigo-50 p-3 text-sm text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300">
        <b>Better approach:</b> {q.betterApproach} <span className="opacity-70">(Target: {q.timeComplexity})</span>
      </div>

      <button onClick={() => setShowCode((v) => !v)} className="mt-3 text-sm font-semibold text-indigo-600 hover:underline dark:text-indigo-400">
        {showCode ? "Hide" : "View"} submitted code
      </button>
      {showCode && (
        <div className="mt-2">
          <CodeEditor value={code || q.starterCode} language={q.language} readOnly />
        </div>
      )}
      <p className="mt-3 text-xs text-slate-400">Hidden test-case inputs are never revealed.</p>
    </Card>
  );
}

function InfoBox({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-700">
      <div className="text-[10px] font-bold uppercase text-slate-400">{label}</div>
      <div className="mt-0.5 text-sm font-medium text-slate-700 dark:text-slate-200">{children}</div>
    </div>
  );
}
