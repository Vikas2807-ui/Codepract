import { AppProvider, useApp } from "./context/AppContext";
import { Header } from "./components/Header";
import { Landing } from "./components/Landing";
import { Setup } from "./components/Setup";
import { MCQTest } from "./components/MCQTest";
import { CodingTest } from "./components/CodingTest";
import { Result } from "./components/Result";
import { Review } from "./components/Review";
import { Dashboard } from "./components/Dashboard";
import { Practice } from "./components/Practice";
import { Interview } from "./components/Interview";
import { Practi } from "./components/Practi";

function Router() {
  const { view } = useApp();
  switch (view) {
    case "home":
      return <Landing />;
    case "setup":
      return <Setup />;
    case "mcq-test":
      return <MCQTest />;
    case "coding-test":
      return <CodingTest />;
    case "result":
      return <Result />;
    case "review":
      return <Review />;
    case "dashboard":
      return <Dashboard />;
    case "practice":
      return <Practice />;
    case "interview":
      return <Interview />;
    default:
      return <Landing />;
  }
}

export default function App() {
  return (
    <AppProvider>
      <div className="min-h-screen bg-white text-slate-900 dark:bg-slate-950 dark:text-slate-100">
        <Header />
        <main>
          <Router />
        </main>
        <Practi />
      </div>
    </AppProvider>
  );
}
