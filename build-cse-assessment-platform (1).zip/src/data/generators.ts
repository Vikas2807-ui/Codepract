import type { MCQQuestion, Difficulty } from "./types";
import { Rng } from "./rng";

type Q = MCQQuestion;

/* ------------------------------------------------------------------ *
 * Option helpers
 * ------------------------------------------------------------------ */

// Build exactly 4 distinct options (correct + distractors), padding from
// fillers when needed. Returns shuffled options + correct index.
function opts4(
  correct: string,
  distractors: string[],
  rng: Rng,
  fillers: string[] = ["0", "1", "-1", "2", "10", "Error", "None", "null"]
): { options: string[]; correctIndex: number } {
  const set: string[] = [correct];
  for (const d of rng.shuffle(distractors)) {
    if (set.length >= 4) break;
    if (!set.includes(d)) set.push(d);
  }
  for (const f of fillers) {
    if (set.length >= 4) break;
    if (!set.includes(f)) set.push(f);
  }
  // last resort: synthesize numeric fillers
  let n = 3;
  while (set.length < 4) {
    const c = String(n++);
    if (!set.includes(c)) set.push(c);
  }
  const options = rng.shuffle(set);
  return { options, correctIndex: options.indexOf(correct) };
}

// Numeric distractors close to the correct value.
function numDistract(correct: number, rng: Rng): string[] {
  const cand = new Set<number>();
  const deltas = [1, -1, 2, -2, 3, -3, 5, -5, 10, -10];
  const shuffled = rng.shuffle(deltas);
  for (const d of shuffled) {
    const v = correct + d;
    if (v !== correct) cand.add(v);
    if (cand.size >= 5) break;
  }
  if (correct !== 0) {
    cand.add(correct * 2);
    if (correct % 2 === 0) cand.add(correct / 2);
  }
  return [...cand].filter((v) => v !== correct).map(String);
}

const DIFFS: Difficulty[] = ["Easy", "Medium", "Hard"];

/* ------------------------------------------------------------------ *
 * 1. APTITUDE / LOGICAL  (fully computed, correct by construction)
 * ------------------------------------------------------------------ */

function genAptitude(target: number): Q[] {
  const rng = new Rng(1001);
  const out: Q[] = [];
  const S = "Aptitude / Logical Problem Solving";
  let i = 0;
  const kinds = 14;
  while (out.length < target) {
    const kind = i % kinds;
    let q: Q | null = null;
    const id = `g_apt_${i}`;
    if (kind === 0) {
      const p = rng.int(5, 90), n = rng.pick([100, 200, 250, 400, 500, 800, 1000, 60, 150]);
      const ans = (p * n) / 100;
      if (Number.isInteger(ans)) {
        const o = opts4(String(ans), numDistract(ans, rng), rng);
        q = mk(id, S, "Percentages", "Easy", `What is ${p}% of ${n}?`, o, `${p}% of ${n} = (${p}/100) × ${n} = ${ans}.`);
      }
    } else if (kind === 1) {
      const nums = Array.from({ length: rng.int(3, 5) }, () => rng.int(2, 40) * 2);
      const sum = nums.reduce((a, b) => a + b, 0);
      const ans = sum / nums.length;
      if (Number.isInteger(ans)) {
        const o = opts4(String(ans), numDistract(ans, rng), rng);
        q = mk(id, S, "Averages", "Easy", `What is the average of ${nums.join(", ")}?`, o, `Sum = ${sum}, count = ${nums.length}, average = ${sum}/${nums.length} = ${ans}.`);
      }
    } else if (kind === 2) {
      const speed = rng.int(30, 120), time = rng.int(2, 8);
      const dist = speed * time;
      const o = opts4(`${dist} km`, numDistract(dist, rng).map((x) => `${x} km`), rng, ["0 km", "100 km"]);
      q = mk(id, S, "Speed & Distance", "Easy", `A vehicle travels at ${speed} km/h for ${time} hours. How far does it travel?`, o, `Distance = speed × time = ${speed} × ${time} = ${dist} km.`);
    } else if (kind === 3) {
      const cp = rng.int(100, 900), pr = rng.pick([10, 20, 25, 50]);
      const sp = cp + (cp * pr) / 100;
      if (Number.isInteger(sp)) {
        const o = opts4(`₹${sp}`, numDistract(sp, rng).map((x) => `₹${x}`), rng, ["₹0", "₹100"]);
        q = mk(id, S, "Profit & Loss", "Medium", `An item costs ₹${cp}. At ${pr}% profit, what is the selling price?`, o, `SP = CP × (1 + ${pr}/100) = ${cp} × ${1 + pr / 100} = ₹${sp}.`);
      }
    } else if (kind === 4) {
      const p = rng.int(1, 20) * 500, r = rng.pick([4, 5, 6, 8, 10]), t = rng.int(1, 5);
      const si = (p * r * t) / 100;
      const o = opts4(`₹${si}`, numDistract(si, rng).map((x) => `₹${x}`), rng, ["₹0"]);
      q = mk(id, S, "Simple Interest", "Medium", `Find the simple interest on ₹${p} at ${r}% per annum for ${t} years.`, o, `SI = (P × R × T)/100 = (${p} × ${r} × ${t})/100 = ₹${si}.`);
    } else if (kind === 5) {
      const a = rng.int(1, 15), d = rng.int(2, 9), len = 5;
      const seq = Array.from({ length: len }, (_, k) => a + k * d);
      const ans = a + len * d;
      const o = opts4(String(ans), numDistract(ans, rng), rng);
      q = mk(id, S, "Number Series", "Medium", `Find the next number: ${seq.join(", ")}, ?`, o, `This is an arithmetic sequence with common difference ${d}. Next = ${seq[len - 1]} + ${d} = ${ans}.`);
    } else if (kind === 6) {
      const a = rng.int(2, 5), r = rng.pick([2, 3]), len = 4;
      const seq = Array.from({ length: len }, (_, k) => a * r ** k);
      const ans = a * r ** len;
      const o = opts4(String(ans), numDistract(ans, rng), rng);
      q = mk(id, S, "Number Series", "Hard", `Find the next number: ${seq.join(", ")}, ?`, o, `Geometric sequence with ratio ${r}. Next = ${seq[len - 1]} × ${r} = ${ans}.`);
    } else if (kind === 7) {
      const total = rng.int(3, 12) * 5, x = rng.int(2, 4), y = rng.int(1, 3);
      const part = total / (x + y);
      if (Number.isInteger(part)) {
        const ans = part * y;
        const o = opts4(String(ans), numDistract(ans, rng), rng);
        q = mk(id, S, "Ratios", "Medium", `Divide ${total} in the ratio ${x}:${y}. What is the smaller/second share (the ${y} part)?`, o, `Total parts = ${x + y}. One part = ${total}/${x + y} = ${part}. The ${y}-part share = ${part} × ${y} = ${ans}.`);
      }
    } else if (kind === 8) {
      const a = rng.int(6, 15), b = rng.int(6, 15);
      const g = gcd(a, b);
      const o = opts4(String(g), numDistract(g, rng).filter((x) => +x > 0), rng, ["1", "2"]);
      q = mk(id, S, "Number Theory", "Medium", `What is the GCD (HCF) of ${a} and ${b}?`, o, `The greatest common divisor of ${a} and ${b} is ${g}.`);
    } else if (kind === 9) {
      const a = rng.int(3, 12), b = rng.int(3, 12);
      const l = (a * b) / gcd(a, b);
      const o = opts4(String(l), numDistract(l, rng), rng);
      q = mk(id, S, "Number Theory", "Medium", `What is the LCM of ${a} and ${b}?`, o, `LCM(${a}, ${b}) = (${a} × ${b}) / GCD = ${a * b}/${gcd(a, b)} = ${l}.`);
    } else if (kind === 10) {
      const d1 = rng.int(5, 20), d2 = rng.int(6, 25);
      if (d1 !== d2) {
        // A alone d1 days, B alone d2 days, together
        const together = (d1 * d2) / (d1 + d2);
        const val = Math.round(together * 100) / 100;
        const o = opts4(`${val} days`, [d1, d2, d1 + d2, Math.round(together) + 1].map((x) => `${x} days`), rng);
        q = mk(id, S, "Time & Work", "Hard", `A can finish a job in ${d1} days and B in ${d2} days. Working together, how long will they take?`, o, `Combined rate = 1/${d1} + 1/${d2}. Time = (${d1}×${d2})/(${d1}+${d2}) ≈ ${val} days.`);
      }
    } else if (kind === 11) {
      const base = rng.int(20, 200), inc = rng.pick([10, 20, 25, 50]);
      const ans = base + (base * inc) / 100;
      if (Number.isInteger(ans)) {
        const o = opts4(String(ans), numDistract(ans, rng), rng);
        q = mk(id, S, "Percentages", "Easy", `A value of ${base} is increased by ${inc}%. What is the new value?`, o, `New value = ${base} + ${inc}% of ${base} = ${base} + ${(base * inc) / 100} = ${ans}.`);
      }
    } else if (kind === 12) {
      const num = rng.int(1, 9), den = rng.pick([2, 4, 5, 10, 20, 25]);
      const pct = (num / den) * 100;
      if (Number.isInteger(pct)) {
        const o = opts4(`${pct}%`, numDistract(pct, rng).map((x) => `${x}%`), rng);
        q = mk(id, S, "Fractions", "Easy", `Express the fraction ${num}/${den} as a percentage.`, o, `${num}/${den} = ${num / den} = ${pct}%.`);
      }
    } else if (kind === 13) {
      const sonAge = rng.int(5, 20), diff = rng.int(20, 35);
      const fatherAge = sonAge + diff;
      const o = opts4(`${fatherAge} years`, numDistract(fatherAge, rng).map((x) => `${x} years`), rng);
      q = mk(id, S, "Ages", "Medium", `A father is ${diff} years older than his son. If the son is ${sonAge}, how old is the father?`, o, `Father's age = son's age + ${diff} = ${sonAge} + ${diff} = ${fatherAge} years.`);
    }
    if (q) out.push(q);
    i++;
    if (i > target * 4) break; // safety
  }
  return out;
}

/* ------------------------------------------------------------------ *
 * 2. COMPUTER ARCHITECTURE (number systems - computed) + arch facts
 * ------------------------------------------------------------------ */

function genArch(target: number): Q[] {
  const rng = new Rng(2002);
  const out: Q[] = [];
  const S = "Computer Architecture";
  let i = 0;
  const kinds = 11;
  while (out.length < target) {
    const kind = i % kinds;
    const id = `g_arch_${i}`;
    let q: Q | null = null;
    if (kind === 0) {
      const n = rng.int(3, 255);
      const bin = n.toString(2);
      const o = opts4(bin, [n.toString(2).padStart(bin.length + 1, "0"), (n + 1).toString(2), (n - 1).toString(2), (n + 2).toString(2)], rng, ["1010", "1111"]);
      q = mk(id, S, "Number Systems", "Medium", `What is the binary representation of the decimal number ${n}?`, o, `${n} in binary is ${bin}.`);
    } else if (kind === 1) {
      const n = rng.int(3, 250);
      const bin = n.toString(2);
      const o = opts4(String(n), numDistract(n, rng), rng);
      q = mk(id, S, "Number Systems", "Medium", `What is the decimal value of the binary number ${bin}?`, o, `Binary ${bin} = ${n} in decimal.`);
    } else if (kind === 2) {
      const n = rng.int(16, 4095);
      const hex = n.toString(16).toUpperCase();
      const o = opts4(`0x${hex}`, [(n + 1).toString(16), (n - 1).toString(16), (n + 16).toString(16)].map((h) => `0x${h.toUpperCase()}`), rng, ["0xFF", "0x10"]);
      q = mk(id, S, "Number Systems", "Medium", `What is the hexadecimal representation of decimal ${n}?`, o, `${n} in hexadecimal is 0x${hex}.`);
    } else if (kind === 3) {
      const n = rng.int(16, 4000);
      const hex = n.toString(16).toUpperCase();
      const o = opts4(String(n), numDistract(n, rng), rng);
      q = mk(id, S, "Number Systems", "Hard", `What is the decimal value of hexadecimal 0x${hex}?`, o, `0x${hex} = ${n} in decimal.`);
    } else if (kind === 4) {
      const n = rng.int(8, 511);
      const oct = n.toString(8);
      const o = opts4(oct, [(n + 1).toString(8), (n - 1).toString(8), (n + 8).toString(8)], rng, ["17", "77"]);
      q = mk(id, S, "Number Systems", "Hard", `What is the octal representation of decimal ${n}?`, o, `${n} in octal is ${oct}.`);
    } else if (kind === 5) {
      const a = rng.int(1, 255), b = rng.int(1, 255);
      const r = a & b;
      const o = opts4(String(r), [String(a | b), String(a ^ b), String(a), String(b)], rng);
      q = mk(id, S, "Bitwise", "Hard", `What is the result of ${a} & ${b} (bitwise AND)?`, o, `${a} & ${b} = ${r} (bit set only where both bits are 1).`);
    } else if (kind === 6) {
      const a = rng.int(1, 255), b = rng.int(1, 255);
      const r = a | b;
      const o = opts4(String(r), [String(a & b), String(a ^ b), String(a), String(b)], rng);
      q = mk(id, S, "Bitwise", "Hard", `What is the result of ${a} | ${b} (bitwise OR)?`, o, `${a} | ${b} = ${r} (bit set where either bit is 1).`);
    } else if (kind === 7) {
      const a = rng.int(1, 255), b = rng.int(1, 255);
      const r = a ^ b;
      const o = opts4(String(r), [String(a & b), String(a | b), String(a), String(b)], rng);
      q = mk(id, S, "Bitwise", "Hard", `What is the result of ${a} ^ ${b} (bitwise XOR)?`, o, `${a} ^ ${b} = ${r} (bit set where bits differ).`);
    } else if (kind === 8) {
      const p = rng.int(3, 16);
      const v = 2 ** p;
      const o = opts4(String(v), [String(2 ** (p + 1)), String(2 ** (p - 1)), String(v + 2)], rng);
      q = mk(id, S, "Powers of Two", "Easy", `What is the value of 2^${p}?`, o, `2 raised to the power ${p} = ${v}.`);
    } else if (kind === 9) {
      const kb = rng.int(1, 64);
      const bytes = kb * 1024;
      const o = opts4(String(bytes), [String(kb * 1000), String(bytes * 2), String(bytes / 2)], rng);
      q = mk(id, S, "Memory Units", "Easy", `How many bytes are there in ${kb} KB? (1 KB = 1024 bytes)`, o, `${kb} KB = ${kb} × 1024 = ${bytes} bytes.`);
    } else if (kind === 10) {
      const bits = rng.int(3, 20);
      const addrs = 2 ** bits;
      const o = opts4(String(addrs), [String(2 ** (bits + 1)), String(2 ** (bits - 1)), String(bits * 2)], rng);
      q = mk(id, S, "Addressing", "Medium", `An address bus of ${bits} bits can address how many distinct memory locations?`, o, `${bits}-bit address bus → 2^${bits} = ${addrs} locations.`);
    }
    if (q) out.push(q);
    i++;
    if (i > target * 4) break;
  }
  return out;
}

/* ------------------------------------------------------------------ *
 * 3. CODE OUTPUT PREDICTION GENERATORS (computed, correct)
 * ------------------------------------------------------------------ */

function genPython(target: number): Q[] {
  const rng = new Rng(3003);
  const out: Q[] = [];
  const S = "Python";
  const words = ["python", "hello", "world", "code", "data", "logic", "array"];
  let i = 0;
  const kinds = 12;
  while (out.length < target) {
    const k = i % kinds;
    const id = `g_pyout_${i}`;
    let q: Q | null = null;
    if (k === 0) {
      const a = rng.int(2, 30), b = rng.int(2, 30);
      const r = a + b;
      q = mk(id, S, "Output Prediction", "Easy", `What is the output?`, opts4(String(r), numDistract(r, rng), rng), `${a} + ${b} = ${r}.`, `print(${a} + ${b})`);
    } else if (k === 1) {
      const a = rng.int(10, 90), b = rng.int(2, 9);
      const r = Math.floor(a / b);
      q = mk(id, S, "Output Prediction", "Medium", `What is the output?`, opts4(String(r), [String(a / b), String(r + 1), String(a % b)], rng), `// is floor division: ${a} // ${b} = ${r}.`, `print(${a} // ${b})`);
    } else if (k === 2) {
      const a = rng.int(10, 90), b = rng.int(2, 9);
      const r = a % b;
      q = mk(id, S, "Output Prediction", "Medium", `What is the output?`, opts4(String(r), numDistract(r, rng).filter((x) => +x >= 0), rng), `% is modulo: ${a} % ${b} = ${r}.`, `print(${a} % ${b})`);
    } else if (k === 3) {
      const w = rng.pick(words);
      const r = w.length;
      q = mk(id, S, "Strings", "Easy", `What is the output?`, opts4(String(r), numDistract(r, rng), rng), `len("${w}") counts the characters = ${r}.`, `print(len("${w}"))`);
    } else if (k === 4) {
      const w = rng.pick(words), n = rng.int(2, 3);
      const r = w.repeat(n);
      q = mk(id, S, "Strings", "Medium", `What is the output?`, opts4(r, [w + n, w, w.repeat(n + 1)], rng, ['"' + w + '"']), `String × int repeats it: "${w}" * ${n} = "${r}".`, `print("${w}" * ${n})`);
    } else if (k === 5) {
      const w = "python", a = rng.int(0, 2), b = rng.int(3, 6);
      const r = w.slice(a, b);
      q = mk(id, S, "Strings", "Hard", `What is the output?`, opts4(r, [w.slice(a, b + 1), w.slice(a - 0, b - 1), w.slice(a + 1, b)], rng), `Slicing "${w}"[${a}:${b}] takes indices ${a}..${b - 1} = "${r}".`, `print("${w}"[${a}:${b}])`);
    } else if (k === 6) {
      const a = rng.int(1, 50), b = rng.int(1, 50);
      const r = a > b ? "True" : "False";
      q = mk(id, S, "Booleans", "Easy", `What is the output?`, opts4(r, ["True", "False", "1", "0"], rng), `${a} > ${b} evaluates to ${r}.`, `print(${a} > ${b})`);
    } else if (k === 7) {
      const arr = Array.from({ length: rng.int(3, 5) }, () => rng.int(1, 20));
      const r = arr.reduce((x, y) => x + y, 0);
      q = mk(id, S, "Lists", "Medium", `What is the output?`, opts4(String(r), numDistract(r, rng), rng), `sum([${arr.join(", ")}]) = ${r}.`, `print(sum([${arr.join(", ")}]))`);
    } else if (k === 8) {
      const a = rng.int(2, 6), b = rng.int(2, 4);
      const r = a ** b;
      q = mk(id, S, "Operators", "Medium", `What is the output?`, opts4(String(r), [String(a * b), String(a ** (b - 1)), String(r + a)], rng), `** is exponent: ${a} ** ${b} = ${r}.`, `print(${a} ** ${b})`);
    } else if (k === 9) {
      const nums = Array.from({ length: rng.int(3, 5) }, () => rng.int(1, 40));
      const r = Math.max(...nums);
      q = mk(id, S, "Built-ins", "Easy", `What is the output?`, opts4(String(r), [String(Math.min(...nums)), String(r - 1), String(nums[0])], rng), `max returns the largest value = ${r}.`, `print(max(${nums.join(", ")}))`);
    } else if (k === 10) {
      const x = rng.int(1, 40);
      const r = -x;
      q = mk(id, S, "Built-ins", "Easy", `What is the output?`, opts4(String(x), [String(r), "0", String(x + 1)], rng), `abs(${r}) returns the magnitude = ${x}.`, `print(abs(${r}))`);
    } else {
      const a = rng.int(1, 20), b = rng.int(1, 20);
      const r = a * b;
      q = mk(id, S, "Output Prediction", "Easy", `What is the output?`, opts4(String(r), numDistract(r, rng), rng), `${a} * ${b} = ${r}.`, `print(${a} * ${b})`);
    }
    if (q) out.push(q);
    i++;
    if (i > target * 4) break;
  }
  return out;
}

function genCLike(S: string, prefix: string, seed: number, target: number, printfStyle: boolean): Q[] {
  const rng = new Rng(seed);
  const out: Q[] = [];
  const emit = (expr: string) => (printfStyle ? `printf("%d", ${expr});` : `cout << (${expr});`);
  let i = 0;
  const kinds = 9;
  while (out.length < target) {
    const k = i % kinds;
    const id = `g_${prefix}_${i}`;
    let q: Q | null = null;
    if (k === 0) {
      const a = rng.int(2, 40), b = rng.int(2, 40);
      const r = a + b;
      q = mk(id, S, "Output Prediction", "Easy", `What is the output?`, opts4(String(r), numDistract(r, rng), rng), `${a} + ${b} = ${r}.`, emit(`${a} + ${b}`));
    } else if (k === 1) {
      const a = rng.int(10, 99), b = rng.int(2, 9);
      const r = Math.trunc(a / b);
      q = mk(id, S, "Output Prediction", "Medium", `What is the output? (integer division)`, opts4(String(r), [String(r + 1), String(a % b), String((a / b).toFixed(1))], rng), `Integer division ${a} / ${b} truncates to ${r}.`, emit(`${a} / ${b}`));
    } else if (k === 2) {
      const a = rng.int(10, 99), b = rng.int(2, 9);
      const r = a % b;
      q = mk(id, S, "Output Prediction", "Medium", `What is the output?`, opts4(String(r), numDistract(r, rng).filter((x) => +x >= 0), rng), `${a} % ${b} = ${r} (remainder).`, emit(`${a} % ${b}`));
    } else if (k === 3) {
      const a = rng.int(1, 9), b = rng.int(2, 9), c = rng.int(2, 9);
      const r = a + b * c;
      q = mk(id, S, "Operator Precedence", "Medium", `What is the output?`, opts4(String(r), [String((a + b) * c), String(a * b + c), String(r + 1)], rng), `* has higher precedence than +: ${a} + ${b}*${c} = ${a} + ${b * c} = ${r}.`, emit(`${a} + ${b} * ${c}`));
    } else if (k === 4) {
      const n = rng.int(1, 20);
      const r = 65 + n;
      const ch = String.fromCharCode(r);
      q = mk(id, S, "Characters", "Hard", `What is the integer output?`, opts4(String(r), [String(65), String(r + 1), `'${ch}'`], rng), `'A' has ASCII value 65, so 'A' + ${n} = ${r}.`, emit(`'A' + ${n}`));
    } else if (k === 5) {
      const a = rng.int(1, 200), b = rng.int(1, 200);
      const r = a & b;
      q = mk(id, S, "Bitwise", "Hard", `What is the output?`, opts4(String(r), [String(a | b), String(a ^ b), String(a)], rng), `${a} & ${b} = ${r} (bitwise AND).`, emit(`${a} & ${b}`));
    } else if (k === 6) {
      const n = rng.int(0, 8);
      const r = 1 << n;
      q = mk(id, S, "Bitwise", "Hard", `What is the output?`, opts4(String(r), [String(1 << (n + 1)), String(n * 2), String(2 * n)], rng), `1 << ${n} shifts left = 2^${n} = ${r}.`, emit(`1 << ${n}`));
    } else if (k === 7) {
      const a = rng.int(1, 50), b = rng.int(1, 50), x = rng.int(1, 9), y = rng.int(10, 19);
      const r = a > b ? x : y;
      q = mk(id, S, "Ternary", "Medium", `What is the output?`, opts4(String(r), [String(a > b ? y : x), String(a + b), String(x + y)], rng), `${a} > ${b} is ${a > b}, so the ternary yields ${r}.`, emit(`${a} > ${b} ? ${x} : ${y}`));
    } else {
      const a = rng.int(2, 15), b = rng.int(2, 15);
      const r = a * b;
      q = mk(id, S, "Output Prediction", "Easy", `What is the output?`, opts4(String(r), numDistract(r, rng), rng), `${a} * ${b} = ${r}.`, emit(`${a} * ${b}`));
    }
    if (q) out.push(q);
    i++;
    if (i > target * 4) break;
  }
  return out;
}

function genJava(target: number): Q[] {
  const rng = new Rng(5005);
  const out: Q[] = [];
  const S = "Java";
  const P = (e: string) => `System.out.println(${e});`;
  let i = 0;
  const kinds = 9;
  while (out.length < target) {
    const k = i % kinds;
    const id = `g_javaout_${i}`;
    let q: Q | null = null;
    if (k === 0) {
      const a = rng.int(2, 40), b = rng.int(2, 40);
      const r = a + b;
      q = mk(id, S, "Output Prediction", "Easy", `What is the output?`, opts4(String(r), numDistract(r, rng), rng), `${a} + ${b} = ${r}.`, P(`${a} + ${b}`));
    } else if (k === 1) {
      const a = rng.int(10, 99), b = rng.int(2, 9);
      const r = Math.trunc(a / b);
      q = mk(id, S, "Output Prediction", "Medium", `What is the output? (integer division)`, opts4(String(r), [String(r + 1), String(a % b), (a / b).toFixed(1)], rng), `int/int truncates: ${a} / ${b} = ${r}.`, P(`${a} / ${b}`));
    } else if (k === 2) {
      const n = rng.int(1, 99);
      const r = `x${n}`;
      q = mk(id, S, "Strings", "Medium", `What is the output?`, opts4(r, [String(n), `x + ${n}`, `${n}x`], rng), `"x" + ${n} concatenates to the string "${r}".`, P(`"x" + ${n}`));
    } else if (k === 3) {
      const n = rng.int(1, 20);
      const r = 65 + n;
      q = mk(id, S, "Characters", "Hard", `What is the output?`, opts4(String(r), [`'${String.fromCharCode(r)}'`, String(65), String(r + 1)], rng), `In Java 'A' + int promotes to int: 65 + ${n} = ${r}.`, P(`'A' + ${n}`));
    } else if (k === 4) {
      const a = rng.int(1, 60), b = rng.int(1, 60);
      const r = Math.max(a, b);
      q = mk(id, S, "Math", "Easy", `What is the output?`, opts4(String(r), [String(Math.min(a, b)), String(a + b), String(r - 1)], rng), `Math.max(${a}, ${b}) = ${r}.`, P(`Math.max(${a}, ${b})`));
    } else if (k === 5) {
      const a = rng.int(10, 99), b = rng.int(2, 9);
      const r = a % b;
      q = mk(id, S, "Output Prediction", "Medium", `What is the output?`, opts4(String(r), numDistract(r, rng).filter((x) => +x >= 0), rng), `${a} % ${b} = ${r}.`, P(`${a} % ${b}`));
    } else if (k === 6) {
      const a = rng.int(1, 50), b = rng.int(1, 50);
      const r = a > b ? "true" : "false";
      q = mk(id, S, "Booleans", "Easy", `What is the output?`, opts4(r, ["true", "false", "1", "0"], rng), `${a} > ${b} is ${r} (Java booleans are lowercase).`, P(`${a} > ${b}`));
    } else if (k === 7) {
      const x = rng.int(1, 40);
      const r = x;
      q = mk(id, S, "Math", "Easy", `What is the output?`, opts4(String(r), [String(-x), "0", String(x + 1)], rng), `Math.abs(${-x}) = ${x}.`, P(`Math.abs(${-x})`));
    } else {
      const a = rng.int(1, 9), b = rng.int(2, 9), c = rng.int(2, 9);
      const r = a + b * c;
      q = mk(id, S, "Operator Precedence", "Medium", `What is the output?`, opts4(String(r), [String((a + b) * c), String(a * b + c), String(r + 1)], rng), `* before +: ${a} + ${b}*${c} = ${r}.`, P(`${a} + ${b} * ${c}`));
    }
    if (q) out.push(q);
    i++;
    if (i > target * 4) break;
  }
  return out;
}

/* ------------------------------------------------------------------ *
 * 4. FACT-BASED GENERATOR for conceptual subjects (verified facts)
 * ------------------------------------------------------------------ */

interface FactTemplate {
  // returns [questionText, correctAnswer, distractorPool, explanation, topic, difficulty]
  make: (f: string[], all: string[][]) => [string, string, string[], string, string, Difficulty] | null;
}

// Build questions from a fact table using multiple templates. Each row is a
// string[]; templates read specific columns. Distractors are drawn from the
// same column across other rows (guaranteeing plausibility + correctness).
function factGen(
  subject: string,
  prefix: string,
  seed: number,
  rows: string[][],
  templates: FactTemplate[]
): Q[] {
  const rng = new Rng(seed);
  const out: Q[] = [];
  let idx = 0;
  for (const t of templates) {
    for (const row of rows) {
      const res = t.make(row, rows);
      if (!res) continue;
      const [question, correct, distractors, explanation, topic, difficulty] = res;
      const pool = distractors.filter((d) => d && d !== correct);
      if (pool.length < 3) continue;
      const o = opts4(correct, pool, rng, pool.slice());
      out.push({
        id: `g_${prefix}_${idx++}`,
        subject,
        topic,
        difficulty,
        question,
        options: o.options,
        correctIndex: o.correctIndex,
        explanation,
        tags: [topic.toLowerCase()],
      });
    }
  }
  return out;
}

function col(rows: string[][], c: number): string[] {
  return rows.map((r) => r[c]).filter(Boolean);
}

/* Category-based generators (correct by construction) --------------- */
// Produces "Which of the following is NOT a {category}?" and
// "Which of the following IS a {category}?" questions. termCol = item column,
// catCol = category column. Only categories with >= 3 items are used.
function catGen(
  subject: string,
  prefix: string,
  seed: number,
  rows: string[][],
  termCol: number,
  catCol: number
): Q[] {
  const rng = new Rng(seed);
  const out: Q[] = [];
  const cats = [...new Set(rows.map((r) => r[catCol]).filter(Boolean))];
  if (cats.length < 2) return out;
  const byCat: Record<string, string[]> = {};
  for (const c of cats) byCat[c] = rows.filter((r) => r[catCol] === c).map((r) => r[termCol]);
  let idx = 0;
  // "IS a" questions: one correct item from the category + 3 from other categories
  for (const c of cats) {
    const members = byCat[c];
    const others = rows.filter((r) => r[catCol] !== c).map((r) => r[termCol]);
    if (members.length < 1 || others.length < 3) continue;
    for (const correct of members) {
      const distract = rng.shuffle(others).slice(0, 6);
      const o = opts4(correct, distract, rng, distract);
      out.push({
        id: `g_${prefix}_is_${idx++}`,
        subject,
        topic: "Classification",
        difficulty: "Medium",
        question: `Which of the following is a "${c}"?`,
        options: o.options,
        correctIndex: o.correctIndex,
        explanation: `${correct} belongs to ${c}.`,
        tags: ["classification"],
      });
    }
  }
  // "NOT a" questions: 3 items from a category + 1 odd item from another
  for (const c of cats) {
    const members = byCat[c];
    const others = rows.filter((r) => r[catCol] !== c);
    if (members.length < 3 || others.length < 1) continue;
    const rounds = Math.min(members.length, 8);
    for (let r = 0; r < rounds; r++) {
      const three = rng.shuffle(members).slice(0, 3);
      const oddRow = rng.pick(others);
      const odd = oddRow[termCol];
      const oddCat = oddRow[catCol];
      if (three.includes(odd)) continue;
      const options = rng.shuffle([...three, odd]);
      out.push({
        id: `g_${prefix}_not_${idx++}`,
        subject,
        topic: "Classification",
        difficulty: "Hard",
        question: `Which of the following is NOT a "${c}"?`,
        options,
        correctIndex: options.indexOf(odd),
        explanation: `${odd} is a ${oddCat}, not a ${c}.`,
        tags: ["classification"],
      });
    }
  }
  return out;
}

// Term↔definition matching correctness: the correct option pairs the term with
// its real definition; distractors pair the SAME term with OTHER definitions.
function matchGen(
  subject: string,
  prefix: string,
  seed: number,
  rows: string[][],
  topic: string
): Q[] {
  const rng = new Rng(seed);
  const out: Q[] = [];
  const defs = rows.map((r) => r[1]).filter(Boolean);
  const stems = [
    "Which of the following pairings is correct?",
    "Which term–definition match is accurate?",
    "Pick the correct statement below.",
    "Which mapping is correct?",
    "Select the accurate term and its meaning.",
  ];
  let idx = 0;
  for (const row of rows) {
    if (!row[1]) continue;
    const correct = `${row[0]} — ${row[1]}`;
    const others = rng.shuffle(defs.filter((d) => d !== row[1])).slice(0, 6);
    const distract = others.map((d) => `${row[0]} — ${d}`);
    if (distract.length < 3) continue;
    const o = opts4(correct, distract, rng, distract);
    out.push({
      id: `g_${prefix}_m_${idx}`,
      subject,
      topic,
      difficulty: "Medium",
      question: stems[idx % stems.length],
      options: o.options,
      correctIndex: o.correctIndex,
      explanation: `${row[0]} — ${row[1]}.`,
      tags: [topic.toLowerCase()],
    });
    idx++;
  }
  return out;
}

/* ---- helper to make a Q with prebuilt options ---- */
function mk(
  id: string,
  subject: string,
  topic: string,
  difficulty: Difficulty,
  question: string,
  o: { options: string[]; correctIndex: number },
  explanation: string,
  code?: string
): Q {
  return { id, subject, topic, difficulty, question, options: o.options, correctIndex: o.correctIndex, explanation, tags: [topic.toLowerCase()], code };
}

function gcd(a: number, b: number): number {
  return b === 0 ? a : gcd(b, a % b);
}

export {
  genAptitude,
  genArch,
  genPython,
  genCLike,
  genJava,
  factGen,
  catGen,
  matchGen,
  col,
  opts4,
  DIFFS,
};
