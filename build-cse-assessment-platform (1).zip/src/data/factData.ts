import type { MCQQuestion, Difficulty } from "./types";
import { factGen, catGen, matchGen, col } from "./generators";
import { Rng } from "./rng";

type Row = string[];
type Tmpl = { make: (f: Row, all: Row[]) => [string, string, string[], string, string, Difficulty] | null };

/* Generic template factories ---------------------------------------- */
// Deterministic hash so phrasing is stable per term across sessions.
function h(s: string): number {
  let x = 0;
  for (let i = 0; i < s.length; i++) x = (x * 31 + s.charCodeAt(i)) >>> 0;
  return x;
}
const WHATIS_PHRASES = [
  (t: string) => `Which of these best describes "${t}"?`,
  (t: string) => `What is "${t}"?`,
  (t: string) => `How is "${t}" best defined?`,
  (t: string) => `Choose the correct meaning of "${t}".`,
  (t: string) => `"${t}" is best described as which of the following?`,
];
const WHICHTERM_PHRASES = [
  (d: string, n: string) => `Which ${n} is described: "${d}"?`,
  (d: string, n: string) => `Identify the ${n}: "${d}".`,
  (d: string, n: string) => `Which ${n} matches this description: "${d}"?`,
  (d: string, n: string) => `Name the ${n}: "${d}".`,
  (d: string, n: string) => `"${d}" — which ${n} is this?`,
];
// term(0) -> definition(1)
const tWhatIs = (topic: string, d: Difficulty): Tmpl => ({
  make: (f, all) =>
    f[1] ? [WHATIS_PHRASES[h(f[0]) % WHATIS_PHRASES.length](f[0]), f[1], col(all, 1), `${f[0]}: ${f[1]}`, topic, d] : null,
});
// definition(1) -> term(0)
const tWhichTerm = (topic: string, d: Difficulty, noun = "concept"): Tmpl => ({
  make: (f, all) =>
    f[1] ? [WHICHTERM_PHRASES[h(f[1]) % WHICHTERM_PHRASES.length](f[1], noun), f[0], col(all, 0), `${f[0]} — ${f[1]}.`, topic, d] : null,
});
// term(0) -> category(2)
const tCategory = (topic: string, d: Difficulty, label = "category"): Tmpl => ({
  make: (f, all) => (f[2] ? [`Which ${label} does "${f[0]}" belong to?`, f[2], col(all, 2), `${f[0]} belongs to: ${f[2]}.`, topic, d] : null),
});

/* =================================================================== *
 * COMPUTER NETWORKS
 * =================================================================== */
// [name, port, transport, osiLayer, expansion]
const CN_PORTS: Row[] = [
  ["HTTP", "80", "TCP", "Application", "HyperText Transfer Protocol"],
  ["HTTPS", "443", "TCP", "Application", "HTTP Secure"],
  ["FTP", "21", "TCP", "Application", "File Transfer Protocol"],
  ["SSH", "22", "TCP", "Application", "Secure Shell"],
  ["Telnet", "23", "TCP", "Application", "Teletype Network"],
  ["SMTP", "25", "TCP", "Application", "Simple Mail Transfer Protocol"],
  ["DNS", "53", "UDP", "Application", "Domain Name System"],
  ["DHCP", "67", "UDP", "Application", "Dynamic Host Configuration Protocol"],
  ["TFTP", "69", "UDP", "Application", "Trivial File Transfer Protocol"],
  ["POP3", "110", "TCP", "Application", "Post Office Protocol v3"],
  ["NTP", "123", "UDP", "Application", "Network Time Protocol"],
  ["IMAP", "143", "TCP", "Application", "Internet Message Access Protocol"],
  ["SNMP", "161", "UDP", "Application", "Simple Network Management Protocol"],
  ["LDAP", "389", "TCP", "Application", "Lightweight Directory Access Protocol"],
  ["SMB", "445", "TCP", "Application", "Server Message Block"],
  ["RDP", "3389", "TCP", "Application", "Remote Desktop Protocol"],
  ["MySQL", "3306", "TCP", "Application", "MySQL Database"],
  ["PostgreSQL", "5432", "TCP", "Application", "PostgreSQL Database"],
];
// [device/term, definition, layer]
const CN_DEVICES: Row[] = [
  ["Router", "Forwards packets between different networks using IP addresses", "Network"],
  ["Switch", "Forwards frames within a LAN using MAC addresses", "Data Link"],
  ["Hub", "Broadcasts incoming signals to all ports (no filtering)", "Physical"],
  ["Bridge", "Connects and filters traffic between two LAN segments", "Data Link"],
  ["Repeater", "Regenerates and amplifies signals to extend distance", "Physical"],
  ["Gateway", "Translates between different network protocols", "Application"],
  ["NIC", "Hardware interface that connects a device to a network", "Data Link"],
  ["Firewall", "Filters traffic based on security rules", "Network"],
  ["Access Point", "Connects wireless devices to a wired network", "Data Link"],
  ["Modem", "Modulates/demodulates signals for transmission lines", "Physical"],
];
// [code, meaning, category]
const CN_STATUS: Row[] = [
  ["200", "OK — request succeeded", "2xx Success"],
  ["201", "Created — resource created", "2xx Success"],
  ["204", "No Content", "2xx Success"],
  ["301", "Moved Permanently", "3xx Redirection"],
  ["302", "Found (temporary redirect)", "3xx Redirection"],
  ["304", "Not Modified", "3xx Redirection"],
  ["400", "Bad Request", "4xx Client Error"],
  ["401", "Unauthorized", "4xx Client Error"],
  ["403", "Forbidden", "4xx Client Error"],
  ["404", "Not Found", "4xx Client Error"],
  ["405", "Method Not Allowed", "4xx Client Error"],
  ["409", "Conflict", "4xx Client Error"],
  ["429", "Too Many Requests", "4xx Client Error"],
  ["500", "Internal Server Error", "5xx Server Error"],
  ["502", "Bad Gateway", "5xx Server Error"],
  ["503", "Service Unavailable", "5xx Server Error"],
  ["504", "Gateway Timeout", "5xx Server Error"],
];
// [concept, definition]
const CN_CONCEPTS: Row[] = [
  ["OSI Model", "A 7-layer reference model for network communication"],
  ["TCP", "Connection-oriented, reliable transport protocol with acknowledgments"],
  ["UDP", "Connectionless, fast transport protocol without guaranteed delivery"],
  ["IP", "Network-layer protocol responsible for logical addressing and routing"],
  ["MAC Address", "48-bit hardware address burned into a network interface"],
  ["Subnet Mask", "Divides an IP address into network and host portions"],
  ["ARP", "Resolves an IP address to a MAC address"],
  ["ICMP", "Used for error reporting and diagnostics (e.g., ping)"],
  ["NAT", "Translates private IP addresses to a public IP address"],
  ["Latency", "The time delay for data to travel from source to destination"],
  ["Bandwidth", "The maximum data transfer rate of a network link"],
  ["Three-way Handshake", "SYN, SYN-ACK, ACK sequence used by TCP to establish a connection"],
  ["CIDR", "Classless addressing notation like 192.168.0.0/24"],
  ["VPN", "Creates a secure encrypted tunnel over a public network"],
  ["Packet", "A unit of data at the network layer"],
  ["Frame", "A unit of data at the data-link layer"],
];

function genCN(): MCQQuestion[] {
  const S = "Computer Networks";
  const out: MCQQuestion[] = [];
  out.push(...factGen(S, "cn_port", 6001, CN_PORTS, [
    { make: (f, all) => [`Which port does ${f[0]} use by default?`, f[1], col(all, 1), `${f[0]} uses port ${f[1]}.`, "Ports", "Medium"] },
    { make: (f, all) => [`Which service uses TCP/UDP port ${f[1]} by default?`, f[0], col(all, 0), `Port ${f[1]} is used by ${f[0]}.`, "Ports", "Medium"] },
    { make: (f) => [`Which transport protocol does ${f[0]} primarily use?`, f[2], ["TCP", "UDP", "ICMP", "IP"], `${f[0]} primarily uses ${f[2]}.`, "Transport", "Hard"] },
    { make: (f, all) => [`What does the acronym ${f[0]} stand for?`, f[4], col(all, 4), `${f[0]} = ${f[4]}.`, "Protocols", "Easy"] },
  ]));
  out.push(...factGen(S, "cn_dev", 6002, CN_DEVICES, [
    tWhatIs("Devices", "Easy"),
    tWhichTerm("Devices", "Medium", "device"),
    { make: (f, all) => [`At which OSI layer does a ${f[0]} primarily operate?`, f[2], col(all, 2).concat(["Transport", "Session", "Presentation"]), `A ${f[0]} operates at the ${f[2]} layer.`, "OSI Layers", "Medium"] },
  ]));
  out.push(...factGen(S, "cn_status", 6003, CN_STATUS, [
    { make: (f, all) => [`What does HTTP status code ${f[0]} mean?`, f[1], col(all, 1), `Status ${f[0]}: ${f[1]}.`, "HTTP", "Medium"] },
    { make: (f, all) => [`Which HTTP status code means "${f[1]}"?`, f[0], col(all, 0), `${f[1]} → ${f[0]}.`, "HTTP", "Medium"] },
    tCategory("HTTP", "Easy", "status class"),
  ]));
  out.push(...factGen(S, "cn_con", 6004, CN_CONCEPTS, [tWhatIs("Concepts", "Medium"), tWhichTerm("Concepts", "Hard")]));
  out.push(...matchGen(S, "cn_mc", 6005, CN_CONCEPTS, "Concepts"));
  out.push(...matchGen(S, "cn_md", 6006, CN_DEVICES, "Devices"));
  out.push(...catGen(S, "cn_cat", 6007, CN_DEVICES, 0, 2));
  out.push(...catGen(S, "cn_st", 6008, CN_STATUS, 0, 2));
  out.push(...catGen(S, "cn_pt", 6009, CN_PORTS, 0, 2));
  return out;
}

/* =================================================================== *
 * OPERATING SYSTEMS
 * =================================================================== */
const OS_ALGOS: Row[] = [
  ["FCFS", "Processes are executed in arrival order (non-preemptive)", "CPU Scheduling"],
  ["SJF", "Executes the process with the smallest burst time first", "CPU Scheduling"],
  ["Round Robin", "Each process gets a fixed time quantum in cyclic order", "CPU Scheduling"],
  ["Priority Scheduling", "The highest-priority process runs first", "CPU Scheduling"],
  ["SRTF", "Preemptive version of shortest job first", "CPU Scheduling"],
  ["FIFO", "Replaces the oldest loaded page first", "Page Replacement"],
  ["LRU", "Replaces the least recently used page", "Page Replacement"],
  ["Optimal", "Replaces the page not needed for the longest future time", "Page Replacement"],
  ["LFU", "Replaces the least frequently used page", "Page Replacement"],
  ["FCFS Disk", "Services disk requests in arrival order", "Disk Scheduling"],
  ["SCAN", "Disk arm moves in one direction servicing requests (elevator)", "Disk Scheduling"],
  ["C-SCAN", "Disk arm services in one direction then jumps back to start", "Disk Scheduling"],
];
const OS_CONCEPTS: Row[] = [
  ["Process", "A program in execution with its own address space"],
  ["Thread", "A lightweight unit of execution that shares the process's memory"],
  ["Deadlock", "A state where processes wait indefinitely for each other's resources"],
  ["Semaphore", "A synchronization primitive using a counter and wait/signal"],
  ["Mutex", "A lock allowing only one thread into a critical section"],
  ["Context Switch", "Saving one process's state and loading another's"],
  ["Paging", "Dividing memory into fixed-size pages and frames"],
  ["Segmentation", "Dividing memory into variable-size logical segments"],
  ["Virtual Memory", "Using disk space to extend apparent physical memory"],
  ["Page Fault", "Occurs when a referenced page is not in physical memory"],
  ["Thrashing", "Excessive paging that severely degrades performance"],
  ["PCB", "A structure storing all information about a process"],
  ["Fragmentation", "Wasted memory that cannot be allocated efficiently"],
  ["Kernel", "The core of the OS that manages resources and hardware"],
  ["System Call", "The interface for a program to request an OS service"],
  ["Starvation", "A process waits indefinitely because others are preferred"],
  ["Critical Section", "Code that accesses shared resources and must be synchronized"],
  ["TLB", "A cache that speeds up virtual-to-physical address translation"],
  ["Spooling", "Buffering jobs (e.g., print) for a slow device"],
  ["Demand Paging", "Loading pages into memory only when they are needed"],
  ["Multiprogramming", "Keeping several programs in memory to keep the CPU busy"],
  ["Multitasking", "Rapidly switching the CPU among multiple tasks"],
  ["Multiprocessing", "Using multiple CPUs or cores simultaneously"],
  ["Time Sharing", "Giving each user a small slice of CPU time"],
  ["Dispatcher", "Hands CPU control to the process chosen by the scheduler"],
  ["Scheduler", "Selects which process runs next"],
  ["Turnaround Time", "Total time from submission to completion"],
  ["Waiting Time", "Time a process spends in the ready queue"],
  ["Response Time", "Time from a request to the first response"],
  ["Throughput", "Number of processes completed per unit time"],
  ["Preemption", "Forcibly taking the CPU from a running process"],
  ["Ready Queue", "The set of processes waiting for the CPU"],
  ["Zombie Process", "A finished process whose table entry still remains"],
  ["Orphan Process", "A process whose parent has already terminated"],
  ["Fork", "A system call that creates a new process"],
  ["Exec", "A system call that replaces a process's image"],
  ["Race Condition", "Result depends on uncontrolled thread timing"],
  ["Producer-Consumer", "A synchronization problem with a shared buffer"],
  ["Readers-Writers", "A synchronization problem balancing reads and writes"],
  ["Dining Philosophers", "A classic deadlock/synchronization problem"],
  ["Banker's Algorithm", "A deadlock-avoidance algorithm using safe states"],
  ["Belady's Anomaly", "More page frames causing more faults (in FIFO)"],
  ["Working Set", "The set of pages a process is actively using"],
  ["Locality of Reference", "Programs tend to reuse nearby memory locations"],
  ["Internal Fragmentation", "Wasted space inside an allocated block"],
  ["External Fragmentation", "Free memory broken into unusable small pieces"],
  ["Compaction", "Rearranging memory to reduce fragmentation"],
  ["Swapping", "Moving processes between memory and disk"],
  ["Interrupt", "A signal that diverts the CPU to handle an event"],
  ["Monolithic Kernel", "A kernel where all services run in kernel space"],
  ["Microkernel", "A minimal kernel with services in user space"],
  ["Real-Time OS", "An OS guaranteeing response within time constraints"],
];
const OS_DEADLOCK: Row[] = [
  ["Mutual Exclusion", "A resource is held in non-shareable mode", "Deadlock Condition"],
  ["Hold and Wait", "A process holds resources while waiting for more", "Deadlock Condition"],
  ["No Preemption", "Resources cannot be forcibly taken away", "Deadlock Condition"],
  ["Circular Wait", "A closed chain of processes each waiting on the next", "Deadlock Condition"],
];

function genOS(): MCQQuestion[] {
  const S = "Operating Systems";
  const out: MCQQuestion[] = [];
  out.push(...factGen(S, "os_algo", 6101, OS_ALGOS, [
    tWhatIs("Algorithms", "Medium"),
    tWhichTerm("Algorithms", "Medium", "algorithm"),
    tCategory("Algorithms", "Easy", "problem area"),
  ]));
  out.push(...factGen(S, "os_con", 6102, OS_CONCEPTS, [tWhatIs("Concepts", "Medium"), tWhichTerm("Concepts", "Hard", "term")]));
  out.push(...factGen(S, "os_dead", 6103, OS_DEADLOCK, [tWhatIs("Deadlocks", "Hard"), tWhichTerm("Deadlocks", "Hard", "condition")]));
  out.push(...matchGen(S, "os_mc", 6104, OS_CONCEPTS, "Concepts"));
  out.push(...matchGen(S, "os_ma", 6105, OS_ALGOS, "Algorithms"));
  out.push(...catGen(S, "os_cat", 6106, OS_ALGOS, 0, 2));
  return out;
}

/* =================================================================== *
 * DBMS
 * =================================================================== */
const DB_CONCEPTS: Row[] = [
  ["Primary Key", "Uniquely identifies each row and cannot be NULL"],
  ["Foreign Key", "References the primary key of another table"],
  ["Candidate Key", "A minimal attribute set that can uniquely identify a row"],
  ["Super Key", "Any attribute set that uniquely identifies a row"],
  ["Composite Key", "A key made up of two or more columns"],
  ["Normalization", "Organizing tables to reduce redundancy and anomalies"],
  ["Denormalization", "Adding redundancy to improve read performance"],
  ["Index", "A structure that speeds up data retrieval"],
  ["View", "A virtual table defined by a stored query"],
  ["Trigger", "Code that runs automatically on a table event"],
  ["Transaction", "A logical unit of work that is all-or-nothing"],
  ["Deadlock", "Two transactions each waiting for the other's lock"],
  ["Schema", "The logical structure/definition of a database"],
  ["Tuple", "A single row in a relation"],
  ["Attribute", "A column in a relation"],
  ["Cardinality", "The number of rows in a relation"],
  ["Degree", "The number of attributes (columns) in a relation"],
  ["Referential Integrity", "Foreign keys must match an existing primary key or be NULL"],
  ["Stored Procedure", "A precompiled set of SQL statements stored in the DB"],
  ["ACID", "Atomicity, Consistency, Isolation, Durability"],
  ["DDL", "SQL sublanguage that defines schema (CREATE, ALTER, DROP)"],
  ["DML", "SQL sublanguage that manipulates data (INSERT, UPDATE, DELETE)"],
  ["DCL", "SQL sublanguage for permissions (GRANT, REVOKE)"],
  ["TCL", "SQL sublanguage for transactions (COMMIT, ROLLBACK)"],
  ["Relation", "A table in the relational model"],
  ["Domain", "The set of allowed values for an attribute"],
  ["Entity", "A real-world object represented in the database"],
  ["Weak Entity", "An entity that depends on another for identification"],
  ["ER Diagram", "A diagram modeling entities and their relationships"],
  ["Cartesian Product", "Every row of one table paired with every row of another"],
  ["Natural Join", "A join on all columns with the same name"],
  ["Equi Join", "A join using an equality condition"],
  ["Self Join", "Joining a table to itself"],
  ["Aggregate Function", "A function computing a single value over rows"],
  ["Clustered Index", "An index that determines the physical row order"],
  ["Non-clustered Index", "A separate structure pointing to table rows"],
  ["B-Tree Index", "A balanced tree structure commonly used for indexes"],
  ["Hash Index", "An index using a hash function for equality lookups"],
  ["Concurrency Control", "Managing simultaneous transactions safely"],
  ["Locking", "Preventing conflicting access to data during transactions"],
  ["Two-Phase Locking", "A protocol with growing and shrinking lock phases"],
  ["Isolation Level", "How visible one transaction's changes are to others"],
  ["Dirty Read", "Reading uncommitted changes from another transaction"],
  ["Phantom Read", "New rows appearing between reads in a transaction"],
  ["Savepoint", "A marker to partially roll back within a transaction"],
  ["Data Redundancy", "Unnecessary duplication of data"],
  ["Data Independence", "Ability to change schema without affecting apps"],
  ["Materialized View", "A stored, precomputed result of a query"],
  ["Sharding", "Splitting a database horizontally across servers"],
  ["Replication", "Keeping copies of data on multiple servers"],
  ["NoSQL", "Non-relational databases for flexible/large-scale data"],
  ["Primary Index", "An index on the primary key"],
  ["Surrogate Key", "An artificial key with no business meaning"],
  ["Check Constraint", "A rule that limits the values allowed in a column"],
  ["Unique Constraint", "Ensures all values in a column are distinct"],
  ["Default Constraint", "Provides a value when none is supplied"],
];
const DB_NORMAL: Row[] = [
  ["1NF", "All attribute values are atomic (no repeating groups)", "Normal Form"],
  ["2NF", "In 1NF and no partial dependency on part of a composite key", "Normal Form"],
  ["3NF", "In 2NF and no transitive dependency on the primary key", "Normal Form"],
  ["BCNF", "Every determinant is a candidate key", "Normal Form"],
  ["4NF", "In BCNF and has no multi-valued dependency", "Normal Form"],
];
const DB_ACID: Row[] = [
  ["Atomicity", "All operations in a transaction succeed or none do", "ACID Property"],
  ["Consistency", "A transaction moves the DB from one valid state to another", "ACID Property"],
  ["Isolation", "Concurrent transactions do not interfere with each other", "ACID Property"],
  ["Durability", "Committed changes survive system failures", "ACID Property"],
];

function genDBMS(): MCQQuestion[] {
  const S = "DBMS";
  const out: MCQQuestion[] = [];
  out.push(...factGen(S, "db_con", 6201, DB_CONCEPTS, [tWhatIs("Concepts", "Medium"), tWhichTerm("Concepts", "Hard", "term")]));
  out.push(...factGen(S, "db_norm", 6202, DB_NORMAL, [
    { make: (f, all) => [`Which normal form requires: ${f[1]}?`, f[0], col(all, 0), `${f[0]}: ${f[1]}.`, "Normalization", "Hard"] },
    { make: (f) => [`What is the main requirement of ${f[0]}?`, f[1], DB_NORMAL.map((r) => r[1]), `${f[0]}: ${f[1]}.`, "Normalization", "Hard"] },
  ]));
  out.push(...factGen(S, "db_acid", 6203, DB_ACID, [tWhatIs("Transactions", "Medium"), tWhichTerm("Transactions", "Medium", "ACID property")]));
  out.push(...matchGen(S, "db_mc", 6204, DB_CONCEPTS, "Concepts"));
  out.push(...matchGen(S, "db_mn", 6205, DB_NORMAL, "Normalization"));
  return out;
}

/* =================================================================== *
 * SQL
 * =================================================================== */
const SQL_KW: Row[] = [
  ["SELECT", "Retrieves rows from one or more tables", "DQL"],
  ["INSERT", "Adds new rows to a table", "DML"],
  ["UPDATE", "Modifies existing rows", "DML"],
  ["DELETE", "Removes rows from a table", "DML"],
  ["WHERE", "Filters rows before grouping", "Clause"],
  ["GROUP BY", "Groups rows sharing a value for aggregation", "Clause"],
  ["HAVING", "Filters groups after aggregation", "Clause"],
  ["ORDER BY", "Sorts the result set", "Clause"],
  ["JOIN", "Combines rows from two tables based on a condition", "Clause"],
  ["DISTINCT", "Removes duplicate rows from results", "Clause"],
  ["CREATE", "Defines a new database object", "DDL"],
  ["ALTER", "Modifies the structure of an object", "DDL"],
  ["DROP", "Deletes a database object entirely", "DDL"],
  ["TRUNCATE", "Removes all rows quickly without logging each row", "DDL"],
  ["GRANT", "Gives privileges to a user", "DCL"],
  ["REVOKE", "Removes privileges from a user", "DCL"],
  ["COMMIT", "Permanently saves the current transaction", "TCL"],
  ["ROLLBACK", "Undoes changes in the current transaction", "TCL"],
  ["LIMIT", "Restricts the number of returned rows", "Clause"],
  ["LIKE", "Matches a pattern with wildcards", "Operator"],
];
const SQL_FUNC: Row[] = [
  ["COUNT()", "Returns the number of rows", "Aggregate"],
  ["SUM()", "Returns the total of a numeric column", "Aggregate"],
  ["AVG()", "Returns the average of a numeric column", "Aggregate"],
  ["MAX()", "Returns the largest value", "Aggregate"],
  ["MIN()", "Returns the smallest value", "Aggregate"],
  ["UPPER()", "Converts text to uppercase", "String"],
  ["LOWER()", "Converts text to lowercase", "String"],
  ["LENGTH()", "Returns the number of characters", "String"],
  ["ROUND()", "Rounds a number to given decimals", "Numeric"],
  ["NOW()", "Returns the current date and time", "Date"],
  ["COALESCE()", "Returns the first non-NULL value", "Null-handling"],
  ["SUBSTRING()", "Extracts part of a string", "String"],
];
const SQL_JOINS: Row[] = [
  ["INNER JOIN", "Returns only rows matching in both tables", "Join"],
  ["LEFT JOIN", "Returns all left rows plus matches from the right", "Join"],
  ["RIGHT JOIN", "Returns all right rows plus matches from the left", "Join"],
  ["FULL OUTER JOIN", "Returns all rows from both tables", "Join"],
  ["CROSS JOIN", "Returns the Cartesian product of both tables", "Join"],
  ["SELF JOIN", "Joins a table to itself", "Join"],
];

function genSQL(): MCQQuestion[] {
  const S = "SQL";
  const out: MCQQuestion[] = [];
  out.push(...factGen(S, "sql_kw", 6301, SQL_KW, [
    { make: (f, all) => [`What does the SQL keyword ${f[0]} do?`, f[1], col(all, 1), `${f[0]}: ${f[1]}.`, "Keywords", "Easy"] },
    { make: (f, all) => [`Which SQL keyword ${f[1].charAt(0).toLowerCase() + f[1].slice(1)}?`, f[0], col(all, 0), `${f[0]} ${f[1].toLowerCase()}.`, "Keywords", "Medium"] },
    tCategory("Keywords", "Hard", "SQL category (DDL/DML/etc.)"),
  ]));
  out.push(...factGen(S, "sql_fn", 6302, SQL_FUNC, [
    { make: (f, all) => [`What does the SQL function ${f[0]} do?`, f[1], col(all, 1), `${f[0]}: ${f[1]}.`, "Functions", "Medium"] },
    tCategory("Functions", "Medium", "function type"),
  ]));
  out.push(...factGen(S, "sql_join", 6303, SQL_JOINS, [
    { make: (f, all) => [`What does an ${f[0]} return?`, f[1], col(all, 1), `${f[0]}: ${f[1]}.`, "Joins", "Medium"] },
    { make: (f, all) => [`Which join ${f[1].charAt(0).toLowerCase() + f[1].slice(1)}?`, f[0], col(all, 0), `${f[0]}: ${f[1]}.`, "Joins", "Hard"] },
  ]));
  out.push(...matchGen(S, "sql_mk", 6304, SQL_KW, "Keywords"));
  out.push(...matchGen(S, "sql_mf", 6305, SQL_FUNC, "Functions"));
  out.push(...matchGen(S, "sql_mj", 6306, SQL_JOINS, "Joins"));
  out.push(...catGen(S, "sql_ck", 6307, SQL_KW, 0, 2));
  out.push(...catGen(S, "sql_cf", 6308, SQL_FUNC, 0, 2));
  return out;
}

/* =================================================================== *
 * DATA STRUCTURES & ALGORITHMS (facts + computed complexity)
 * =================================================================== */
const DS_COMPLEXITY: Row[] = [
  ["Array access by index", "O(1)", "Array"],
  ["Array search (unsorted)", "O(n)", "Array"],
  ["Binary search (sorted array)", "O(log n)", "Searching"],
  ["Linear search", "O(n)", "Searching"],
  ["Insert at head of linked list", "O(1)", "Linked List"],
  ["Insert at tail of singly linked list (no tail ptr)", "O(n)", "Linked List"],
  ["Stack push/pop", "O(1)", "Stack"],
  ["Queue enqueue/dequeue", "O(1)", "Queue"],
  ["Hash table lookup (average)", "O(1)", "Hashing"],
  ["Hash table lookup (worst case)", "O(n)", "Hashing"],
  ["BST search (balanced)", "O(log n)", "Tree"],
  ["BST search (worst case, skewed)", "O(n)", "Tree"],
  ["Merge sort", "O(n log n)", "Sorting"],
  ["Quick sort (average)", "O(n log n)", "Sorting"],
  ["Quick sort (worst case)", "O(n^2)", "Sorting"],
  ["Bubble sort", "O(n^2)", "Sorting"],
  ["Selection sort", "O(n^2)", "Sorting"],
  ["Insertion sort (worst case)", "O(n^2)", "Sorting"],
  ["Heap sort", "O(n log n)", "Sorting"],
  ["BFS / DFS traversal", "O(V + E)", "Graph"],
  ["Dijkstra (with min-heap)", "O((V+E) log V)", "Graph"],
  ["Building a heap", "O(n)", "Heap"],
  ["Heap insert/extract", "O(log n)", "Heap"],
  ["Naive recursive Fibonacci", "O(2^n)", "Recursion"],
];
const DS_CONCEPTS: Row[] = [
  ["Stack", "A LIFO (Last-In-First-Out) data structure"],
  ["Queue", "A FIFO (First-In-First-Out) data structure"],
  ["Deque", "A double-ended queue allowing insert/remove at both ends"],
  ["Linked List", "A linear structure of nodes connected by pointers"],
  ["Binary Tree", "A tree where each node has at most two children"],
  ["Binary Search Tree", "A binary tree with left < root < right ordering"],
  ["Heap", "A complete binary tree satisfying the heap property"],
  ["Hash Table", "A structure mapping keys to values using a hash function"],
  ["Graph", "A set of vertices connected by edges"],
  ["Trie", "A tree used for efficient prefix-based string storage"],
  ["AVL Tree", "A self-balancing binary search tree"],
  ["Priority Queue", "A queue where elements are served by priority"],
  ["Circular Queue", "A queue where the last position connects to the first"],
  ["Adjacency List", "A graph representation storing neighbors per vertex"],
  ["Adjacency Matrix", "A 2D matrix representation of graph edges"],
  ["Doubly Linked List", "Nodes with pointers to both next and previous"],
  ["Circular Linked List", "A list whose last node links back to the first"],
  ["Complete Binary Tree", "All levels filled except possibly the last (left-filled)"],
  ["Full Binary Tree", "Every node has either 0 or 2 children"],
  ["Balanced Tree", "A tree whose height is kept logarithmic"],
  ["Red-Black Tree", "A self-balancing BST using node colors"],
  ["B-Tree", "A balanced multi-way tree used in databases"],
  ["Min-Heap", "A heap where each parent is smaller than its children"],
  ["Max-Heap", "A heap where each parent is larger than its children"],
  ["Hash Function", "Maps keys to indices in a hash table"],
  ["Collision", "When two keys hash to the same index"],
  ["Chaining", "Resolving collisions with a linked list per bucket"],
  ["Open Addressing", "Resolving collisions by probing for another slot"],
  ["Load Factor", "The ratio of entries to buckets in a hash table"],
  ["In-order Traversal", "Left, root, right traversal of a tree"],
  ["Pre-order Traversal", "Root, left, right traversal of a tree"],
  ["Post-order Traversal", "Left, right, root traversal of a tree"],
  ["Level-order Traversal", "Visiting tree nodes level by level"],
  ["Topological Sort", "A linear ordering of a DAG's vertices"],
  ["Spanning Tree", "A subgraph connecting all vertices without cycles"],
  ["Minimum Spanning Tree", "A spanning tree with minimum total edge weight"],
  ["Dijkstra's Algorithm", "Shortest path for non-negative edge weights"],
  ["Bellman-Ford", "Shortest path allowing negative edge weights"],
  ["Dynamic Programming", "Solving problems by reusing subproblem results"],
  ["Greedy Algorithm", "Making the locally optimal choice at each step"],
  ["Backtracking", "Trying options and undoing them on failure"],
  ["Divide and Conquer", "Splitting a problem, solving parts, then combining"],
  ["Two Pointers", "A technique using two indices to scan data"],
  ["Sliding Window", "A technique using a moving range over a sequence"],
  ["Base Case", "The condition that stops a recursion"],
  ["DAG", "A directed graph with no cycles"],
  ["Memoization", "Caching results of expensive function calls"],
  ["Binary Heap", "A complete binary tree stored in an array"],
];

function genDS(): MCQQuestion[] {
  const S = "Data Structures & Algorithms";
  const out: MCQQuestion[] = [];
  const bigO = ["O(1)", "O(log n)", "O(n)", "O(n log n)", "O(n^2)", "O(2^n)", "O(V + E)"];
  out.push(...factGen(S, "ds_cx", 6401, DS_COMPLEXITY, [
    { make: (f) => [`What is the time complexity of: ${f[0]}?`, f[1], bigO, `${f[0]} is ${f[1]}.`, f[2], "Medium"] },
  ]));
  out.push(...factGen(S, "ds_con", 6402, DS_CONCEPTS, [tWhatIs("Concepts", "Easy"), tWhichTerm("Concepts", "Medium", "data structure")]));
  out.push(...matchGen(S, "ds_mc", 6403, DS_CONCEPTS, "Concepts"));
  out.push(...matchGen(S, "ds_mx", 6404, DS_COMPLEXITY, "Complexity"));
  out.push(...catGen(S, "ds_cat", 6405, DS_COMPLEXITY, 0, 2));
  return out;
}

/* =================================================================== *
 * OOP
 * =================================================================== */
const OOP_CONCEPTS: Row[] = [
  ["Encapsulation", "Bundling data with methods and hiding internal state"],
  ["Inheritance", "A class acquiring properties and behavior of another class"],
  ["Polymorphism", "One interface behaving differently based on the object"],
  ["Abstraction", "Exposing essential features while hiding complexity"],
  ["Class", "A blueprint from which objects are created"],
  ["Object", "An instance of a class"],
  ["Method Overloading", "Same method name with different parameter lists (compile-time)"],
  ["Method Overriding", "Redefining a parent method in a subclass (run-time)"],
  ["Constructor", "A special method that initializes a new object"],
  ["Destructor", "A method invoked when an object is destroyed"],
  ["Interface", "A contract of methods a class must implement"],
  ["Abstract Class", "A class that cannot be instantiated and may have abstract methods"],
  ["Composition", "Building objects that contain other objects (has-a)"],
  ["Aggregation", "A weak has-a relationship where parts can exist independently"],
  ["Association", "A general relationship between two classes"],
  ["Static Method", "A method belonging to the class rather than an instance"],
  ["Virtual Function", "A function resolved at runtime for dynamic dispatch"],
  ["Multiple Inheritance", "A class inheriting from more than one base class"],
  ["Message Passing", "Objects communicating by invoking each other's methods"],
  ["Coupling", "The degree of dependency between classes"],
  ["Cohesion", "How focused a class's responsibilities are"],
  ["Getter", "A method that returns a private field's value"],
  ["Setter", "A method that updates a private field's value"],
  ["this pointer", "A reference to the current object instance"],
  ["super", "A reference used to access the parent class"],
  ["Overloading", "Same method name with different parameters (compile-time)"],
  ["Overriding", "Redefining an inherited method (run-time)"],
  ["Access Modifier", "Keyword controlling visibility (public/private/protected)"],
  ["Private Member", "A member accessible only within its own class"],
  ["Protected Member", "A member accessible in the class and its subclasses"],
  ["Public Member", "A member accessible from anywhere"],
  ["Static Variable", "A variable shared by all instances of a class"],
  ["Instance Variable", "A field unique to each object"],
  ["Final Method", "A method that cannot be overridden"],
  ["Sealed Class", "A class that cannot be inherited"],
  ["Upcasting", "Treating a derived object as its base type"],
  ["Downcasting", "Casting a base reference back to a derived type"],
  ["Dynamic Binding", "Resolving a method call at run time"],
  ["Static Binding", "Resolving a method call at compile time"],
  ["Object Slicing", "Losing derived data when copying to a base object"],
  ["Friend Function", "A non-member function granted access to private members"],
  ["Pure Virtual Function", "A virtual function with no body making a class abstract"],
  ["Copy Constructor", "A constructor that initializes from another object"],
  ["Default Constructor", "A constructor taking no arguments"],
  ["Delegation", "One object handing work to another object"],
  ["Immutable Object", "An object whose state cannot change after creation"],
  ["Has-a Relationship", "A relationship expressed by composition/aggregation"],
  ["Is-a Relationship", "A relationship expressed by inheritance"],
];
const OOP_PATTERNS: Row[] = [
  ["Singleton", "Ensures a class has only one instance", "Creational"],
  ["Factory", "Creates objects without specifying the exact class", "Creational"],
  ["Builder", "Constructs complex objects step by step", "Creational"],
  ["Prototype", "Creates new objects by cloning an existing one", "Creational"],
  ["Adapter", "Lets incompatible interfaces work together", "Structural"],
  ["Decorator", "Adds behavior to objects dynamically", "Structural"],
  ["Facade", "Provides a simplified interface to a subsystem", "Structural"],
  ["Proxy", "Provides a placeholder controlling access to an object", "Structural"],
  ["Observer", "Notifies dependents automatically when state changes", "Behavioral"],
  ["Strategy", "Encapsulates interchangeable algorithms", "Behavioral"],
  ["Command", "Encapsulates a request as an object", "Behavioral"],
  ["Iterator", "Provides sequential access to elements", "Behavioral"],
];

function genOOP(): MCQQuestion[] {
  const S = "OOP";
  const out: MCQQuestion[] = [];
  out.push(...factGen(S, "oop_con", 6501, OOP_CONCEPTS, [tWhatIs("Concepts", "Medium"), tWhichTerm("Concepts", "Medium", "OOP concept")]));
  out.push(...factGen(S, "oop_pat", 6502, OOP_PATTERNS, [
    { make: (f, all) => [`Which design pattern: ${f[1]}?`, f[0], col(all, 0), `${f[0]} — ${f[1]}.`, "Design Patterns", "Hard"] },
    tCategory("Design Patterns", "Hard", "pattern category"),
  ]));
  out.push(...matchGen(S, "oop_mc", 6503, OOP_CONCEPTS, "Concepts"));
  out.push(...matchGen(S, "oop_mp", 6504, OOP_PATTERNS, "Design Patterns"));
  out.push(...catGen(S, "oop_cat", 6505, OOP_PATTERNS, 0, 2));
  return out;
}

/* =================================================================== *
 * SOFTWARE ENGINEERING
 * =================================================================== */
const SE_CONCEPTS: Row[] = [
  ["Waterfall", "A linear sequential SDLC model"],
  ["Agile", "Iterative development emphasizing collaboration and change"],
  ["Scrum", "An agile framework using sprints and defined roles"],
  ["Sprint", "A fixed time-boxed iteration in Scrum"],
  ["Kanban", "A visual workflow method limiting work in progress"],
  ["Unit Testing", "Testing individual components in isolation"],
  ["Integration Testing", "Testing combined modules together"],
  ["System Testing", "Testing the complete integrated system"],
  ["Regression Testing", "Re-testing to ensure changes didn't break existing features"],
  ["Black-box Testing", "Testing without knowledge of internal code"],
  ["White-box Testing", "Testing based on internal code structure"],
  ["Refactoring", "Improving code structure without changing behavior"],
  ["Version Control", "Tracking and managing changes to source code"],
  ["Continuous Integration", "Frequently merging and automatically testing code"],
  ["Technical Debt", "The cost of choosing an easy solution over a better one"],
  ["Code Review", "Systematic examination of code by peers"],
  ["Coupling", "The degree of interdependence between modules"],
  ["Cohesion", "How closely related the responsibilities of a module are"],
  ["Use Case", "A description of how users interact with the system"],
  ["Sprint Retrospective", "A meeting to reflect on and improve the process"],
  ["Spiral Model", "A risk-driven SDLC combining iterative and waterfall ideas"],
  ["V-Model", "An SDLC where each dev phase has a matching test phase"],
  ["Prototype Model", "Building an early sample to refine requirements"],
  ["Incremental Model", "Delivering the system in successive functional increments"],
  ["Product Owner", "The Scrum role that prioritizes the backlog"],
  ["Scrum Master", "The Scrum role that facilitates the process"],
  ["Product Backlog", "An ordered list of everything the product may need"],
  ["Sprint Backlog", "The work selected for the current sprint"],
  ["Daily Standup", "A short daily meeting to sync the team"],
  ["User Story", "A short feature description from the user's perspective"],
  ["Story Point", "A relative estimate of effort for a story"],
  ["Velocity", "The amount of work a team completes per sprint"],
  ["Burndown Chart", "A chart showing remaining work over time"],
  ["Acceptance Criteria", "Conditions a feature must meet to be accepted"],
  ["Smoke Testing", "A quick check that core functions work"],
  ["Alpha Testing", "Testing by internal staff before release"],
  ["Beta Testing", "Testing by real users before general release"],
  ["Test Case", "A set of inputs and expected results to verify behavior"],
  ["Test-Driven Development", "Writing tests before the implementation"],
  ["Pair Programming", "Two developers writing code together at one workstation"],
  ["Continuous Deployment", "Automatically releasing every passing change to production"],
  ["Branching", "Maintaining parallel lines of development in VCS"],
  ["Merge Conflict", "Competing edits that VCS cannot auto-resolve"],
  ["Pull Request", "A request to review and merge code changes"],
  ["Commit", "A saved snapshot of changes in version control"],
  ["Design Pattern", "A reusable solution to a common design problem"],
  ["UML", "A standardized modeling language for software design"],
  ["Functional Requirement", "What the system should do"],
  ["Non-functional Requirement", "Quality attributes like performance or security"],
  ["Maintainability", "How easily software can be modified"],
  ["Scalability", "The ability to handle growing load"],
  ["Modularity", "Dividing a system into independent components"],
  ["SRS", "A document specifying software requirements"],
  ["Waterfall Phase", "A stage such as requirements, design, or testing"],
  ["Feasibility Study", "An assessment of whether a project is viable"],
];
const SE_SOLID: Row[] = [
  ["Single Responsibility", "A class should have only one reason to change", "SOLID"],
  ["Open/Closed", "Open for extension, closed for modification", "SOLID"],
  ["Liskov Substitution", "Subtypes must be substitutable for their base types", "SOLID"],
  ["Interface Segregation", "Clients shouldn't depend on methods they don't use", "SOLID"],
  ["Dependency Inversion", "Depend on abstractions, not concretions", "SOLID"],
];

function genSE(): MCQQuestion[] {
  const S = "Software Engineering";
  const out: MCQQuestion[] = [];
  out.push(...factGen(S, "se_con", 6601, SE_CONCEPTS, [tWhatIs("Concepts", "Medium"), tWhichTerm("Concepts", "Medium", "concept")]));
  out.push(...factGen(S, "se_solid", 6602, SE_SOLID, [
    { make: (f, all) => [`Which SOLID principle states: "${f[1]}"?`, f[0], col(all, 0), `${f[0]} Principle: ${f[1]}.`, "SOLID", "Hard"] },
    { make: (f) => [`What does the ${f[0]} Principle state?`, f[1], SE_SOLID.map((r) => r[1]), `${f[0]}: ${f[1]}.`, "SOLID", "Hard"] },
  ]));
  out.push(...matchGen(S, "se_mc", 6603, SE_CONCEPTS, "Concepts"));
  return out;
}

/* =================================================================== *
 * CYBERSECURITY
 * =================================================================== */
const CY_CONCEPTS: Row[] = [
  ["Phishing", "Tricking users into revealing credentials via fake messages"],
  ["Malware", "Malicious software designed to harm or exploit systems"],
  ["Ransomware", "Malware that encrypts data and demands payment"],
  ["SQL Injection", "Injecting malicious SQL through unsanitized input"],
  ["XSS", "Injecting scripts that run in other users' browsers"],
  ["CSRF", "Forcing a user to perform unwanted actions while authenticated"],
  ["DDoS", "Overwhelming a service with traffic from many sources"],
  ["Man-in-the-Middle", "Intercepting communication between two parties"],
  ["Brute Force", "Trying many passwords until one works"],
  ["Firewall", "Filters network traffic based on security rules"],
  ["Encryption", "Converting data into an unreadable form using a key"],
  ["Symmetric Encryption", "Uses the same key to encrypt and decrypt"],
  ["Asymmetric Encryption", "Uses a public/private key pair"],
  ["Hashing", "One-way transformation producing a fixed-size digest"],
  ["Digital Signature", "Verifies authenticity and integrity using keys"],
  ["Two-Factor Authentication", "Requires two independent verification factors"],
  ["Zero-day", "A vulnerability unknown to the vendor with no patch"],
  ["VPN", "Creates a secure encrypted tunnel over a public network"],
  ["Social Engineering", "Manipulating people into breaking security"],
  ["Penetration Testing", "Authorized simulated attacks to find weaknesses"],
  ["Spyware", "Malware that secretly gathers user information"],
  ["Trojan Horse", "Malware disguised as legitimate software"],
  ["Worm", "Self-replicating malware that spreads across networks"],
  ["Rootkit", "Malware that hides deep in the OS to evade detection"],
  ["Keylogger", "Records keystrokes to steal credentials"],
  ["Adware", "Software that displays unwanted advertisements"],
  ["Botnet", "A network of compromised machines controlled by an attacker"],
  ["IDS", "Detects suspicious activity and raises alerts"],
  ["IPS", "Detects and actively blocks malicious traffic"],
  ["Honeypot", "A decoy system used to lure and study attackers"],
  ["Salting", "Adding random data to a password before hashing"],
  ["Public Key", "The shareable key in asymmetric encryption"],
  ["Private Key", "The secret key kept by the owner in asymmetric encryption"],
  ["AES", "A widely used symmetric block cipher"],
  ["RSA", "A widely used asymmetric encryption algorithm"],
  ["TLS", "A protocol that encrypts data in transit"],
  ["Certificate Authority", "A trusted entity that issues digital certificates"],
  ["Least Privilege", "Granting only the minimum access needed"],
  ["Defense in Depth", "Using multiple layers of security controls"],
  ["SIEM", "Aggregates and analyzes security event logs"],
  ["Vulnerability", "A weakness that can be exploited"],
  ["Exploit", "Code or technique that takes advantage of a vulnerability"],
  ["Patch", "An update that fixes a security flaw"],
  ["Sandbox", "An isolated environment to safely run untrusted code"],
  ["OTP", "A one-time password valid for a single login"],
  ["Biometrics", "Authentication using physical characteristics"],
  ["Access Control List", "Rules specifying which users can access a resource"],
  ["Non-repudiation", "Assurance that an action cannot be denied later"],
  ["Session Hijacking", "Stealing a valid session token to impersonate a user"],
  ["Privilege Escalation", "Gaining higher access rights than intended"],
  ["Data Breach", "Unauthorized access to confidential data"],
  ["Spoofing", "Faking an identity such as an IP or email address"],
  ["Whaling", "Phishing that targets high-profile executives"],
  ["Smishing", "Phishing carried out via SMS text messages"],
  ["Vishing", "Phishing carried out via voice calls"],
  ["Air Gap", "Isolating a system from unsecured networks"],
  ["Cipher", "An algorithm for encryption or decryption"],
  ["Plaintext", "Readable data before encryption"],
  ["Ciphertext", "Encrypted, unreadable data"],
  ["Payload", "The part of malware that performs the malicious action"],
  ["Backdoor", "A hidden method of bypassing normal authentication"],
  ["Patch Management", "The process of applying updates to fix vulnerabilities"],
];
const CY_CIA: Row[] = [
  ["Confidentiality", "Ensuring information is accessible only to authorized parties", "CIA Triad"],
  ["Integrity", "Ensuring data is accurate and unaltered", "CIA Triad"],
  ["Availability", "Ensuring systems and data are accessible when needed", "CIA Triad"],
];

function genCyber(): MCQQuestion[] {
  const S = "Cybersecurity Fundamentals";
  const out: MCQQuestion[] = [];
  out.push(...factGen(S, "cy_con", 6701, CY_CONCEPTS, [tWhatIs("Concepts", "Medium"), tWhichTerm("Concepts", "Medium", "term/attack")]));
  out.push(...factGen(S, "cy_cia", 6702, CY_CIA, [tWhatIs("CIA Triad", "Easy"), tWhichTerm("CIA Triad", "Medium", "CIA property")]));
  out.push(...matchGen(S, "cy_mc", 6703, CY_CONCEPTS, "Concepts"));
  return out;
}

/* =================================================================== *
 * WEB TECHNOLOGIES
 * =================================================================== */
const WEB_HTML: Row[] = [
  ["<a>", "Creates a hyperlink", "HTML"],
  ["<img>", "Embeds an image", "HTML"],
  ["<p>", "Defines a paragraph", "HTML"],
  ["<div>", "A generic block-level container", "HTML"],
  ["<span>", "A generic inline container", "HTML"],
  ["<ul>", "An unordered (bulleted) list", "HTML"],
  ["<ol>", "An ordered (numbered) list", "HTML"],
  ["<table>", "Defines a table", "HTML"],
  ["<form>", "Defines an input form", "HTML"],
  ["<input>", "An input control", "HTML"],
  ["<h1>", "The top-level heading", "HTML"],
  ["<br>", "Inserts a line break", "HTML"],
];
const WEB_CONCEPTS: Row[] = [
  ["GET", "HTTP method to retrieve data (safe, idempotent)"],
  ["POST", "HTTP method to submit data that creates a resource"],
  ["PUT", "HTTP method to replace a resource (idempotent)"],
  ["DELETE", "HTTP method to remove a resource"],
  ["PATCH", "HTTP method to partially update a resource"],
  ["DOM", "A tree representation of an HTML document"],
  ["JSON", "A lightweight text data-interchange format"],
  ["AJAX", "Technique for asynchronous requests without reloading"],
  ["Cookie", "Small data stored by the browser per site"],
  ["localStorage", "Browser storage that persists with no expiry"],
  ["sessionStorage", "Browser storage cleared when the tab closes"],
  ["CSS", "A language for styling HTML elements"],
  ["Flexbox", "A CSS layout model for one-dimensional layouts"],
  ["Grid", "A CSS layout model for two-dimensional layouts"],
  ["REST", "An architectural style using HTTP verbs on resources"],
  ["CORS", "A mechanism controlling cross-origin resource sharing"],
  ["CDN", "A network of edge servers that cache content near users"],
  ["Responsive Design", "Layouts that adapt to different screen sizes"],
  ["SPA", "A web app that loads a single page and updates dynamically"],
  ["WebSocket", "A protocol for full-duplex real-time communication"],
  ["HTML", "The standard markup language for web pages"],
  ["URL", "The address of a web resource"],
  ["HTTP", "The protocol for transferring web pages"],
  ["HTTPS", "HTTP secured with TLS encryption"],
  ["Header", "Metadata sent with an HTTP request or response"],
  ["Query String", "Key-value pairs appended to a URL after ?"],
  ["Viewport", "The visible area of a web page on a device"],
  ["Media Query", "A CSS rule that applies styles based on device features"],
  ["Pseudo-class", "A CSS selector for a special state like :hover"],
  ["Box Model", "The layout model of content, padding, border, and margin"],
  ["Specificity", "The rule that decides which CSS selector wins"],
  ["Event Listener", "Code that runs in response to a user action"],
  ["Callback", "A function passed to be run later"],
  ["Promise", "An object representing a future asynchronous value"],
  ["async/await", "Syntax for writing asynchronous code sequentially"],
  ["Closure", "A function that remembers variables from its outer scope"],
  ["Hoisting", "JavaScript moving declarations to the top of their scope"],
  ["let", "A block-scoped variable declaration"],
  ["const", "A block-scoped constant declaration"],
  ["var", "A function-scoped variable declaration"],
  ["Arrow Function", "A concise function syntax with lexical this"],
  ["Template Literal", "A backtick string allowing interpolation"],
  ["Virtual DOM", "An in-memory UI representation for efficient updates"],
  ["Session", "Server-side state for a user across requests"],
  ["JWT", "A compact token format for stateless authentication"],
  ["Same-Origin Policy", "A browser rule restricting cross-origin access"],
  ["Minification", "Removing whitespace to shrink code files"],
  ["Transpiler", "A tool converting one source language to another"],
  ["Bundler", "A tool combining modules into fewer files"],
  ["Semantic HTML", "Using tags that convey meaning like <article>"],
  ["Favicon", "The small icon shown in a browser tab"],
  ["Web Server", "Software that serves web content over HTTP"],
  ["Cache-Control", "An HTTP header controlling how responses are cached"],
  ["Progressive Web App", "A web app that behaves like a native app"],
];
const WEB_CSS: Row[] = [
  ["color", "Sets the text (foreground) color", "CSS Property"],
  ["background-color", "Sets the background color", "CSS Property"],
  ["margin", "Sets the space outside an element", "CSS Property"],
  ["padding", "Sets the space inside an element", "CSS Property"],
  ["display", "Sets how an element is rendered (block/flex/etc.)", "CSS Property"],
  ["position", "Sets the positioning method of an element", "CSS Property"],
  ["font-size", "Sets the size of the text", "CSS Property"],
  ["z-index", "Controls the stacking order of elements", "CSS Property"],
];

function genWeb(): MCQQuestion[] {
  const S = "Web Technologies";
  const out: MCQQuestion[] = [];
  out.push(...factGen(S, "web_html", 6801, WEB_HTML, [
    { make: (f, all) => [`What does the HTML tag ${f[0]} do?`, f[1], col(all, 1), `${f[0]}: ${f[1]}.`, "HTML", "Easy"] },
    { make: (f, all) => [`Which HTML tag ${f[1].charAt(0).toLowerCase() + f[1].slice(1)}?`, f[0], col(all, 0), `${f[0]}: ${f[1]}.`, "HTML", "Medium"] },
  ]));
  out.push(...factGen(S, "web_con", 6802, WEB_CONCEPTS, [tWhatIs("Concepts", "Medium"), tWhichTerm("Concepts", "Medium", "term")]));
  out.push(...factGen(S, "web_css", 6803, WEB_CSS, [
    { make: (f, all) => [`What does the CSS property "${f[0]}" do?`, f[1], col(all, 1), `${f[0]}: ${f[1]}.`, "CSS", "Easy"] },
    { make: (f, all) => [`Which CSS property ${f[1].charAt(0).toLowerCase() + f[1].slice(1)}?`, f[0], col(all, 0), `${f[0]}: ${f[1]}.`, "CSS", "Medium"] },
  ]));
  out.push(...matchGen(S, "web_mc", 6804, WEB_CONCEPTS, "Concepts"));
  out.push(...matchGen(S, "web_mh", 6805, WEB_HTML, "HTML"));
  out.push(...matchGen(S, "web_ms", 6806, WEB_CSS, "CSS"));
  return out;
}

/* =================================================================== *
 * CLOUD COMPUTING
 * =================================================================== */
const CLOUD_CONCEPTS: Row[] = [
  ["IaaS", "Provides virtualized compute, storage and network resources"],
  ["PaaS", "Provides a platform to develop and deploy apps without managing infra"],
  ["SaaS", "Delivers ready-to-use software over the internet"],
  ["FaaS", "Runs code in response to events without managing servers"],
  ["Public Cloud", "Cloud resources owned and operated by a third party"],
  ["Private Cloud", "Cloud infrastructure dedicated to a single organization"],
  ["Hybrid Cloud", "Combines private and public cloud resources"],
  ["Elasticity", "Automatically scaling resources with demand"],
  ["Scalability", "The ability to handle growth by adding resources"],
  ["Load Balancer", "Distributes traffic across multiple servers"],
  ["Auto Scaling", "Automatically adjusting the number of instances"],
  ["Virtual Machine", "An emulated computer running on a physical host"],
  ["Container", "A lightweight, isolated runtime packaging an app and its deps"],
  ["Kubernetes", "An orchestration platform for containers"],
  ["Docker", "A platform for building and running containers"],
  ["Serverless", "A model where the provider manages servers automatically"],
  ["CDN", "Caches content on edge servers close to users"],
  ["Multi-tenancy", "Multiple customers sharing the same infrastructure"],
  ["High Availability", "Designing systems to minimize downtime"],
  ["Region", "A geographic area containing cloud data centers"],
  ["Availability Zone", "An isolated data center within a region"],
  ["Object Storage", "Storage that manages data as objects (e.g., S3)"],
  ["Block Storage", "Storage exposed as raw volumes attached to instances"],
  ["Fault Tolerance", "The ability to keep operating despite component failures"],
  ["Disaster Recovery", "Plans to restore service after a major outage"],
  ["Pay-as-you-go", "Billing based only on resources actually consumed"],
  ["Vendor Lock-in", "Difficulty moving away from a specific cloud provider"],
  ["Provisioning", "Allocating and configuring cloud resources"],
  ["Orchestration", "Automated coordination of multiple services/containers"],
  ["Microservices", "An architecture of small, independently deployable services"],
  ["API Gateway", "A single entry point that routes requests to services"],
  ["Message Queue", "A buffer that decouples producers and consumers"],
  ["Edge Computing", "Processing data near where it is generated"],
  ["Cold Storage", "Low-cost storage for rarely accessed data"],
  ["Snapshot", "A point-in-time copy of storage or a VM"],
  ["Elastic IP", "A static public IP that can be reassigned"],
  ["VPC", "A logically isolated virtual network in the cloud"],
  ["Shared Responsibility Model", "Security duties split between provider and customer"],
  ["Serverless Function", "Event-driven code run without managing servers"],
  ["Container Registry", "A store for container images"],
  ["Horizontal Scaling", "Adding more instances to handle load"],
  ["Vertical Scaling", "Increasing the resources of a single instance"],
  ["Data Center", "A facility housing servers and infrastructure"],
  ["Hypervisor", "Software that creates and runs virtual machines"],
  ["Multi-cloud", "Using services from more than one cloud provider"],
  ["Bare Metal", "A physical server dedicated to a single tenant"],
  ["Throughput", "The amount of work or data processed per unit time"],
  ["SLA", "A contract defining expected service availability"],
  ["Ingress", "Incoming network traffic to a service"],
  ["Egress", "Outgoing network traffic from a service"],
  ["Blob", "A binary large object stored in the cloud"],
  ["Managed Service", "A service the provider operates and maintains for you"],
];
const CLOUD_MODELS: Row[] = [
  ["IaaS", "Infrastructure as a Service", "Service Model"],
  ["PaaS", "Platform as a Service", "Service Model"],
  ["SaaS", "Software as a Service", "Service Model"],
  ["FaaS", "Function as a Service", "Service Model"],
];

function genCloud(): MCQQuestion[] {
  const S = "Cloud Computing";
  const out: MCQQuestion[] = [];
  out.push(...factGen(S, "cl_con", 6901, CLOUD_CONCEPTS, [tWhatIs("Concepts", "Medium"), tWhichTerm("Concepts", "Medium", "term")]));
  out.push(...factGen(S, "cl_model", 6902, CLOUD_MODELS, [
    { make: (f, all) => [`What does the cloud model ${f[0]} stand for?`, f[1], col(all, 1), `${f[0]} = ${f[1]}.`, "Service Models", "Easy"] },
  ]));
  out.push(...matchGen(S, "cl_mc", 6903, CLOUD_CONCEPTS, "Concepts"));
  return out;
}

/* =================================================================== *
 * LANGUAGE CONCEPT FACTS (C, C++, Java, Python) - supplement output gen
 * =================================================================== */
const C_CONCEPTS: Row[] = [
  ["malloc()", "Allocates uninitialized memory on the heap"],
  ["calloc()", "Allocates zero-initialized memory"],
  ["free()", "Releases previously allocated heap memory"],
  ["realloc()", "Resizes a previously allocated block"],
  ["pointer", "A variable that stores a memory address"],
  ["NULL pointer", "A pointer that points to no valid location"],
  ["sizeof", "An operator returning the size of a type in bytes"],
  ["struct", "A user-defined type grouping related variables"],
  ["union", "A type where all members share the same memory"],
  ["const", "A qualifier marking a variable as read-only"],
  ["static variable", "A variable that retains its value between calls"],
  ["dangling pointer", "A pointer referencing freed or invalid memory"],
  ["segmentation fault", "A crash from accessing invalid memory"],
  ["array", "A contiguous block of same-type elements"],
  ["string in C", "A null-terminated array of characters"],
  ["header file", "A file with declarations included via #include"],
  ["preprocessor", "Handles directives like #define before compilation"],
  ["recursion", "A function calling itself"],
];
const CPP_CONCEPTS: Row[] = [
  ["std::vector", "A dynamic array from the STL"],
  ["std::map", "An ordered key-value container (balanced BST)"],
  ["std::unordered_map", "A hash-based key-value container with O(1) average lookup"],
  ["std::set", "An ordered container of unique elements"],
  ["reference", "An alias for an existing variable"],
  ["constructor", "A method that initializes an object"],
  ["destructor", "A method called when an object goes out of scope"],
  ["virtual function", "Enables runtime polymorphism via the vtable"],
  ["template", "Enables generic programming with type parameters"],
  ["operator overloading", "Defining custom behavior for operators"],
  ["namespace", "A scope to group identifiers and avoid name clashes"],
  ["RAII", "Tying resource lifetime to object lifetime"],
  ["smart pointer", "An object managing dynamic memory automatically"],
  ["inheritance", "Deriving a class from a base class"],
  ["polymorphism", "One interface with multiple implementations"],
  ["STL", "The Standard Template Library of containers and algorithms"],
  ["iterator", "An object to traverse container elements"],
  ["nullptr", "The C++11 null pointer literal"],
];
const JAVA_CONCEPTS: Row[] = [
  ["JVM", "Executes Java bytecode on any platform"],
  ["JRE", "The runtime environment including the JVM and libraries"],
  ["JDK", "The development kit including the compiler and JRE"],
  ["ArrayList", "A resizable array implementation of List"],
  ["HashMap", "A hash-based key-value map with no ordering guarantee"],
  ["HashSet", "A collection of unique elements backed by a hash map"],
  ["LinkedList", "A doubly-linked list implementation of List/Deque"],
  ["TreeMap", "A sorted key-value map (red-black tree)"],
  ["interface", "A contract of abstract methods a class implements"],
  ["abstract class", "A class that cannot be instantiated directly"],
  ["final", "A keyword preventing inheritance/override/reassignment"],
  ["static", "A member belonging to the class, not an instance"],
  ["String immutability", "String objects cannot be changed after creation"],
  ["StringBuilder", "A mutable sequence of characters"],
  ["checked exception", "An exception that must be declared or handled"],
  ["garbage collection", "Automatic reclamation of unused memory"],
  ["autoboxing", "Automatic conversion between primitives and wrappers"],
  ["polymorphism", "Objects taking many forms via overriding"],
  ["encapsulation", "Restricting field access via getters/setters"],
  ["thread", "A lightweight unit of concurrent execution"],
];
const PY_CONCEPTS: Row[] = [
  ["list", "An ordered, mutable sequence"],
  ["tuple", "An ordered, immutable sequence"],
  ["dict", "A mutable mapping of key-value pairs"],
  ["set", "An unordered collection of unique elements"],
  ["list comprehension", "A concise way to build a list from an iterable"],
  ["generator", "A lazy iterator produced with yield"],
  ["decorator", "A function that wraps and modifies another function"],
  ["lambda", "An anonymous inline function"],
  ["self", "The conventional name for the instance parameter"],
  ["PEP 8", "The official Python style guide"],
  ["GIL", "The Global Interpreter Lock limiting threads to one at a time"],
  ["slicing", "Extracting a subsequence with [start:stop:step]"],
  ["*args", "Collects extra positional arguments into a tuple"],
  ["**kwargs", "Collects extra keyword arguments into a dict"],
  ["is operator", "Tests object identity (same object in memory)"],
  ["== operator", "Tests value equality"],
  ["None", "Python's null / absence-of-value object"],
  ["f-string", "A formatted string literal prefixed with f"],
  ["duck typing", "Type determined by behavior, not explicit class"],
  ["mutable default", "A common pitfall where default args are shared"],
];

function genLangConcepts(): { subject: string; qs: MCQQuestion[] }[] {
  return [
    { subject: "C Programming", qs: [...factGen("C Programming", "c_con", 7101, C_CONCEPTS, [tWhatIs("Concepts", "Medium"), tWhichTerm("Concepts", "Medium", "C construct")]), ...matchGen("C Programming", "c_mc", 7201, C_CONCEPTS, "Concepts")] },
    { subject: "C++", qs: [...factGen("C++", "cpp_con", 7102, CPP_CONCEPTS, [tWhatIs("Concepts", "Medium"), tWhichTerm("Concepts", "Medium", "C++ feature")]), ...matchGen("C++", "cpp_mc", 7202, CPP_CONCEPTS, "Concepts")] },
    { subject: "Java", qs: [...factGen("Java", "java_con", 7103, JAVA_CONCEPTS, [tWhatIs("Concepts", "Medium"), tWhichTerm("Concepts", "Medium", "Java feature")]), ...matchGen("Java", "java_mc", 7203, JAVA_CONCEPTS, "Concepts")] },
    { subject: "Python", qs: [...factGen("Python", "py_con", 7104, PY_CONCEPTS, [tWhatIs("Concepts", "Medium"), tWhichTerm("Concepts", "Medium", "Python feature")]), ...matchGen("Python", "py_mc", 7204, PY_CONCEPTS, "Concepts")] },
  ];
}

export {
  genCN,
  genOS,
  genDBMS,
  genSQL,
  genDS,
  genOOP,
  genSE,
  genCyber,
  genWeb,
  genCloud,
  genLangConcepts,
};

// silence unused import warning safety
export const _rngCheck = Rng;

/* ================================================================== *
 * KNOWLEDGE EXPORT — a flat glossary (term -> definition) aggregated
 * from every fact table above. Used by the PRACTI assistant to answer
 * "what is X", "define X", "difference between X and Y", etc.
 * ================================================================== */
export interface GlossaryEntry {
  subject: string;
  term: string;
  def: string;
}

function g(subject: string, rows: Row[], termCol = 0, defCol = 1): GlossaryEntry[] {
  return rows
    .filter((r) => r[termCol] && r[defCol])
    .map((r) => ({ subject, term: r[termCol], def: r[defCol] }));
}

export const GLOSSARY: GlossaryEntry[] = [
  // Computer Networks
  ...g("Computer Networks", CN_CONCEPTS),
  ...g("Computer Networks", CN_DEVICES),
  ...CN_PORTS.map((r) => ({ subject: "Computer Networks", term: r[0], def: `${r[4]} — default port ${r[1]} over ${r[2]}.` })),
  ...CN_STATUS.map((r) => ({ subject: "Computer Networks", term: `HTTP ${r[0]}`, def: `${r[1]} (${r[2]}).` })),
  // Operating Systems
  ...g("Operating Systems", OS_CONCEPTS),
  ...g("Operating Systems", OS_ALGOS),
  ...g("Operating Systems", OS_DEADLOCK),
  // DBMS
  ...g("DBMS", DB_CONCEPTS),
  ...DB_NORMAL.map((r) => ({ subject: "DBMS", term: r[0], def: r[1] })),
  ...g("DBMS", DB_ACID),
  // SQL
  ...SQL_KW.map((r) => ({ subject: "SQL", term: `${r[0]} (SQL)`, def: `${r[1]} (${r[2]}).` })),
  ...g("SQL", SQL_FUNC),
  ...g("SQL", SQL_JOINS),
  // Data Structures
  ...g("Data Structures & Algorithms", DS_CONCEPTS),
  ...DS_COMPLEXITY.map((r) => ({ subject: "Data Structures & Algorithms", term: r[0], def: `Time complexity: ${r[1]} (${r[2]}).` })),
  // OOP
  ...g("OOP", OOP_CONCEPTS),
  ...g("OOP", OOP_PATTERNS),
  // Software Engineering
  ...g("Software Engineering", SE_CONCEPTS),
  ...g("Software Engineering", SE_SOLID),
  // Cybersecurity
  ...g("Cybersecurity Fundamentals", CY_CONCEPTS),
  ...g("Cybersecurity Fundamentals", CY_CIA),
  // Web
  ...WEB_HTML.map((r) => ({ subject: "Web Technologies", term: `${r[0]} tag`, def: r[1] })),
  ...g("Web Technologies", WEB_CONCEPTS),
  ...WEB_CSS.map((r) => ({ subject: "Web Technologies", term: `${r[0]} (CSS)`, def: r[1] })),
  // Cloud
  ...g("Cloud Computing", CLOUD_CONCEPTS),
  ...CLOUD_MODELS.map((r) => ({ subject: "Cloud Computing", term: r[0], def: `${r[1]} — a cloud service model.` })),
  // Languages
  ...g("C Programming", C_CONCEPTS),
  ...g("C++", CPP_CONCEPTS),
  ...g("Java", JAVA_CONCEPTS),
  ...g("Python", PY_CONCEPTS),
];
