import type { MCQQuestion, Difficulty } from "./types";
import { Rng } from "./rng";
import { opts4 } from "./generators";

type Q = MCQQuestion;

/* ================================================================== *
 * THEORY GENERATORS
 *
 * These produce concept/theory questions (NOT arithmetic output
 * prediction). Three styles:
 *  1. stmtGen  — "Which statement is TRUE / FALSE about X?"
 *  2. errorGen — "This code has a bug. What is the error?"
 *  3. purposeGen — "What is the purpose of X?" (term -> use)
 * All answers are hand-verified for correctness.
 * ================================================================== */

// "Which statement is TRUE?" uses 1 true + 3 false.
// "Which statement is FALSE?" uses 1 false + 3 true.
function stmtGen(
  subject: string,
  prefix: string,
  seed: number,
  topic: string,
  trueArr: string[],
  falseArr: string[],
  difficulty: Difficulty = "Medium"
): Q[] {
  const rng = new Rng(seed);
  const out: Q[] = [];
  let idx = 0;
  // TRUE questions
  for (const t of trueArr) {
    if (falseArr.length < 3) break;
    const distract = rng.shuffle(falseArr).slice(0, 6);
    const o = opts4(t, distract, rng, distract);
    if (o.options.length < 4) continue;
    out.push({
      id: `t_${prefix}_T${idx++}`,
      subject,
      topic,
      difficulty,
      question: "Which of the following statements is TRUE?",
      options: o.options,
      correctIndex: o.correctIndex,
      explanation: `Correct: "${t}" The other options are false.`,
      tags: [topic.toLowerCase(), "theory"],
    });
  }
  // FALSE questions
  idx = 0;
  for (const f of falseArr) {
    if (trueArr.length < 3) break;
    const distract = rng.shuffle(trueArr).slice(0, 6);
    const o = opts4(f, distract, rng, distract);
    if (o.options.length < 4) continue;
    out.push({
      id: `t_${prefix}_F${idx++}`,
      subject,
      topic,
      difficulty,
      question: "Which of the following statements is FALSE?",
      options: o.options,
      correctIndex: o.correctIndex,
      explanation: `The false statement is: "${f}" The other three are true.`,
      tags: [topic.toLowerCase(), "theory"],
    });
  }
  return out;
}

// Error identification. item = [code, correctErrorDesc, ...wrongDescs]
function errorGen(subject: string, prefix: string, seed: number, items: string[][], lang: string): Q[] {
  const rng = new Rng(seed);
  const out: Q[] = [];
  let idx = 0;
  const allWrong = items.flatMap((it) => it.slice(2));
  for (const it of items) {
    const [code, correct, ...wrong] = it;
    const pool = [...wrong, ...rng.shuffle(allWrong).filter((w) => !wrong.includes(w) && w !== correct)].slice(0, 6);
    if (pool.length < 3) continue;
    const o = opts4(correct, pool, rng, pool);
    out.push({
      id: `e_${prefix}_${idx++}`,
      subject,
      topic: "Error Identification",
      difficulty: "Hard",
      question: "The following code contains a bug. What is the error?",
      options: o.options,
      correctIndex: o.correctIndex,
      explanation: `${correct}`,
      tags: ["error", "debugging"],
      code: lang + "\n" + code,
    });
  }
  return out;
}

// Purpose/use questions from [term, purpose] rows.
function purposeGen(subject: string, prefix: string, seed: number, topic: string, rows: string[][]): Q[] {
  const rng = new Rng(seed);
  const out: Q[] = [];
  const purposes = rows.map((r) => r[1]);
  const phrases = [
    (t: string) => `What is the primary purpose of ${t}?`,
    (t: string) => `In which situation would you use ${t}?`,
    (t: string) => `What does ${t} help you achieve?`,
  ];
  let idx = 0;
  for (const [term, purpose] of rows) {
    const distract = rng.shuffle(purposes.filter((p) => p !== purpose)).slice(0, 6);
    if (distract.length < 3) continue;
    const o = opts4(purpose, distract, rng, distract);
    out.push({
      id: `p_${prefix}_${idx}`,
      subject,
      topic,
      difficulty: "Medium",
      question: phrases[idx % phrases.length](term),
      options: o.options,
      correctIndex: o.correctIndex,
      explanation: `${term}: ${purpose}`,
      tags: [topic.toLowerCase(), "theory"],
    });
    idx++;
  }
  return out;
}

/* ================================================================== *
 * PYTHON theory
 * ================================================================== */
const PY_TRUE = [
  "Lists in Python are mutable and can be changed after creation.",
  "Tuples are immutable sequences.",
  "Dictionaries store data as key-value pairs.",
  "Sets automatically remove duplicate elements.",
  "Strings in Python are immutable.",
  "The 'is' operator checks object identity, not value equality.",
  "Python uses indentation to define code blocks.",
  "A function defined with 'def' can return multiple values as a tuple.",
  "The 'None' keyword represents the absence of a value.",
  "List comprehensions provide a concise way to create lists.",
  "The 'len()' function returns the number of items in a container.",
  "Python is dynamically typed, so variables don't need explicit type declarations.",
  "The 'range()' function returns a lazy iterable in Python 3.",
  "A generator produces values lazily using the 'yield' keyword.",
  "The '**' operator performs exponentiation.",
  "Dictionary keys must be immutable (hashable) objects.",
  "The 'in' operator checks for membership in a sequence.",
  "Python supports multiple inheritance.",
  "The 'self' parameter refers to the current instance in a method.",
  "'==' compares values while 'is' compares identity.",
  "A 'try/except' block is used to handle exceptions.",
  "The 'finally' block executes whether or not an exception occurs.",
  "Slicing a list returns a new list.",
  "The 'global' keyword lets a function modify a global variable.",
  "Everything in Python is an object.",
  "The '//' operator performs floor (integer) division.",
  "Default function arguments are evaluated once at definition time.",
  "A lambda is an anonymous, single-expression function.",
  "Modules are imported using the 'import' statement.",
  "'append()' adds a single element to the end of a list.",
];
const PY_FALSE = [
  "Tuples are mutable and can be modified after creation.",
  "Strings in Python can be changed in place.",
  "The '==' operator checks object identity in Python.",
  "Python requires you to declare variable types explicitly.",
  "Lists automatically remove duplicate elements.",
  "Dictionary keys can be mutable objects like lists.",
  "The 'is' operator compares values, not identity.",
  "Python uses curly braces {} to define code blocks.",
  "A set preserves the insertion order and allows duplicates.",
  "The '/' operator always returns an integer in Python 3.",
  "Indentation is optional and only for readability in Python.",
  "The 'yield' keyword immediately returns and ends the function.",
  "Python does not support multiple inheritance.",
  "'append()' can add multiple elements at once to a list.",
  "Functions in Python cannot return more than one value.",
  "The 'None' keyword is the same as the integer 0.",
  "Modules must be compiled before they can be imported.",
  "A lambda function can contain multiple statements and loops.",
  "The 'range()' function returns a list in Python 3.",
  "Variables declared inside a function are accessible globally by default.",
];

const PY_ERRORS = [
  ["for i in range(5)\n    print(i)", "Missing colon ':' after the for statement.", "The range function needs three arguments.", "print must use parentheses in Python 2 only.", "The loop variable i is undefined."],
  ["def add(a, b):\nreturn a + b", "The 'return' statement is not indented inside the function.", "Functions cannot be named 'add'.", "Missing semicolon after return.", "Parameters a and b must be typed."],
  ["x = [1, 2, 3]\nprint(x[3])", "IndexError: index 3 is out of range for a 3-element list.", "Lists cannot be printed directly.", "x must be declared with the list keyword.", "Indexing starts at 1, not 0."],
  ["d = {'a': 1}\nprint(d['b'])", "KeyError: the key 'b' does not exist in the dictionary.", "Dictionaries cannot store integers.", "You must use d.get() to print any key.", "Dictionary keys must be integers."],
  ["print('Hello)", "The string literal is missing a closing quote.", "print is not a valid function name.", "Strings must use double quotes only.", "Missing parentheses around the string."],
  ["nums = (1, 2, 3)\nnums[0] = 5", "TypeError: tuples are immutable and cannot be assigned to.", "Tuples must be created with square brackets.", "The index 0 is out of range.", "You cannot mix integers in a tuple."],
  ["def f():\n    print(y)\n    y = 10", "UnboundLocalError: y is used before assignment in the local scope.", "y must be declared as a string.", "Functions cannot contain print statements.", "The function is missing a return value."],
  ["if x = 5:\n    print(x)", "Assignment '=' used instead of comparison '=='.", "The if statement needs an else clause.", "x must be defined with 'var'.", "Colons are not allowed after if."],
  ["import maths", "ModuleNotFoundError: the module is 'math', not 'maths'.", "Imports must be at the end of the file.", "You must write 'include math'.", "Modules cannot be imported by name."],
  ["s = 'abc'\ns[0] = 'x'", "TypeError: strings are immutable and cannot be modified by index.", "Strings must be declared with double quotes.", "Index 0 does not exist in a string.", "You must use s.append() instead."],
];

/* ================================================================== *
 * JAVA theory
 * ================================================================== */
const JAVA_TRUE = [
  "Java is a statically typed language.",
  "Every Java application must have a 'main' method as its entry point.",
  "String objects are immutable in Java.",
  "The JVM executes Java bytecode.",
  "Java supports single inheritance for classes.",
  "A class can implement multiple interfaces.",
  "The 'final' keyword prevents a class from being subclassed.",
  "Java uses automatic garbage collection.",
  "Primitive types like int are not objects.",
  "The 'static' keyword makes a member belong to the class, not instances.",
  "Method overloading is resolved at compile time.",
  "Method overriding is resolved at run time.",
  "An abstract class cannot be instantiated directly.",
  "Interfaces can have default methods since Java 8.",
  "The '==' operator compares references for objects.",
  "The '.equals()' method compares object values (when overridden).",
  "Checked exceptions must be declared or handled.",
  "ArrayList allows duplicate elements.",
  "HashSet does not allow duplicate elements.",
  "The 'this' keyword refers to the current object.",
  "Java passes arguments by value.",
  "A constructor has the same name as its class and no return type.",
  "StringBuilder is mutable, unlike String.",
  "The 'super' keyword accesses the parent class members.",
  "Wrapper classes box primitives into objects.",
  "The 'try-with-resources' statement auto-closes resources.",
  "An interface cannot be instantiated on its own.",
  "The default value of an uninitialized int field is 0.",
  "Arrays in Java have a fixed length once created.",
  "The 'throws' keyword declares exceptions a method may throw.",
];
const JAVA_FALSE = [
  "Java is a dynamically typed language.",
  "String objects in Java are mutable.",
  "Java supports multiple inheritance of classes directly.",
  "The '==' operator always compares object values.",
  "A class in Java can extend multiple classes.",
  "Primitive types like int are objects in Java.",
  "The 'final' keyword makes a variable static.",
  "Java does not have garbage collection.",
  "Interfaces cannot contain any method bodies at all.",
  "Method overriding is resolved at compile time.",
  "Constructors can have a return type like void.",
  "ArrayList does not allow duplicate elements.",
  "HashSet allows storing duplicate elements.",
  "Java passes objects by reference (the reference itself is not copied).",
  "Arrays in Java can grow in size dynamically.",
  "The 'static' keyword makes a member unique to each instance.",
  "Checked exceptions can be ignored without declaring them.",
  "An abstract class can be instantiated with 'new'.",
  "StringBuilder is immutable like String.",
  "The main method must return an int value.",
];

const JAVA_ERRORS = [
  ["int x = 5\nSystem.out.println(x);", "Missing semicolon ';' after the variable declaration.", "System.out.println is spelled incorrectly.", "int cannot be assigned the value 5.", "x must be declared as String."],
  ["String s = 'hello';", "Single quotes create a char; String literals need double quotes.", "String must be lowercase 'string'.", "Missing semicolon at the end.", "Strings cannot be assigned directly."],
  ["public class A {\n  void run() {\n    return 5;\n  }\n}", "A void method cannot return a value.", "The class name must be lowercase.", "run() is a reserved keyword.", "Missing a main method causes this error."],
  ["int[] a = new int[3];\na[3] = 10;", "ArrayIndexOutOfBoundsException: valid indices are 0..2.", "Arrays must be created with braces only.", "The array size cannot be 3.", "a[3] must be a String."],
  ["if (x = 10) { }", "Cannot assign in a condition; use '==' for comparison.", "if requires an else branch.", "Braces are not allowed after if.", "x must be a boolean literal."],
  ["String s = null;\nint n = s.length();", "NullPointerException: calling a method on a null reference.", "length() is not a String method.", "s must be an int.", "Strings cannot be null in Java."],
  ["System.out.println(\"Hi\")", "Missing semicolon ';' at the end of the statement.", "println should be printline.", "Strings need single quotes.", "System must be lowercase."],
  ["public static void main(String args) { }", "The main method parameter must be String[] (an array).", "main cannot be static.", "main must return int.", "void is not allowed for main."],
  ["class A { A() { return; } A(int x){} }\nnew A(\"hi\");", "No constructor matches a String argument.", "Constructors cannot be overloaded.", "return is illegal in a constructor.", "Class A needs a main method."],
  ["List<int> nums = new ArrayList<>();", "Generics require wrapper types; use List<Integer>, not List<int>.", "ArrayList is not a valid class.", "List cannot be an interface.", "Missing import for int."],
];

/* ================================================================== *
 * C theory
 * ================================================================== */
const C_TRUE = [
  "In C, arrays are zero-indexed.",
  "A pointer stores the memory address of another variable.",
  "malloc() returns a void pointer to uninitialized memory.",
  "The '&' operator returns the address of a variable.",
  "The '*' operator dereferences a pointer.",
  "Strings in C are null-terminated character arrays.",
  "C is a statically typed, compiled language.",
  "The 'sizeof' operator returns the size of a type in bytes.",
  "free() releases dynamically allocated memory.",
  "Function arguments in C are passed by value by default.",
  "A 'struct' groups variables of different types together.",
  "The '#include' directive is handled by the preprocessor.",
  "An uninitialized local variable holds a garbage value.",
  "The 'const' qualifier makes a variable read-only.",
  "Array names decay to pointers when passed to functions.",
  "The '%' operator computes the remainder of integer division.",
  "A 'static' local variable retains its value between calls.",
  "The 'break' statement exits the nearest loop or switch.",
  "The 'continue' statement skips to the next loop iteration.",
  "calloc() initializes allocated memory to zero.",
  "A NULL pointer points to no valid memory location.",
  "The main() function is the program's entry point.",
  "Character constants are enclosed in single quotes.",
  "The '->' operator accesses a struct member via a pointer.",
  "Integer division in C truncates the fractional part.",
];
const C_FALSE = [
  "In C, arrays start at index 1.",
  "malloc() initializes allocated memory to zero.",
  "Strings in C are automatically resizable objects.",
  "C passes all arguments by reference by default.",
  "The '*' operator returns the address of a variable.",
  "The '&' operator dereferences a pointer.",
  "A 'struct' can only hold variables of the same type.",
  "The 'sizeof' operator returns the value stored in a variable.",
  "free() must be called on every stack variable.",
  "An uninitialized local variable is always zero.",
  "C is an interpreted language.",
  "The preprocessor runs after compilation.",
  "A 'static' local variable is destroyed after each call.",
  "calloc() leaves memory uninitialized.",
  "The '%' operator performs floating-point division.",
  "Character constants use double quotes.",
  "Array names cannot be passed to functions.",
  "The '->' operator is used on non-pointer structs.",
  "NULL pointers can be safely dereferenced.",
  "Integer division in C rounds to the nearest integer.",
];

const C_ERRORS = [
  ["int main() {\n  printf(\"Hi\");\n}", "Missing #include <stdio.h> for printf.", "main must return a string.", "printf needs three arguments.", "Braces are not allowed in main."],
  ["int a = 5\nprintf(\"%d\", a);", "Missing semicolon ';' after the declaration.", "%d cannot print an int.", "a must be a float.", "printf must come before the declaration."],
  ["int *p;\n*p = 10;", "Dereferencing an uninitialized (wild) pointer.", "Pointers cannot store integers.", "The '*' should be '&'.", "p must be declared as int, not int*."],
  ["char s[3] = \"abc\";", "No room for the null terminator; needs size 4.", "Strings must use single quotes.", "char arrays cannot be initialized.", "The size must be 2."],
  ["int arr[3];\narr[3] = 5;", "Out-of-bounds write: valid indices are 0..2.", "Arrays cannot be assigned to.", "The array size must be 0.", "arr must be a pointer."],
  ["scanf(\"%d\", x);", "scanf needs the address: use &x, not x.", "%d is invalid for scanf.", "scanf cannot read integers.", "x must be a pointer already."],
  ["for (i = 0; i < 5; i++);\n  sum += i;", "A stray semicolon ends the loop body prematurely.", "The loop needs a break statement.", "i must be declared as float.", "sum cannot be used in a loop."],
  ["int x = 10;\nif (x = 5) {}", "Assignment '=' used instead of comparison '=='.", "if cannot test integers.", "Missing else branch.", "x must be boolean."],
  ["char *s = \"hi\";\ns[0] = 'H';", "Modifying a string literal is undefined behavior.", "Strings cannot be indexed.", "s must be an int pointer.", "'H' is not a valid char."],
  ["int f() {\n  int x = 5;\n}", "The function is declared to return int but returns nothing.", "Local variables are not allowed.", "f must take arguments.", "Missing semicolon after the brace."],
];

/* ================================================================== *
 * C++ theory
 * ================================================================== */
const CPP_TRUE = [
  "C++ supports both procedural and object-oriented programming.",
  "A reference must be initialized when it is declared.",
  "C++ supports function and operator overloading.",
  "The 'new' operator allocates memory on the heap.",
  "The 'delete' operator frees memory allocated with 'new'.",
  "A virtual function enables runtime polymorphism.",
  "Templates enable generic programming with type parameters.",
  "std::vector is a dynamic array from the STL.",
  "A constructor initializes an object when it is created.",
  "A destructor is called when an object goes out of scope.",
  "C++ supports multiple inheritance.",
  "The 'this' pointer refers to the current object.",
  "std::unordered_map offers average O(1) lookup.",
  "A pure virtual function makes a class abstract.",
  "The 'const' keyword can make member functions read-only.",
  "Namespaces prevent naming conflicts.",
  "References cannot be reseated to refer to another object.",
  "RAII ties resource lifetime to object lifetime.",
  "std::map keeps its keys in sorted order.",
  "Smart pointers help manage dynamic memory automatically.",
  "Operator overloading lets user types use built-in operators.",
  "A copy constructor creates an object from an existing one.",
  "The 'nullptr' keyword represents a null pointer in modern C++.",
  "Inheritance models an 'is-a' relationship.",
  "STL algorithms operate through iterators.",
];
const CPP_FALSE = [
  "A reference in C++ can be left uninitialized.",
  "C++ does not support operator overloading.",
  "The 'delete' operator allocates memory.",
  "std::vector has a fixed size like a C array.",
  "C++ supports only single inheritance.",
  "A destructor takes arguments and can be overloaded.",
  "std::map stores its keys in random order.",
  "Templates are resolved at run time, not compile time.",
  "A pure virtual function provides a default body.",
  "References can be reseated to point to different objects.",
  "'new' allocates memory on the stack.",
  "std::unordered_map guarantees sorted iteration order.",
  "The 'this' pointer refers to the base class object.",
  "Constructors can be declared 'virtual' in standard C++.",
  "Smart pointers must be manually freed with delete.",
  "A class with a pure virtual function can be instantiated.",
  "Namespaces increase the program's runtime speed.",
  "Operator overloading changes operator precedence.",
  "A copy constructor deletes the original object.",
  "Inheritance in C++ models a 'has-a' relationship.",
];

const CPP_ERRORS = [
  ["int main() {\n  cout << \"Hi\";\n}", "Missing #include <iostream> and/or 'using namespace std'.", "cout needs parentheses.", "main must return a string.", "<< is not a valid operator."],
  ["int& r;", "A reference must be initialized when declared.", "References cannot be of type int.", "Missing semicolon.", "'&' should be '*'."],
  ["int *p = new int;\ndelete p;\n*p = 5;", "Use-after-free: writing to memory after delete.", "delete cannot be used on int pointers.", "new returns a reference, not a pointer.", "p must be initialized to NULL."],
  ["vector<int> v;\nv[0] = 10;", "Writing to index 0 of an empty vector is out of bounds.", "vector cannot store int.", "Missing template argument.", "v must be declared with new."],
  ["class A { virtual void f() = 0; };\nA a;", "Cannot instantiate an abstract class (pure virtual f).", "virtual functions are illegal.", "A needs a constructor.", "f cannot be void."],
  ["string s = 'hello';", "Single quotes are for char; use double quotes for strings.", "string must be capitalized.", "Missing #include <string> only.", "s must be a char array."],
  ["for (int i = 0; i < 5; i++)\ncout << i\ncout << endl;", "Missing semicolon after the first cout statement.", "endl is not valid.", "The loop needs braces always.", "i cannot be compared with <."],
  ["int arr[3] = {1,2,3};\ncout << arr[3];", "Out-of-bounds read: valid indices are 0..2.", "Arrays cannot be printed.", "arr must use new.", "The initializer has too few values."],
  ["void f(int x) {}\nf();", "f is called with no argument but requires one.", "void functions cannot take arguments.", "f must return a value.", "Missing semicolon after f()."],
  ["const int x = 5;\nx = 10;", "Cannot assign to a const variable.", "const must be used with pointers.", "x must be initialized later.", "10 is not an int."],
];

/* ================================================================== *
 * OOP theory
 * ================================================================== */
const OOP_TRUE = [
  "Encapsulation bundles data and methods while hiding internal state.",
  "Inheritance allows a class to reuse another class's members.",
  "Polymorphism lets one interface represent different underlying types.",
  "Abstraction hides complexity and exposes only essentials.",
  "A class is a blueprint; an object is an instance of it.",
  "Method overriding provides run-time polymorphism.",
  "Method overloading provides compile-time polymorphism.",
  "An abstract class may contain both abstract and concrete methods.",
  "An interface defines a contract without implementation (classically).",
  "Composition models a 'has-a' relationship.",
  "Inheritance models an 'is-a' relationship.",
  "A constructor initializes a new object.",
  "Private members are accessible only within their own class.",
  "Protected members are accessible in subclasses.",
  "Getters and setters support encapsulation.",
  "Dynamic binding resolves method calls at run time.",
  "An object has state (attributes) and behavior (methods).",
  "Aggregation is a weak 'has-a' where parts can exist independently.",
  "A subclass can override an inherited method.",
  "Static members belong to the class rather than instances.",
];
const OOP_FALSE = [
  "Encapsulation exposes all internal data publicly.",
  "Method overloading is resolved at run time.",
  "An interface provides full method implementations by default.",
  "A class is an instance of an object.",
  "Private members are accessible from any class.",
  "Inheritance models a 'has-a' relationship.",
  "Composition models an 'is-a' relationship.",
  "Abstract classes can always be instantiated directly.",
  "Polymorphism means every class must be final.",
  "Static members are unique to each object instance.",
  "Overriding changes a method's name and parameters.",
  "Constructors return a value like normal methods.",
  "Abstraction means exposing every implementation detail.",
  "A subclass cannot access any parent members.",
  "Encapsulation and inheritance are the same concept.",
  "Dynamic binding happens entirely at compile time.",
  "Getters modify private fields directly from outside.",
  "An object cannot have behavior, only state.",
  "Interfaces can be instantiated directly with 'new'.",
  "Protected members are accessible from unrelated classes.",
];

/* ================================================================== *
 * DBMS theory
 * ================================================================== */
const DBMS_TRUE = [
  "A primary key uniquely identifies each row and cannot be NULL.",
  "A foreign key references the primary key of another table.",
  "Normalization reduces data redundancy.",
  "The 'A' in ACID stands for Atomicity.",
  "A transaction is an all-or-nothing unit of work.",
  "An index speeds up data retrieval.",
  "3NF eliminates transitive dependencies.",
  "A view is a virtual table based on a query.",
  "Referential integrity is enforced by foreign keys.",
  "COMMIT permanently saves a transaction's changes.",
  "ROLLBACK undoes changes in the current transaction.",
  "A composite key consists of two or more columns.",
  "1NF requires atomic (indivisible) column values.",
  "DELETE can use a WHERE clause to remove specific rows.",
  "A candidate key is a minimal super key.",
  "Isolation controls visibility between concurrent transactions.",
  "Denormalization can improve read performance.",
  "A trigger runs automatically on a table event.",
  "BCNF requires every determinant to be a candidate key.",
  "An entity in an ER diagram is drawn as a rectangle.",
];
const DBMS_FALSE = [
  "A primary key can contain NULL values.",
  "A foreign key must always be the primary key of its own table.",
  "Normalization increases data redundancy.",
  "The 'D' in ACID stands for Distribution.",
  "TRUNCATE can use a WHERE clause to delete specific rows.",
  "An index always slows down queries.",
  "A view physically stores its own copy of the data.",
  "1NF allows multi-valued (non-atomic) attributes.",
  "COMMIT undoes the current transaction.",
  "3NF permits transitive dependencies.",
  "A transaction can be partially committed by default.",
  "Foreign keys prevent all data retrieval.",
  "A candidate key must include every column.",
  "Denormalization always reduces storage usage.",
  "Triggers must be invoked manually by the user.",
  "An attribute in an ER diagram is drawn as a rectangle.",
  "ROLLBACK permanently saves changes.",
  "Isolation has no effect on concurrent transactions.",
  "Every table must have a foreign key.",
  "Indexes remove duplicate rows automatically.",
];

/* ================================================================== *
 * OPERATING SYSTEMS theory
 * ================================================================== */
const OS_TRUE = [
  "A process is a program in execution with its own address space.",
  "Threads within a process share its code, data, and heap.",
  "Deadlock requires mutual exclusion, hold-and-wait, no-preemption, and circular wait.",
  "Round Robin scheduling uses a fixed time quantum.",
  "Paging eliminates external fragmentation.",
  "Virtual memory lets programs exceed physical RAM.",
  "A page fault occurs when a referenced page is not in memory.",
  "A semaphore is a synchronization primitive.",
  "Context switching saves and restores process state.",
  "The scheduler decides which process runs next.",
  "SJF can lead to starvation of long processes.",
  "A mutex allows only one thread in a critical section.",
  "The PCB stores information about a process.",
  "Thrashing is excessive paging that degrades performance.",
  "FCFS scheduling is non-preemptive.",
  "Each thread has its own stack and registers.",
  "Demand paging loads pages only when needed.",
  "Internal fragmentation is wasted space inside an allocation.",
  "A zombie process has finished but still has a table entry.",
  "The kernel manages hardware and system resources.",
];
const OS_FALSE = [
  "Threads of the same process each have a separate heap.",
  "Round Robin scheduling is non-preemptive.",
  "Paging causes external fragmentation.",
  "A page fault means the CPU has crashed.",
  "Virtual memory reduces the total addressable space.",
  "FCFS scheduling always minimizes waiting time.",
  "A process cannot contain more than one thread.",
  "Deadlock needs only two conditions to occur.",
  "The PCB stores only the program's source code.",
  "Context switching has zero overhead.",
  "A mutex allows unlimited threads in a critical section.",
  "SJF guarantees no process ever waits.",
  "Segmentation uses fixed-size blocks.",
  "The scheduler executes user programs directly without the CPU.",
  "Thrashing improves system throughput.",
  "Demand paging loads all pages at program start.",
  "Internal fragmentation is free memory between allocations.",
  "A zombie process is one that never started.",
  "The kernel runs entirely in user mode.",
  "Semaphores are used only for memory allocation.",
];

/* ================================================================== *
 * COMPUTER NETWORKS theory
 * ================================================================== */
const CN_TRUE = [
  "The OSI model has seven layers.",
  "TCP is a connection-oriented, reliable protocol.",
  "UDP is connectionless and does not guarantee delivery.",
  "IP operates at the network layer.",
  "DNS translates domain names into IP addresses.",
  "A router forwards packets between different networks.",
  "A switch forwards frames using MAC addresses.",
  "HTTPS uses TLS to encrypt traffic.",
  "The TCP three-way handshake is SYN, SYN-ACK, ACK.",
  "An IPv4 address is 32 bits long.",
  "An IPv6 address is 128 bits long.",
  "A firewall filters traffic based on rules.",
  "ARP resolves an IP address to a MAC address.",
  "The transport layer provides end-to-end communication.",
  "A MAC address is a hardware address.",
  "DHCP dynamically assigns IP addresses.",
  "Latency is the delay before data transfer begins.",
  "Bandwidth is the maximum data rate of a link.",
  "The application layer is the topmost OSI layer.",
  "NAT lets multiple devices share one public IP.",
];
const CN_FALSE = [
  "The OSI model has five layers.",
  "TCP is a connectionless protocol.",
  "UDP guarantees reliable, ordered delivery.",
  "IP operates at the application layer.",
  "DNS translates IP addresses into MAC addresses only.",
  "A hub forwards frames using IP addresses.",
  "An IPv4 address is 64 bits long.",
  "An IPv6 address is 32 bits long.",
  "HTTPS sends all data in plain text.",
  "A switch operates at the network layer using IP.",
  "The TCP handshake has only two steps.",
  "ARP resolves domain names to IP addresses.",
  "A firewall increases network bandwidth.",
  "Bandwidth and latency mean exactly the same thing.",
  "NAT assigns unique public IPs to every device.",
  "UDP is slower than TCP because of acknowledgments.",
  "The physical layer is the topmost OSI layer.",
  "DHCP encrypts all network traffic.",
  "A router operates only at the physical layer.",
  "MAC addresses change every time a packet is sent.",
];

/* ================================================================== *
 * DATA STRUCTURES theory
 * ================================================================== */
const DS_TRUE = [
  "A stack follows Last-In-First-Out (LIFO) order.",
  "A queue follows First-In-First-Out (FIFO) order.",
  "Binary search requires a sorted array.",
  "Array access by index is O(1).",
  "A linked list stores nodes connected by pointers.",
  "In-order traversal of a BST yields sorted order.",
  "A hash table offers average O(1) lookup.",
  "Merge sort has O(n log n) worst-case time.",
  "A heap is a complete binary tree.",
  "BFS uses a queue to explore level by level.",
  "DFS can be implemented using recursion or a stack.",
  "A doubly linked list has pointers to both neighbors.",
  "Inserting at the head of a linked list is O(1).",
  "A binary search tree keeps left < root < right.",
  "Quicksort has O(n^2) worst-case time.",
  "A priority queue serves elements by priority.",
  "A graph consists of vertices and edges.",
  "Hash collisions can be resolved by chaining.",
  "A min-heap keeps the smallest element at the root.",
  "Topological sort applies to a directed acyclic graph.",
];
const DS_FALSE = [
  "A stack follows First-In-First-Out order.",
  "A queue follows Last-In-First-Out order.",
  "Binary search works on any unsorted array.",
  "Array access by index is O(n).",
  "In-order traversal of a BST yields random order.",
  "A hash table always guarantees O(1) worst-case lookup.",
  "Merge sort has O(n^2) worst-case time.",
  "BFS uses a stack to explore depth first.",
  "Inserting at the head of a linked list is O(n).",
  "A max-heap keeps the smallest element at the root.",
  "A binary search tree keeps right < root < left.",
  "Quicksort always runs in O(log n) time.",
  "A graph cannot contain cycles.",
  "Topological sort applies to undirected cyclic graphs.",
  "Arrays can grow in size automatically in all languages.",
  "A linked list allows O(1) random access by index.",
  "A heap is always a full binary search tree.",
  "Hash collisions never occur with good hashing.",
  "DFS always finds the shortest path in an unweighted graph.",
  "A priority queue serves elements in insertion order only.",
];

/* ================================================================== *
 * SQL theory
 * ================================================================== */
const SQL_TRUE = [
  "SELECT retrieves rows from one or more tables.",
  "WHERE filters rows before grouping.",
  "HAVING filters groups after aggregation.",
  "GROUP BY groups rows for aggregate functions.",
  "ORDER BY sorts the result set.",
  "INNER JOIN returns only matching rows from both tables.",
  "LEFT JOIN returns all rows from the left table.",
  "DISTINCT removes duplicate rows from the result.",
  "COUNT(*) returns the number of rows.",
  "TRUNCATE removes all rows but keeps the table structure.",
  "A subquery is a query nested inside another query.",
  "COMMIT permanently saves a transaction.",
  "LIKE matches patterns using wildcards.",
  "BETWEEN tests whether a value is within an inclusive range.",
  "DROP removes an entire table and its data.",
  "UPDATE modifies existing rows.",
  "Aggregate functions operate on sets of rows.",
  "A LEFT JOIN can produce NULLs for unmatched right rows.",
  "GRANT gives privileges to a user.",
  "The IN operator checks membership in a list of values.",
];
const SQL_FALSE = [
  "WHERE can filter aggregated groups using COUNT().",
  "HAVING filters individual rows before grouping.",
  "INNER JOIN returns all rows from both tables regardless of match.",
  "DISTINCT sorts the result set in ascending order.",
  "TRUNCATE deletes the table structure along with the rows.",
  "COMMIT undoes all changes in a transaction.",
  "DROP only removes rows but keeps the table.",
  "ORDER BY groups rows for aggregation.",
  "A LEFT JOIN discards all left-table rows without a match.",
  "COUNT(*) returns the sum of a numeric column.",
  "LIKE matches values using arithmetic operators.",
  "GROUP BY sorts data and removes duplicates automatically.",
  "UPDATE creates a new table each time it runs.",
  "The IN operator checks for a numeric range only.",
  "GRANT removes privileges from a user.",
  "Subqueries cannot appear in a WHERE clause.",
  "BETWEEN is exclusive of both endpoints.",
  "SELECT can only read from a single table ever.",
  "Aggregate functions operate on one row at a time.",
  "ROLLBACK permanently commits the transaction.",
];

/* ================================================================== *
 * SOFTWARE ENGINEERING theory
 * ================================================================== */
const SE_TRUE = [
  "The Waterfall model is a linear, sequential process.",
  "Agile emphasizes iterative delivery and collaboration.",
  "A sprint is a time-boxed iteration in Scrum.",
  "Unit testing verifies individual components in isolation.",
  "The Product Owner prioritizes the product backlog.",
  "Version control tracks changes to source code.",
  "Black-box testing ignores internal code structure.",
  "White-box testing is based on internal code logic.",
  "Refactoring improves code without changing behavior.",
  "Continuous Integration frequently merges and tests code.",
  "The Single Responsibility Principle is part of SOLID.",
  "Regression testing checks that changes didn't break features.",
  "A user story describes a feature from the user's view.",
  "Coupling measures interdependence between modules.",
  "Cohesion measures how focused a module's tasks are.",
  "Integration testing checks combined modules.",
  "The Scrum Master facilitates the Scrum process.",
  "Functional requirements describe what the system should do.",
  "Technical debt is the cost of quick, suboptimal solutions.",
  "A burndown chart shows remaining work over time.",
];
const SE_FALSE = [
  "The Waterfall model allows easy iteration between all phases at any time.",
  "Agile requires complete documentation before any coding.",
  "Unit testing verifies the entire integrated system.",
  "The Scrum Master prioritizes the product backlog.",
  "White-box testing ignores internal code structure.",
  "Refactoring changes external behavior significantly.",
  "High coupling and high cohesion are both ideal.",
  "A sprint has no fixed time limit.",
  "Version control cannot handle multiple developers.",
  "Continuous Integration means deploying once per year.",
  "Functional requirements describe only performance and security.",
  "Regression testing writes new features from scratch.",
  "Coupling measures how focused a single module is.",
  "The Product Owner writes all the code.",
  "Black-box testing requires reading the source code.",
  "Technical debt improves long-term maintainability.",
  "A user story is a detailed database schema.",
  "Integration testing tests one function in isolation.",
  "Low cohesion is a sign of good design.",
  "Agile forbids any changes once a project starts.",
];

/* ================================================================== *
 * CYBERSECURITY theory
 * ================================================================== */
const CY_TRUE = [
  "The CIA triad stands for Confidentiality, Integrity, and Availability.",
  "Phishing tricks users into revealing sensitive information.",
  "Symmetric encryption uses the same key to encrypt and decrypt.",
  "Asymmetric encryption uses a public/private key pair.",
  "Hashing is a one-way function.",
  "A firewall filters traffic based on rules.",
  "SQL injection exploits unsanitized input in queries.",
  "XSS injects scripts that run in a victim's browser.",
  "Two-factor authentication uses two independent factors.",
  "A DDoS attack floods a service to make it unavailable.",
  "A zero-day is a vulnerability with no available patch.",
  "Ransomware encrypts data and demands payment.",
  "Salting adds random data before hashing a password.",
  "A VPN creates an encrypted tunnel over a public network.",
  "Least privilege grants only the minimum required access.",
  "A digital signature verifies authenticity and integrity.",
  "Social engineering manipulates people, not systems.",
  "TLS encrypts data in transit.",
  "An IDS detects suspicious activity and alerts.",
  "Defense in depth uses multiple layers of security.",
];
const CY_FALSE = [
  "The CIA triad stands for Control, Identity, and Access.",
  "Symmetric encryption uses a public/private key pair.",
  "Hashing is easily reversible to recover the input.",
  "Phishing is a type of hardware failure.",
  "A firewall speeds up the network by caching pages.",
  "XSS primarily targets database indexes.",
  "Two-factor authentication uses two passwords of the same type.",
  "A DDoS attack silently steals data without disruption.",
  "A zero-day vulnerability always has a ready patch.",
  "Ransomware improves system performance.",
  "Salting removes the need for hashing entirely.",
  "A VPN sends all traffic in plain text.",
  "Least privilege grants every user admin access.",
  "A digital signature encrypts the entire hard drive.",
  "Social engineering exploits only software bugs.",
  "TLS is used only for storing files at rest.",
  "An IPS only logs traffic and never blocks it.",
  "Asymmetric encryption uses a single shared key.",
  "Defense in depth relies on a single security control.",
  "Confidentiality means making all data public.",
];

/* ================================================================== *
 * WEB TECHNOLOGIES theory
 * ================================================================== */
const WEB_TRUE = [
  "HTML defines the structure of a web page.",
  "CSS is used to style web pages.",
  "JavaScript adds interactivity to web pages.",
  "HTTP GET is used to retrieve data.",
  "HTTP POST is used to submit data.",
  "The DOM is a tree representation of a page.",
  "JSON is a lightweight data-interchange format.",
  "'let' declares a block-scoped variable in JavaScript.",
  "HTTPS encrypts data using TLS.",
  "A cookie stores small data in the browser.",
  "localStorage persists data with no expiry.",
  "sessionStorage is cleared when the tab closes.",
  "REST uses HTTP methods to operate on resources.",
  "The <a> tag creates a hyperlink.",
  "A media query applies styles based on device features.",
  "The GET method is idempotent.",
  "A Promise represents a future asynchronous value.",
  "Flexbox is a one-dimensional CSS layout model.",
  "CORS controls cross-origin resource sharing.",
  "The viewport is the visible area of a web page.",
];
const WEB_FALSE = [
  "CSS defines the structure of a web page.",
  "HTML is used mainly to style pages with colors.",
  "HTTP GET is used to permanently delete resources.",
  "The DOM is a network protocol.",
  "JSON is a programming language for servers.",
  "'var' is block-scoped in JavaScript.",
  "HTTPS sends data in plain text.",
  "localStorage is automatically cleared on page reload.",
  "sessionStorage never expires and persists forever.",
  "REST requires SOAP envelopes for every request.",
  "The <img> tag creates a hyperlink.",
  "The POST method is always idempotent and safe.",
  "A Promise blocks the main thread until resolved.",
  "Flexbox is a two-dimensional grid system only.",
  "CORS speeds up JavaScript execution.",
  "JavaScript can only run on servers, not browsers.",
  "Cookies can store gigabytes of data by default.",
  "The DOM cannot be modified by JavaScript.",
  "HTML tags are case-sensitive and must be uppercase.",
  "CSS specificity has no effect on which rule applies.",
];

/* ================================================================== *
 * CLOUD COMPUTING theory
 * ================================================================== */
const CLOUD_TRUE = [
  "SaaS delivers ready-to-use software over the internet.",
  "IaaS provides virtualized compute and storage resources.",
  "PaaS provides a platform to build and deploy applications.",
  "Elasticity means scaling resources automatically with demand.",
  "A public cloud is operated by a third-party provider.",
  "A private cloud is dedicated to a single organization.",
  "A hybrid cloud combines public and private clouds.",
  "Kubernetes orchestrates containers.",
  "A container packages an app with its dependencies.",
  "Serverless computing bills for actual execution time.",
  "A load balancer distributes traffic across servers.",
  "A CDN caches content near users to reduce latency.",
  "Horizontal scaling adds more instances.",
  "Vertical scaling increases a single instance's resources.",
  "High availability minimizes downtime.",
  "The shared responsibility model splits security duties.",
  "A region is a geographic area of data centers.",
  "Auto scaling adjusts capacity based on load.",
  "A VM is emulated by a hypervisor.",
  "Pay-as-you-go bills only for resources used.",
];
const CLOUD_FALSE = [
  "SaaS requires customers to manage the underlying servers.",
  "IaaS delivers only finished end-user applications.",
  "Elasticity means resources never change size.",
  "A public cloud is dedicated to one company only.",
  "A hybrid cloud uses no public cloud at all.",
  "Kubernetes is a relational database engine.",
  "Serverless means there are literally no servers involved.",
  "A load balancer stores all application data permanently.",
  "A CDN increases latency by centralizing content.",
  "Horizontal scaling means upgrading a single machine's CPU.",
  "Vertical scaling adds more separate instances.",
  "High availability guarantees the system is always offline.",
  "In the shared responsibility model the provider secures everything.",
  "A region is a single physical server.",
  "Auto scaling requires manual intervention for every change.",
  "A hypervisor is a type of network cable.",
  "Pay-as-you-go charges a fixed fee regardless of usage.",
  "Containers are heavier than full virtual machines.",
  "PaaS gives you raw physical hardware to rack yourself.",
  "A private cloud cannot be customized by its owner.",
];

/* ================================================================== *
 * COMPUTER ARCHITECTURE theory
 * ================================================================== */
const ARCH_TRUE = [
  "The ALU performs arithmetic and logic operations.",
  "Registers are the fastest storage in the memory hierarchy.",
  "Cache bridges the speed gap between CPU and main memory.",
  "Pipelining increases instruction throughput.",
  "The instruction cycle is fetch, decode, execute.",
  "1 KB traditionally equals 1024 bytes.",
  "The control unit directs the operation of the processor.",
  "A cache hit means data was found in the cache.",
  "DMA lets devices transfer data without CPU involvement.",
  "RAM is volatile memory.",
  "The program counter holds the address of the next instruction.",
  "Binary uses base 2.",
  "Hexadecimal uses base 16.",
  "A bit is the smallest unit of data.",
  "Main memory is slower than cache memory.",
  "A 32-bit address bus can address 2^32 locations.",
  "The fetch stage retrieves an instruction from memory.",
  "Cache is smaller and faster than main memory.",
  "ROM retains its contents without power.",
  "Throughput measures work completed per unit time.",
];
const ARCH_FALSE = [
  "Registers are the slowest storage in the hierarchy.",
  "Cache is larger and slower than main memory.",
  "Pipelining decreases instruction throughput.",
  "1 KB traditionally equals 1000 bits.",
  "A cache hit means data was NOT found in the cache.",
  "RAM retains data permanently without power.",
  "The ALU stores the next instruction address.",
  "Binary uses base 10.",
  "Hexadecimal uses base 8.",
  "A byte is smaller than a bit.",
  "Cache memory is slower than main memory.",
  "DMA requires the CPU to copy every byte manually.",
  "The control unit performs all arithmetic.",
  "ROM loses its contents when powered off.",
  "The program counter stores arithmetic results.",
  "A 32-bit bus can address only 32 locations.",
  "Main memory is faster than CPU registers.",
  "Throughput measures the delay of a single instruction.",
  "The decode stage writes results back to memory.",
  "Volatile memory keeps data after shutdown.",
];

/* ================================================================== *
 * PURPOSE ROWS (term -> use) for extra "purpose" variety
 * ================================================================== */
const PY_PURPOSE = [
  ["a list comprehension", "to build a new list concisely from an iterable"],
  ["the 'with' statement", "to manage resources and auto-close them"],
  ["a decorator", "to wrap and extend a function's behavior"],
  ["the 'enumerate()' function", "to loop with both index and value"],
  ["the 'zip()' function", "to iterate over multiple sequences in parallel"],
  ["a generator", "to produce values lazily one at a time"],
  ["the 'map()' function", "to apply a function to every item of an iterable"],
  ["the 'filter()' function", "to keep items that satisfy a condition"],
];
const JAVA_PURPOSE = [
  ["the 'final' keyword", "to prevent modification, overriding, or inheritance"],
  ["an interface", "to define a contract of methods a class must implement"],
  ["the 'static' keyword", "to make a member belong to the class itself"],
  ["a try-with-resources block", "to automatically close resources"],
  ["generics", "to write type-safe reusable code"],
  ["the 'super' keyword", "to access parent-class members"],
  ["an ArrayList", "to store a resizable ordered collection"],
  ["a HashMap", "to store key-value pairs with fast lookup"],
];

/* ================================================================== *
 * Assemble theory questions per subject
 * ================================================================== */
export function buildTheory(subject: string): Q[] {
  switch (subject) {
    case "Python":
      return [
        ...stmtGen(subject, "py", 8001, "Concepts", PY_TRUE, PY_FALSE),
        ...errorGen(subject, "py", 8101, PY_ERRORS, "# Python"),
        ...purposeGen(subject, "py", 8201, "Concepts", PY_PURPOSE),
      ];
    case "Java":
      return [
        ...stmtGen(subject, "java", 8002, "Concepts", JAVA_TRUE, JAVA_FALSE),
        ...errorGen(subject, "java", 8102, JAVA_ERRORS, "// Java"),
        ...purposeGen(subject, "java", 8202, "Concepts", JAVA_PURPOSE),
      ];
    case "C Programming":
      return [
        ...stmtGen(subject, "c", 8003, "Concepts", C_TRUE, C_FALSE),
        ...errorGen(subject, "c", 8103, C_ERRORS, "// C"),
      ];
    case "C++":
      return [
        ...stmtGen(subject, "cpp", 8004, "Concepts", CPP_TRUE, CPP_FALSE),
        ...errorGen(subject, "cpp", 8104, CPP_ERRORS, "// C++"),
      ];
    case "OOP":
      return stmtGen(subject, "oop", 8005, "Concepts", OOP_TRUE, OOP_FALSE);
    case "DBMS":
      return stmtGen(subject, "dbms", 8006, "Concepts", DBMS_TRUE, DBMS_FALSE);
    case "Operating Systems":
      return stmtGen(subject, "os", 8007, "Concepts", OS_TRUE, OS_FALSE);
    case "Computer Networks":
      return stmtGen(subject, "cn", 8008, "Concepts", CN_TRUE, CN_FALSE);
    case "Data Structures & Algorithms":
      return stmtGen(subject, "ds", 8009, "Concepts", DS_TRUE, DS_FALSE);
    case "SQL":
      return stmtGen(subject, "sql", 8010, "Concepts", SQL_TRUE, SQL_FALSE);
    case "Software Engineering":
      return stmtGen(subject, "se", 8011, "Concepts", SE_TRUE, SE_FALSE);
    case "Cybersecurity Fundamentals":
      return stmtGen(subject, "cy", 8012, "Concepts", CY_TRUE, CY_FALSE);
    case "Web Technologies":
      return stmtGen(subject, "web", 8013, "Concepts", WEB_TRUE, WEB_FALSE);
    case "Cloud Computing":
      return stmtGen(subject, "cloud", 8014, "Concepts", CLOUD_TRUE, CLOUD_FALSE);
    case "Computer Architecture":
      return stmtGen(subject, "arch", 8015, "Concepts", ARCH_TRUE, ARCH_FALSE);
    default:
      return [];
  }
}

/* ================================================================== *
 * KNOWLEDGE EXPORT — true concept statements per subject. PRACTI uses
 * these as extra facts when answering free-form questions.
 * ================================================================== */
export interface FactStatement {
  subject: string;
  text: string;
}

export const TRUE_FACTS: FactStatement[] = [
  ...PY_TRUE.map((t) => ({ subject: "Python", text: t })),
  ...JAVA_TRUE.map((t) => ({ subject: "Java", text: t })),
  ...C_TRUE.map((t) => ({ subject: "C Programming", text: t })),
  ...CPP_TRUE.map((t) => ({ subject: "C++", text: t })),
  ...OOP_TRUE.map((t) => ({ subject: "OOP", text: t })),
  ...DBMS_TRUE.map((t) => ({ subject: "DBMS", text: t })),
  ...OS_TRUE.map((t) => ({ subject: "Operating Systems", text: t })),
  ...CN_TRUE.map((t) => ({ subject: "Computer Networks", text: t })),
  ...DS_TRUE.map((t) => ({ subject: "Data Structures & Algorithms", text: t })),
  ...SQL_TRUE.map((t) => ({ subject: "SQL", text: t })),
  ...SE_TRUE.map((t) => ({ subject: "Software Engineering", text: t })),
  ...CY_TRUE.map((t) => ({ subject: "Cybersecurity Fundamentals", text: t })),
  ...WEB_TRUE.map((t) => ({ subject: "Web Technologies", text: t })),
  ...CLOUD_TRUE.map((t) => ({ subject: "Cloud Computing", text: t })),
  ...ARCH_TRUE.map((t) => ({ subject: "Computer Architecture", text: t })),
];
