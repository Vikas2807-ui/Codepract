import type { MCQQuestion } from "./types";
import { MCQ_BANK } from "./mcqBank";
import { genAptitude, genArch, genPython, genCLike, genJava } from "./generators";
import {
  genCN, genOS, genDBMS, genSQL, genDS, genOOP, genSE, genCyber, genWeb, genCloud, genLangConcepts,
} from "./factData";
import { buildTheory } from "./theory";

/*
 * Central MCQ pool.
 *
 * Each subject's pool = curated hand-written questions + programmatically
 * generated questions (computed math/number-systems/code-output that are
 * correct by construction, plus verified fact-table questions). Generation is
 * deterministic (seeded), so every question has a STABLE id across sessions —
 * this is what lets the "already seen / no-repeat" tracking work reliably.
 */

// Remove exact-twin questions (same visible text + code + option set).
function dedupe(list: MCQQuestion[]): MCQQuestion[] {
  const seenId = new Set<string>();
  const seenSig = new Set<string>();
  const out: MCQQuestion[] = [];
  for (const q of list) {
    if (seenId.has(q.id)) continue;
    const sig = (q.question + "|" + (q.code || "") + "|" + [...q.options].sort().join("¦")).toLowerCase();
    if (seenSig.has(sig)) continue;
    seenId.add(q.id);
    seenSig.add(sig);
    out.push(q);
  }
  return out;
}

function curatedFor(subject: string): MCQQuestion[] {
  return MCQ_BANK.filter((q) => q.subject === subject);
}

// Build the map lazily once (module singleton).
let POOL: Record<string, MCQQuestion[]> | null = null;

function build(): Record<string, MCQQuestion[]> {
  const langConcepts = genLangConcepts();
  const conceptOf = (s: string) => langConcepts.find((x) => x.subject === s)?.qs ?? [];

  // `th(subject)` = the theory-concept questions (true/false statements,
  // error-identification, purpose) for that subject.
  const th = (s: string) => buildTheory(s);

  const map: Record<string, MCQQuestion[]> = {
    "Aptitude / Logical Problem Solving": dedupe([
      ...curatedFor("Aptitude / Logical Problem Solving"),
      ...genAptitude(620),
    ]),
    "Computer Architecture": dedupe([
      ...curatedFor("Computer Architecture"),
      ...th("Computer Architecture"),
      ...genArch(560),
    ]),
    Python: dedupe([
      ...curatedFor("Python"),
      ...conceptOf("Python"),
      ...th("Python"),
      ...genPython(470),
    ]),
    "C Programming": dedupe([
      ...curatedFor("C Programming"),
      ...conceptOf("C Programming"),
      ...th("C Programming"),
      ...genCLike("C Programming", "cout", 4004, 480, true),
    ]),
    "C++": dedupe([
      ...curatedFor("C++"),
      ...conceptOf("C++"),
      ...th("C++"),
      ...genCLike("C++", "cppout", 4040, 480, false),
    ]),
    Java: dedupe([
      ...curatedFor("Java"),
      ...conceptOf("Java"),
      ...th("Java"),
      ...genJava(430),
    ]),
    "Data Structures & Algorithms": dedupe([
      ...curatedFor("Data Structures & Algorithms"),
      ...th("Data Structures & Algorithms"),
      ...genDS(),
    ]),
    DBMS: dedupe([...curatedFor("DBMS"), ...th("DBMS"), ...genDBMS()]),
    SQL: dedupe([...curatedFor("SQL"), ...th("SQL"), ...genSQL()]),
    "Operating Systems": dedupe([...curatedFor("Operating Systems"), ...th("Operating Systems"), ...genOS()]),
    "Computer Networks": dedupe([...curatedFor("Computer Networks"), ...th("Computer Networks"), ...genCN()]),
    "Software Engineering": dedupe([...curatedFor("Software Engineering"), ...th("Software Engineering"), ...genSE()]),
    OOP: dedupe([...curatedFor("OOP"), ...th("OOP"), ...genOOP()]),
    "Cybersecurity Fundamentals": dedupe([...curatedFor("Cybersecurity Fundamentals"), ...th("Cybersecurity Fundamentals"), ...genCyber()]),
    "Web Technologies": dedupe([...curatedFor("Web Technologies"), ...th("Web Technologies"), ...genWeb()]),
    "Cloud Computing": dedupe([...curatedFor("Cloud Computing"), ...th("Cloud Computing"), ...genCloud()]),
  };
  return map;
}

export function getPoolMap(): Record<string, MCQQuestion[]> {
  if (!POOL) POOL = build();
  return POOL;
}

export function getSubjectPool(subject: string): MCQQuestion[] {
  const map = getPoolMap();
  if (subject === "All Subjects") {
    return dedupe(Object.values(map).flat());
  }
  return map[subject] ?? [];
}

export function subjectCount(subject: string): number {
  return getSubjectPool(subject).length;
}

// Debug helper: counts per subject.
export function allCounts(): Record<string, number> {
  const map = getPoolMap();
  const res: Record<string, number> = {};
  for (const [k, v] of Object.entries(map)) res[k] = v.length;
  res["All Subjects"] = getSubjectPool("All Subjects").length;
  return res;
}
