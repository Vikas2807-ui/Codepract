export type Difficulty = "Easy" | "Medium" | "Hard";

export interface MCQQuestion {
  id: string;
  subject: string;
  topic: string;
  difficulty: Difficulty;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  tags: string[];
  code?: string; // optional code block shown in monospace
}

export interface SampleTest {
  input: string;
  output: string;
  explanation?: string;
}

export interface CodingQuestion {
  id: string;
  language: string; // "Python" | "C" | "C++" | "Java" | "SQL"
  topic: string;
  difficulty: Difficulty;
  title: string;
  statement: string;
  inputFormat: string;
  outputFormat: string;
  constraints: string[];
  samples: SampleTest[];
  starterCode: string;
  totalTestCases: number; // visible + hidden
  timeComplexity: string;
  betterApproach: string;
  // keyword-based rubric used for heuristic evaluation
  requiredKeywords: string[];
  edgeKeywords: string[]; // keywords that indicate edge-case handling
}

export type TestMode = "coding" | "mcq";

export interface MCQAnswerState {
  selectedIndex: number | null;
  markedForReview: boolean;
}

export interface CodingAnswerState {
  code: string;
  submitted: boolean;
  passed: number;
  total: number;
  status: "Not Attempted" | "Correct" | "Partially Correct" | "Incorrect";
  feedback: string;
}

export interface TestConfig {
  mode: TestMode;
  language?: string; // coding
  subject: string; // "All Subjects" or a single subject (mcq)
  difficulty: Difficulty | "Mixed" | "Company Screening";
  count: number;
  timerMinutes: number; // 0 = untimed
  preset?: string;
  practice?: boolean;
}

export interface TopicPerf {
  topic: string;
  correct: number;
  total: number;
}

export interface TestResult {
  id: string;
  date: number;
  mode: TestMode;
  config: TestConfig;
  score: number; // out of count
  total: number;
  correct: number;
  incorrect: number;
  unattempted: number;
  accuracy: number;
  scoreOutOf10: number;
  topicPerf: TopicPerf[];
  difficultyPerf: { difficulty: string; correct: number; total: number }[];
  testCasesPassed?: number;
  testCasesTotal?: number;
  avgExecMs?: number;
}
