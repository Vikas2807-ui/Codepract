// Deterministic seeded PRNG (mulberry32). Given the same seed it always
// produces the same sequence — this keeps generated question IDs stable across
// sessions so the "already seen" tracking remains valid.
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class Rng {
  private next: () => number;
  constructor(seed: number) {
    this.next = mulberry32(seed);
  }
  // float in [0,1)
  f() {
    return this.next();
  }
  // int in [min, max] inclusive
  int(min: number, max: number) {
    return min + Math.floor(this.next() * (max - min + 1));
  }
  // pick one element
  pick<T>(arr: T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }
  // shuffle a copy
  shuffle<T>(arr: T[]): T[] {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(this.next() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }
  bool() {
    return this.next() < 0.5;
  }
}
