export const SUBJECTS: string[] = [
  "C Programming",
  "C++",
  "Java",
  "Python",
  "Data Structures & Algorithms",
  "DBMS",
  "Operating Systems",
  "Computer Networks",
  "Software Engineering",
  "Computer Architecture",
  "OOP",
  "SQL",
  "Cybersecurity Fundamentals",
  "Web Technologies",
  "Cloud Computing",
  "Aptitude / Logical Problem Solving",
];

export const CODING_LANGUAGES: { name: string; desc: string; icon: string; db?: boolean }[] = [
  { name: "Python", desc: "Clean syntax, great for algorithmic problem solving.", icon: "🐍" },
  { name: "C", desc: "Low-level control, pointers and memory concepts.", icon: "⚙️" },
  { name: "C++", desc: "Systems + STL powered competitive programming.", icon: "➕" },
  { name: "Java", desc: "Enterprise standard, strong OOP conventions.", icon: "☕" },
  { name: "JavaScript", desc: "The language of the web; async & functional style.", icon: "🟨" },
  { name: "TypeScript", desc: "Typed JavaScript for safer, scalable code.", icon: "🔷" },
  { name: "C#", desc: ".NET powerhouse with strong OOP and LINQ.", icon: "#️⃣" },
  { name: "Go", desc: "Simple, concurrent and fast — built for backends.", icon: "🐹" },
  { name: "Kotlin", desc: "Modern JVM language, first-class for Android.", icon: "🟣" },
  { name: "Ruby", desc: "Elegant, expressive and developer-friendly.", icon: "💎" },
  { name: "PHP", desc: "Widely used server-side scripting for the web.", icon: "🐘" },
  { name: "Swift", desc: "Apple's safe, fast language for iOS/macOS.", icon: "🦅" },
  { name: "Rust", desc: "Memory-safe systems programming without a GC.", icon: "🦀" },
  { name: "SQL", desc: "Database & query assessment (not a general language).", icon: "🗄️", db: true },
];

export const PRESETS: { name: string; desc: string; config: { mode: "coding" | "mcq"; count: number; difficulty: string; timer: number } }[] = [
  {
    name: "Fresher Coding Screening",
    desc: "10 coding problems, company-balanced difficulty, 60 min timer.",
    config: { mode: "coding", count: 10, difficulty: "Company Screening", timer: 60 },
  },
  {
    name: "Core CSE Assessment",
    desc: "50 MCQs across all core CS subjects, 45 min timer.",
    config: { mode: "mcq", count: 50, difficulty: "Company Screening", timer: 45 },
  },
  {
    name: "Software Developer Assessment",
    desc: "25 mixed-difficulty MCQs, 30 min — balanced core knowledge.",
    config: { mode: "mcq", count: 25, difficulty: "Mixed", timer: 30 },
  },
  {
    name: "Product Company Style",
    desc: "10 hard coding problems focusing on DS & problem solving.",
    config: { mode: "coding", count: 10, difficulty: "Hard", timer: 90 },
  },
  {
    name: "Service Company Style",
    desc: "50 easy-to-medium MCQs covering fundamentals, 45 min.",
    config: { mode: "mcq", count: 50, difficulty: "Mixed", timer: 45 },
  },
];

export const TIMER_OPTIONS = [
  { label: "Untimed", value: 0 },
  { label: "15 min", value: 15 },
  { label: "30 min", value: 30 },
  { label: "45 min", value: 45 },
  { label: "60 min", value: 60 },
  { label: "90 min", value: 90 },
];
