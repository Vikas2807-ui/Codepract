import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from "react";
import type { TestResult, TestConfig } from "../data/types";
import { loadResults, loadTheme, saveTheme } from "../lib/storage";
import type { PractiContext } from "../lib/practi";

export type View =
  | "home"
  | "setup"
  | "mcq-test"
  | "coding-test"
  | "result"
  | "review"
  | "dashboard"
  | "practice"
  | "interview";

interface AppState {
  view: View;
  navigate: (v: View) => void;
  theme: "light" | "dark";
  toggleTheme: () => void;
  results: TestResult[];
  refreshResults: () => void;
  // setup config carried between screens
  pendingConfig: Partial<TestConfig> | null;
  setPendingConfig: (c: Partial<TestConfig> | null) => void;
  // last result for the result/review screens
  lastResult: TestResult | null;
  setLastResult: (r: TestResult | null) => void;
  // review data (questions + answers)
  reviewData: unknown | null;
  setReviewData: (d: unknown | null) => void;
  // PRACTI assistant: what the user is currently looking at
  practiCtx: PractiContext;
  setPractiCtx: (c: PractiContext) => void;
}

const Ctx = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [view, setView] = useState<View>("home");
  const [theme, setTheme] = useState<"light" | "dark">(() => loadTheme());
  const [results, setResults] = useState<TestResult[]>(() => loadResults());
  const [pendingConfig, setPendingConfig] = useState<Partial<TestConfig> | null>(null);
  const [lastResult, setLastResult] = useState<TestResult | null>(null);
  const [reviewData, setReviewData] = useState<unknown | null>(null);
  const [practiCtx, setPractiCtx] = useState<PractiContext>({ kind: "none" });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") root.classList.add("dark");
    else root.classList.remove("dark");
    saveTheme(theme);
  }, [theme]);

  const navigate = useCallback((v: View) => {
    setView(v);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((t) => (t === "dark" ? "light" : "dark"));
  }, []);

  const refreshResults = useCallback(() => {
    setResults(loadResults());
  }, []);

  return (
    <Ctx.Provider
      value={{
        view,
        navigate,
        theme,
        toggleTheme,
        results,
        refreshResults,
        pendingConfig,
        setPendingConfig,
        lastResult,
        setLastResult,
        reviewData,
        setReviewData,
        practiCtx,
        setPractiCtx,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useApp() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
