import type { TestResult } from "../data/types";

const KEYS = {
  results: "csect_results",
  theme: "csect_theme",
  activeTest: "csect_active_test",
  solved: "csect_solved",
  seen: "csect_seen", // per-subject list of already-served question ids
};

export function loadResults(): TestResult[] {
  try {
    const raw = localStorage.getItem(KEYS.results);
    return raw ? (JSON.parse(raw) as TestResult[]) : [];
  } catch {
    return [];
  }
}

export function saveResult(result: TestResult): TestResult[] {
  const all = loadResults();
  all.unshift(result);
  try {
    localStorage.setItem(KEYS.results, JSON.stringify(all.slice(0, 100)));
  } catch {
    /* ignore quota errors */
  }
  return all;
}

export function clearResults() {
  try {
    localStorage.removeItem(KEYS.results);
  } catch {
    /* ignore */
  }
}

export function loadTheme(): "light" | "dark" {
  try {
    const t = localStorage.getItem(KEYS.theme);
    if (t === "light" || t === "dark") return t;
  } catch {
    /* ignore */
  }
  return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export function saveTheme(theme: "light" | "dark") {
  try {
    localStorage.setItem(KEYS.theme, theme);
  } catch {
    /* ignore */
  }
}

// Active test persistence (for refresh recovery / anti-accident)
export function saveActiveTest(state: unknown) {
  try {
    localStorage.setItem(KEYS.activeTest, JSON.stringify(state));
  } catch {
    /* ignore */
  }
}

export function loadActiveTest<T>(): T | null {
  try {
    const raw = localStorage.getItem(KEYS.activeTest);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

export function clearActiveTest() {
  try {
    localStorage.removeItem(KEYS.activeTest);
  } catch {
    /* ignore */
  }
}

// Track solved question ids
export function loadSolved(): Record<string, boolean> {
  try {
    const raw = localStorage.getItem(KEYS.solved);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function markSolved(id: string) {
  const s = loadSolved();
  s[id] = true;
  try {
    localStorage.setItem(KEYS.solved, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

/* ------------------------------------------------------------------ *
 * No-repeat tracking: remember which question ids a subject has already
 * served so future quizzes only draw fresh questions until the pool is
 * exhausted, then recycle.
 * ------------------------------------------------------------------ */

type SeenMap = Record<string, string[]>;

function loadSeenMap(): SeenMap {
  try {
    const raw = localStorage.getItem(KEYS.seen);
    return raw ? (JSON.parse(raw) as SeenMap) : {};
  } catch {
    return {};
  }
}

function saveSeenMap(map: SeenMap) {
  try {
    localStorage.setItem(KEYS.seen, JSON.stringify(map));
  } catch {
    /* ignore */
  }
}

export function getSeen(subject: string): Set<string> {
  const map = loadSeenMap();
  return new Set(map[subject] ?? []);
}

export function addSeen(subject: string, ids: string[]) {
  const map = loadSeenMap();
  const set = new Set(map[subject] ?? []);
  for (const id of ids) set.add(id);
  map[subject] = [...set];
  saveSeenMap(map);
}

export function resetSeen(subject: string) {
  const map = loadSeenMap();
  delete map[subject];
  saveSeenMap(map);
}

export function seenCount(subject: string): number {
  return (loadSeenMap()[subject] ?? []).length;
}
