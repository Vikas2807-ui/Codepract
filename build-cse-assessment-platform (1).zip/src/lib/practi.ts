import { GLOSSARY, type GlossaryEntry } from "../data/factData";
import { TRUE_FACTS } from "../data/theory";
import type { MCQQuestion, CodingQuestion } from "../data/types";

/* ------------------------------------------------------------------ *
 * PRACTI — a built-in, context-aware study assistant.
 *
 * NOTE: This app is a fully static site (no backend) and we must never
 * ship secret API keys in frontend code. So PRACTI is NOT a remote LLM —
 * it is a local knowledge assistant powered by the app's own large,
 * curated concept base (thousands of verified facts) plus awareness of
 * the exact question/code the user is currently working on. It can:
 *   • explain the current MCQ or coding problem
 *   • give a hint without revealing the answer
 *   • reveal and explain the correct answer
 *   • define terms / compare two concepts / discuss complexity
 *   • answer general CS concept questions from the glossary
 * ------------------------------------------------------------------ */

export type PractiContext =
  | { kind: "mcq"; question: MCQQuestion; selectedIndex: number | null; revealed?: boolean }
  | { kind: "coding"; question: CodingQuestion; code?: string }
  | { kind: "none"; area?: string };

export interface ChatMessage {
  id: string;
  role: "user" | "practi";
  text: string;
}

const STOP = new Set([
  "the", "a", "an", "is", "are", "of", "to", "in", "on", "for", "and", "or",
  "what", "which", "how", "why", "do", "does", "can", "you", "me", "my", "i",
  "this", "that", "it", "with", "about", "please", "explain", "tell", "give",
  "between", "difference", "define", "meaning", "mean", "vs", "versus", "whats",
  "whats", "help", "question", "answer", "hint", "code", "problem", "practi",
]);

function tokens(s: string): string[] {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9+#.\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 1 && !STOP.has(w));
}

function norm(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9+#]/g, "");
}

/* ---- glossary lookup ------------------------------------------------ */

// Find the glossary entry that best matches a term phrase.
function findTerm(query: string, subjectHint?: string): GlossaryEntry | null {
  const q = norm(query);
  if (!q) return null;
  let best: GlossaryEntry | null = null;
  let bestScore = 0;
  for (const e of GLOSSARY) {
    const t = norm(e.term);
    let score = 0;
    if (t === q) score = 100;
    else if (t.replace(/\(.*\)/g, "") === q) score = 95;
    else if (q.includes(t) || t.includes(q)) score = 60 + Math.min(t.length, q.length);
    else {
      // token overlap
      const et = new Set(tokens(e.term));
      const qt = tokens(query);
      const overlap = qt.filter((w) => et.has(w)).length;
      if (overlap > 0) score = 20 + overlap * 10;
    }
    if (subjectHint && e.subject === subjectHint) score += 8;
    if (score > bestScore) {
      bestScore = score;
      best = e;
    }
  }
  return bestScore >= 30 ? best : null;
}

// Broader free-text search across glossary + true-facts.
function searchKnowledge(query: string, subjectHint?: string, limit = 3): string[] {
  const qt = tokens(query);
  if (qt.length === 0) return [];
  const scored: { text: string; score: number }[] = [];

  for (const e of GLOSSARY) {
    const hay = tokens(e.term + " " + e.def);
    const set = new Set(hay);
    let score = qt.filter((w) => set.has(w)).length;
    // boost if term words appear
    const termWords = new Set(tokens(e.term));
    score += qt.filter((w) => termWords.has(w)).length * 2;
    if (subjectHint && e.subject === subjectHint) score += 1;
    if (score > 0) scored.push({ text: `**${e.term}** — ${e.def}`, score });
  }
  for (const f of TRUE_FACTS) {
    const set = new Set(tokens(f.text));
    const score = qt.filter((w) => set.has(w)).length;
    if (subjectHint && f.subject === subjectHint && score > 0) {
      scored.push({ text: f.text, score: score + 1 });
    } else if (score >= 2) {
      scored.push({ text: f.text, score });
    }
  }

  scored.sort((a, b) => b.score - a.score);
  // de-dup
  const seen = new Set<string>();
  const out: string[] = [];
  for (const s of scored) {
    const key = s.text.slice(0, 40);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(s.text);
    if (out.length >= limit) break;
  }
  return out;
}

/* ---- MCQ helpers --------------------------------------------------- */

function letter(i: number) {
  return String.fromCharCode(65 + i);
}

function mcqExplain(q: MCQQuestion): string {
  const correct = q.options[q.correctIndex];
  return `Here's the breakdown of this ${q.subject} question (topic: ${q.topic}):\n\n**Correct answer: ${letter(q.correctIndex)}. ${correct}**\n\n${q.explanation}`;
}

function mcqHint(q: MCQQuestion): string {
  // A hint derived from the explanation / topic without naming the option.
  const firstSentence = q.explanation.split(/(?<=\.)\s/)[0] || q.explanation;
  return `Hint for this ${q.topic} question: think about the core idea — ${firstSentence}\n\nRe-read the options carefully and eliminate the ones that contradict that. Ask me to "explain the answer" when you're ready.`;
}

/* ---- Coding helpers ------------------------------------------------ */

function codingExplain(q: CodingQuestion): string {
  return `**${q.title}** (${q.language}, ${q.difficulty})\n\n${q.statement}\n\n**Input:** ${q.inputFormat}\n**Output:** ${q.outputFormat}\n\nStart by reading the sample case, then plan your logic before coding. Ask me for a "hint" or the "approach" if you're stuck.`;
}

function codingHint(q: CodingQuestion): string {
  const sample = q.samples[0];
  const ex = sample ? `\n\nFor example, input \`${sample.input.replace(/\n/g, " / ")}\` should give \`${sample.output}\`.` : "";
  return `Hint: this is a **${q.topic}** problem. A clean solution runs in about **${q.timeComplexity}**.${ex}\n\nBreak it into steps: (1) read the input exactly as described, (2) process it, (3) print the output in the required format. Ask for the "approach" for a fuller strategy.`;
}

function codingApproach(q: CodingQuestion): string {
  return `Approach for **${q.title}**:\n\n${q.betterApproach}\n\n🎯 Target time complexity: **${q.timeComplexity}**. Remember to handle edge cases (empty input, negatives, duplicates, boundaries) — those are often the hidden test cases.`;
}

/* ---- intent detection + main answer -------------------------------- */

const GREET = ["hi", "hello", "hey", "yo", "hii", "hiya", "greetings"];

export function practiGreeting(ctx: PractiContext): string {
  if (ctx.kind === "mcq") {
    return `Hi! I'm **PRACTI**, your study buddy. 🤖\nYou're on a ${ctx.question.subject} question. I can:\n• "explain this question"\n• give a "hint"\n• "explain the answer"\n• define any concept (e.g., "what is a hash table?")\n\nWhat would you like?`;
  }
  if (ctx.kind === "coding") {
    return `Hi! I'm **PRACTI**. 🤖\nYou're solving **${ctx.question.title}** in ${ctx.question.language}. I can:\n• "explain the problem"\n• give a "hint" or the "approach"\n• discuss "time complexity"\n• define any concept\n\nHow can I help?`;
  }
  return `Hi! I'm **PRACTI**, your CSE study assistant. 🤖\nAsk me about any concept — "what is normalization?", "difference between TCP and UDP", "explain polymorphism", "time complexity of binary search", and more. During a quiz or coding problem I can also explain the exact question you're on.`;
}

export function askPracti(raw: string, ctx: PractiContext): string {
  const text = raw.trim();
  if (!text) return "Ask me anything about CS concepts, or your current question!";
  const low = text.toLowerCase();

  const subjectHint =
    ctx.kind === "mcq" ? ctx.question.subject : ctx.kind === "coding" ? ctx.question.language : undefined;

  // explicit greeting (exact match only, so "explain…" isn't caught)
  if (GREET.includes(low) || GREET.some((g) => low === g + "!" || low === g + ".")) {
    return practiGreeting(ctx);
  }
  // thanks — word-boundary so it doesn't match "ty" inside "complexity"
  if (/\b(thanks|thank you|thank u|thankyou|thx|ty|appreciate)\b/.test(low)) {
    return "You're welcome! 🙌 Keep going — ask me anything else whenever you get stuck.";
  }
  if (/who are you|what are you|your name|what can you do|^help\b|^help$/.test(low)) {
    return practiGreeting(ctx);
  }

  const wantsAnswer = /\b(answer|solution|correct option|which (one|option)|reveal)\b/.test(low);
  const wantsHint = /\bhint|clue|stuck|how (do|to) (i|start)|where (do|to) start\b/.test(low);
  const wantsExplainThis =
    /\b(this|current|the)\b.*\b(question|problem|mcq)\b/.test(low) ||
    /explain (this|it|the (question|problem))/.test(low) ||
    low === "explain" ||
    /explain the code|explain this code/.test(low);
  const wantsApproach = /\bapproach|strategy|how to solve|best way|optimal\b/.test(low);
  const wantsComplexity = /\b(time|space) complexity|big.?o|how fast|efficiency\b/.test(low);

  // ---- context-aware: MCQ ----
  if (ctx.kind === "mcq") {
    const q = ctx.question;
    if (wantsAnswer) return mcqExplain(q);
    if (wantsHint) return mcqHint(q);
    if (wantsExplainThis) {
      // If already answered/revealed, give full explanation, else a hint.
      if (ctx.revealed || ctx.selectedIndex !== null) return mcqExplain(q);
      return `This question is about **${q.topic}** (${q.subject}).\n\n${mcqHint(q)}`;
    }
  }

  // ---- context-aware: Coding ----
  if (ctx.kind === "coding") {
    const q = ctx.question;
    if (wantsComplexity) return `The target time complexity for **${q.title}** is **${q.timeComplexity}**.\n\n${q.betterApproach}`;
    if (wantsApproach) return codingApproach(q);
    if (wantsHint) return codingHint(q);
    if (wantsExplainThis || /problem|statement|what.*(do|asking|mean)/.test(low)) return codingExplain(q);
  }

  // ---- general time-complexity questions ("complexity of binary search") ----
  if (/\bcomplexity\b|big.?o\b|how fast is\b/.test(low)) {
    const term = low
      .replace(/.*complexity\s*(of|for)?\s*/i, "")
      .replace(/.*big.?o\s*(of|for)?\s*/i, "")
      .replace(/.*how fast is\s*/i, "")
      .replace(/[?.!]+$/, "")
      .trim();
    const qWords = tokens(term || low);
    let best: GlossaryEntry | null = null;
    let bestScore = 0;
    for (const e of GLOSSARY) {
      if (!/complexity|O\(/.test(e.def)) continue;
      const et = new Set(tokens(e.term));
      const overlap = qWords.filter((w) => et.has(w)).length;
      if (overlap > bestScore) {
        bestScore = overlap;
        best = e;
      }
    }
    if (best && bestScore > 0) {
      return `**${best.term}** — ${best.def}`;
    }
  }

  // ---- difference between X and Y ----
  const diff = low.match(/difference between (.+?) and (.+)/) || low.match(/(.+?)\s+vs\.?\s+(.+)/);
  if (diff) {
    const aEntry = findTerm(diff[1], subjectHint);
    const bEntry = findTerm(diff[2], subjectHint);
    if (aEntry && bEntry) {
      return `**${aEntry.term}** vs **${bEntry.term}**:\n\n• **${aEntry.term}** — ${aEntry.def}\n\n• **${bEntry.term}** — ${bEntry.def}`;
    }
    if (aEntry || bEntry) {
      const e = (aEntry || bEntry)!;
      return `Here's what I know:\n\n**${e.term}** — ${e.def}\n\nI couldn't find a solid match for the other term — try rephrasing it.`;
    }
  }

  // ---- define / what is X ----
  const defMatch =
    low.match(/(?:what(?:'s| is| are)|define|explain|meaning of|tell me about)\s+(?:a |an |the )?(.+)/) ||
    low.match(/^(.+?)\??$/);
  if (defMatch) {
    const term = defMatch[1].replace(/[?.!]+$/, "").trim();
    const entry = findTerm(term, subjectHint);
    if (entry) {
      const related = searchKnowledge(term, entry.subject, 2).filter(
        (r) => !r.toLowerCase().includes(entry.term.toLowerCase().slice(0, 8))
      );
      let msg = `**${entry.term}** (${entry.subject}) — ${entry.def}`;
      if (related.length) msg += `\n\nRelated:\n${related.map((r) => "• " + r).join("\n")}`;
      return msg;
    }
  }

  // ---- fallback: free-text knowledge search ----
  const hits = searchKnowledge(text, subjectHint, 3);
  if (hits.length) {
    return `Here's what I found:\n\n${hits.map((h) => "• " + h).join("\n\n")}\n\nWant more detail? Ask "what is <term>?" or, during a question, say "explain this question".`;
  }

  // ---- nothing matched ----
  const suggestions =
    ctx.kind === "mcq"
      ? `Try: "explain this question", "give me a hint", or "what is ${ctx.question.topic}?"`
      : ctx.kind === "coding"
      ? `Try: "explain the problem", "hint", "approach", or "time complexity".`
      : `Try: "what is a stack?", "difference between TCP and UDP", or "explain normalization".`;
  return `I'm not fully sure about that one. I'm strongest on core CSE concepts and your current question.\n\n${suggestions}`;
}
