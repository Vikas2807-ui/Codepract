import type {
  MCQQuestion,
  CodingQuestion,
  MCQAnswerState,
  CodingAnswerState,
  TestConfig,
  TestResult,
  TopicPerf,
} from "../data/types";

function buildTopicPerf(
  items: { topic: string; correct: boolean }[]
): TopicPerf[] {
  const map: Record<string, { correct: number; total: number }> = {};
  items.forEach((it) => {
    if (!map[it.topic]) map[it.topic] = { correct: 0, total: 0 };
    map[it.topic].total += 1;
    if (it.correct) map[it.topic].correct += 1;
  });
  return Object.entries(map).map(([topic, v]) => ({ topic, correct: v.correct, total: v.total }));
}

function buildDifficultyPerf(
  items: { difficulty: string; correct: boolean }[]
) {
  const order = ["Easy", "Medium", "Hard"];
  const map: Record<string, { correct: number; total: number }> = {};
  items.forEach((it) => {
    if (!map[it.difficulty]) map[it.difficulty] = { correct: 0, total: 0 };
    map[it.difficulty].total += 1;
    if (it.correct) map[it.difficulty].correct += 1;
  });
  return order
    .filter((d) => map[d])
    .map((d) => ({ difficulty: d, correct: map[d].correct, total: map[d].total }));
}

export function buildMCQResult(
  config: TestConfig,
  questions: MCQQuestion[],
  answers: MCQAnswerState[]
): TestResult {
  let correct = 0;
  let incorrect = 0;
  let unattempted = 0;

  const perItems = questions.map((q, i) => {
    const a = answers[i];
    const attempted = a && a.selectedIndex !== null;
    const isCorrect = attempted && a.selectedIndex === q.correctIndex;
    if (!attempted) unattempted += 1;
    else if (isCorrect) correct += 1;
    else incorrect += 1;
    return {
      topic: q.topic,
      difficulty: q.difficulty,
      // For unattempted, count as not correct in topic breakdown
      correct: !!isCorrect,
    };
  });

  const total = questions.length;
  const accuracy = total === 0 ? 0 : Math.round((correct / total) * 100);

  return {
    id: `r_${Date.now()}`,
    date: Date.now(),
    mode: "mcq",
    config,
    score: correct,
    total,
    correct,
    incorrect,
    unattempted,
    accuracy,
    scoreOutOf10: total === 0 ? 0 : Math.round((correct / total) * 100) / 10,
    topicPerf: buildTopicPerf(perItems),
    difficultyPerf: buildDifficultyPerf(perItems),
  };
}

export function buildCodingResult(
  config: TestConfig,
  questions: CodingQuestion[],
  answers: CodingAnswerState[],
  execTimes: number[]
): TestResult {
  let correct = 0;
  let incorrect = 0;
  let unattempted = 0;
  let tcPassed = 0;
  let tcTotal = 0;
  let fractionalScore = 0;

  const perItems = questions.map((q, i) => {
    const a = answers[i];
    tcTotal += q.totalTestCases;
    if (!a || a.status === "Not Attempted") {
      unattempted += 1;
      return { topic: q.topic, difficulty: q.difficulty, correct: false };
    }
    tcPassed += a.passed;
    fractionalScore += a.total > 0 ? a.passed / a.total : 0;
    if (a.status === "Correct") correct += 1;
    else incorrect += 1;
    return { topic: q.topic, difficulty: q.difficulty, correct: a.status === "Correct" };
  });

  const total = questions.length;
  const validTimes = execTimes.filter((t) => t > 0);
  const avgExec = validTimes.length
    ? Math.round(validTimes.reduce((s, t) => s + t, 0) / validTimes.length)
    : 0;

  const accuracy = total === 0 ? 0 : Math.round((correct / total) * 100);
  const scoreOutOf10 = total === 0 ? 0 : Math.round((fractionalScore / total) * 100) / 10;

  return {
    id: `r_${Date.now()}`,
    date: Date.now(),
    mode: "coding",
    config,
    score: correct,
    total,
    correct,
    incorrect,
    unattempted,
    accuracy,
    scoreOutOf10,
    topicPerf: buildTopicPerf(perItems),
    difficultyPerf: buildDifficultyPerf(perItems),
    testCasesPassed: tcPassed,
    testCasesTotal: tcTotal,
    avgExecMs: avgExec,
  };
}
