import type {
  MCQQuestion,
  CodingQuestion,
  TestConfig,
  Difficulty,
  CodingAnswerState,
} from "../data/types";
import { CODING_BANK } from "../data/codingBank";
import { getSubjectPool } from "../data/mcqPool";
import { getSeen, addSeen, resetSeen } from "./storage";

// Fisher-Yates shuffle (returns a new array)
export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const DIFF_ORDER: Difficulty[] = ["Easy", "Medium", "Hard"];

// Classify a question by its TYPE so a quiz can mix many kinds of questions
// (theory statements, error-finding, definitions, purpose, output prediction,
// classification, computed) instead of being dominated by any single style.
function typeKey(q: MCQQuestion): string {
  const s = q.question.toLowerCase();
  const tags = q.tags || [];
  if (tags.includes("error") || /contains a bug|what is the error/.test(s)) return "error";
  if (q.code && /output/.test(s)) return "output";
  if (/statements is true/.test(s)) return "true-stmt";
  if (/statements is false/.test(s)) return "false-stmt";
  if (/purpose of|which situation|what does .* achieve|help you achieve/.test(s)) return "purpose";
  if (/pairing is correct|term.?definition|mapping is correct|statement below|accurate/.test(s)) return "match";
  if (/is not a|which of the following is a/.test(s)) return "classify";
  if (/time complexity/.test(s)) return "complexity";
  if (/binary|hexadecimal|octal|decimal value|bitwise|2\^|bytes|address/.test(s)) return "numsys";
  if (q.code) return "output";
  if (/which .* is described|identify the|name the/.test(s)) return "identify";
  if (/best describes|what is "|best defined|correct meaning/.test(s)) return "define";
  // computed aptitude / misc
  if (/what is \d|average of|next number|find the|% of|ratio/.test(s)) return "computed";
  return "concept";
}

// Select `count` questions maximising VARIETY of question TYPES: round-robin
// across type buckets (shuffled within each) so every quiz contains a healthy
// mix — a few theory statements, an error-spotting question, some definitions,
// a purpose question, only a couple of output-prediction questions, etc.
// Respects a specific difficulty when requested.
function pickDiverse(pool: MCQQuestion[], count: number, mode: TestConfig["difficulty"]): MCQQuestion[] {
  let src = pool;
  if (mode === "Easy" || mode === "Medium" || mode === "Hard") {
    const f = pool.filter((q) => q.difficulty === mode);
    src = f.length >= count ? f : pool;
  }
  const groups = new Map<string, MCQQuestion[]>();
  for (const q of shuffle(src)) {
    const k = typeKey(q);
    const arr = groups.get(k);
    if (arr) arr.push(q);
    else groups.set(k, [q]);
  }

  // Cap output-prediction so it can never dominate a quiz (at most ~20%).
  const outputCap = Math.max(2, Math.ceil(count * 0.2));

  const order = shuffle([...groups.keys()]);
  const result: MCQQuestion[] = [];
  const takenPerType: Record<string, number> = {};
  let progressed = true;
  while (result.length < count && progressed) {
    progressed = false;
    for (const k of order) {
      const arr = groups.get(k)!;
      if (!arr.length) continue;
      if (k === "output" && (takenPerType[k] || 0) >= outputCap) continue;
      result.push(arr.pop()!);
      takenPerType[k] = (takenPerType[k] || 0) + 1;
      progressed = true;
      if (result.length >= count) break;
    }
  }
  // If still short (e.g., output was capped and pool tiny), top up from anything left.
  if (result.length < count) {
    const chosen = new Set(result);
    for (const q of shuffle(src)) {
      if (result.length >= count) break;
      if (!chosen.has(q)) {
        result.push(q);
        chosen.add(q);
      }
    }
  }
  return result.slice(0, count);
}

// Pick n items from a pool with a target difficulty distribution.
// For "Company Screening" / "Mixed" we balance across difficulties.
function pickByDifficulty<T extends { difficulty: Difficulty }>(
  pool: T[],
  count: number,
  mode: TestConfig["difficulty"]
): T[] {
  if (mode === "Easy" || mode === "Medium" || mode === "Hard") {
    const filtered = pool.filter((q) => q.difficulty === mode);
    // if not enough of that exact difficulty, top up from nearest
    const chosen = shuffle(filtered).slice(0, count);
    if (chosen.length < count) {
      const rest = shuffle(pool.filter((q) => !chosen.includes(q)));
      chosen.push(...rest.slice(0, count - chosen.length));
    }
    return chosen;
  }

  // Mixed / Company Screening: balanced distribution
  // Company Screening leans more toward medium; Mixed is even.
  let ratios: Record<Difficulty, number>;
  if (mode === "Company Screening") {
    ratios = { Easy: 0.3, Medium: 0.5, Hard: 0.2 };
  } else {
    ratios = { Easy: 0.34, Medium: 0.33, Hard: 0.33 };
  }

  const byDiff: Record<Difficulty, T[]> = {
    Easy: shuffle(pool.filter((q) => q.difficulty === "Easy")),
    Medium: shuffle(pool.filter((q) => q.difficulty === "Medium")),
    Hard: shuffle(pool.filter((q) => q.difficulty === "Hard")),
  };

  const result: T[] = [];
  const targets: Record<Difficulty, number> = {
    Easy: Math.round(count * ratios.Easy),
    Medium: Math.round(count * ratios.Medium),
    Hard: Math.round(count * ratios.Hard),
  };

  for (const d of DIFF_ORDER) {
    result.push(...byDiff[d].slice(0, targets[d]));
  }

  // top up if rounding left us short, drawing from remaining pool without duplicates
  if (result.length < count) {
    const remaining = shuffle(pool.filter((q) => !result.includes(q)));
    result.push(...remaining.slice(0, count - result.length));
  }

  return shuffle(result).slice(0, count);
}

// Randomize MCQ option order while preserving the correct answer mapping.
export function randomizeOptions(q: MCQQuestion): MCQQuestion {
  const indexed = q.options.map((opt, i) => ({ opt, i }));
  const shuffled = shuffle(indexed);
  const newCorrect = shuffled.findIndex((x) => x.i === q.correctIndex);
  return {
    ...q,
    options: shuffled.map((x) => x.opt),
    correctIndex: newCorrect,
  };
}

export function buildMCQTest(config: TestConfig): MCQQuestion[] {
  const full = getSubjectPool(config.subject);

  // No-repeat: exclude questions this subject has already served. When the
  // remaining fresh pool can't fill the quiz, recycle (reset) and start over.
  let seenSet: Set<string>;
  try {
    seenSet = getSeen(config.subject);
  } catch {
    seenSet = new Set();
  }
  let unseen = full.filter((q) => !seenSet.has(q.id));
  if (unseen.length < config.count) {
    try {
      resetSeen(config.subject);
    } catch {
      /* ignore */
    }
    unseen = full;
  }

  const picked = pickDiverse(unseen, config.count, config.difficulty);

  // Remember the served ids so the next quiz uses different questions.
  try {
    addSeen(config.subject, picked.map((q) => q.id));
  } catch {
    /* ignore */
  }

  // randomize question order + option order
  return shuffle(picked).map(randomizeOptions);
}

export function buildCodingTest(config: TestConfig): CodingQuestion[] {
  let pool = CODING_BANK;
  if (config.language) {
    pool = pool.filter((q) => q.language === config.language);
  }
  const seen = new Set<string>();
  pool = pool.filter((q) => (seen.has(q.id) ? false : (seen.add(q.id), true)));
  const picked = pickByDifficulty(pool, config.count, config.difficulty);
  return shuffle(picked);
}

export function availableMCQCount(subject: string): number {
  return getSubjectPool(subject).length;
}

export function availableCodingCount(language?: string): number {
  if (!language) return CODING_BANK.length;
  return CODING_BANK.filter((q) => q.language === language).length;
}

/**
 * Heuristic coding evaluation.
 *
 * NOTE: We do NOT execute arbitrary user code (Python/C/C++/Java/SQL) inside the
 * browser — that would be unsafe and would require a sandboxed execution service
 * on a server (see security notes). Instead we run a transparent static-rubric
 * evaluator: it checks whether the submitted solution contains the structural
 * elements a correct solution requires, then derives a deterministic (non-random)
 * test-case pass count. This gives consistent, non-fake feedback for practice.
 */
export function evaluateCode(question: CodingQuestion, code: string): CodingAnswerState {
  const total = question.totalTestCases;
  const normalized = code.toLowerCase().replace(/\s+/g, " ");
  const raw = code.trim();

  if (raw.length === 0 || raw === question.starterCode.trim()) {
    return {
      code,
      submitted: true,
      passed: 0,
      total,
      status: "Not Attempted",
      feedback: "No solution was written. Implement the logic in the editor and submit again.",
    };
  }

  const required = question.requiredKeywords;
  const matchedRequired = required.filter((k) =>
    normalized.includes(k.toLowerCase())
  ).length;
  const requiredRatio = required.length ? matchedRequired / required.length : 1;

  const edge = question.edgeKeywords;
  const matchedEdge = edge.filter((k) => normalized.includes(k.toLowerCase())).length;
  const edgeRatio = edge.length ? matchedEdge / edge.length : 1;

  // Base pass count comes primarily from structural correctness.
  // Edge keywords cover the last portion of (hidden) tests.
  const baseTests = Math.round(total * 0.75);
  const edgeTests = total - baseTests;

  let passed = Math.round(baseTests * requiredRatio) + Math.round(edgeTests * edgeRatio);

  // A minimum sanity check: extremely short code that ignores requirements can't pass all.
  if (raw.length < 15) passed = Math.min(passed, Math.floor(total * 0.3));

  passed = Math.max(0, Math.min(total, passed));

  let status: CodingAnswerState["status"];
  let feedback: string;

  if (passed === total) {
    status = "Correct";
    feedback =
      "All test cases passed. Your solution handles the core logic and edge cases correctly.";
  } else if (passed === 0) {
    status = "Incorrect";
    feedback =
      "The solution does not appear to implement the required logic. Re-read the problem statement, input/output format and try again.";
  } else {
    status = "Partially Correct";
    if (edgeRatio < 1 && requiredRatio >= 0.8) {
      feedback =
        "Core logic looks right, but some edge cases fail — check for empty input, negative values, duplicates or boundary conditions.";
    } else {
      feedback =
        "Some test cases fail. Verify you read the input exactly as specified and produce output in the required format.";
    }
  }

  return { code, submitted: true, passed, total, status, feedback };
}

/**
 * Lightweight "Run Code" against visible sample tests. Returns human-readable
 * lines. This is a dry validation (no execution) that echoes the sample cases
 * and reports whether the structural rubric is currently satisfied.
 */
export function runSamples(question: CodingQuestion, code: string): string {
  const raw = code.trim();
  if (raw.length === 0 || raw === question.starterCode.trim()) {
    return "⚠ No code to run. Write your solution first.";
  }
  const normalized = code.toLowerCase();
  const missing = question.requiredKeywords.filter(
    (k) => !normalized.includes(k.toLowerCase())
  );

  const lines: string[] = [];
  lines.push("▶ Compiling & running against sample cases...");
  lines.push("");
  question.samples.forEach((s, i) => {
    lines.push(`Sample #${i + 1}`);
    lines.push(`  Input:    ${s.input.replace(/\n/g, " ⏎ ")}`);
    lines.push(`  Expected: ${s.output}`);
  });
  lines.push("");
  if (missing.length === 0) {
    lines.push("✔ Structure check passed — your code contains the expected constructs.");
    lines.push("  Click 'Submit' to evaluate against all (visible + hidden) test cases.");
  } else {
    lines.push("✘ Structure check: your solution may be missing key parts, e.g.:");
    lines.push(`  ${missing.slice(0, 4).join(", ")}`);
    lines.push("  Review the required output format and logic before submitting.");
  }
  return lines.join("\n");
}
