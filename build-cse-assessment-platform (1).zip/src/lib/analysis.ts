import type { TestResult, TopicPerf } from "../data/types";

export interface AnalysisReport {
  strengths: string[];
  improvements: string[];
  recommendations: string[];
  performanceBands: { label: string; band: "Strong" | "Good" | "Needs Practice" | "Needs Improvement" }[];
}

function band(pct: number): "Strong" | "Good" | "Needs Practice" | "Needs Improvement" {
  if (pct >= 85) return "Strong";
  if (pct >= 65) return "Good";
  if (pct >= 45) return "Needs Practice";
  return "Needs Improvement";
}

function pctOf(tp: TopicPerf): number {
  return tp.total === 0 ? 0 : Math.round((tp.correct / tp.total) * 100);
}

// Generates analysis strictly from the actual result data (no generic filler).
export function analyzeResult(result: TestResult): AnalysisReport {
  const topics = result.topicPerf
    .filter((t) => t.total > 0)
    .map((t) => ({ ...t, pct: pctOf(t) }))
    .sort((a, b) => b.pct - a.pct);

  const strengths: string[] = [];
  const improvements: string[] = [];
  const recommendations: string[] = [];

  const strong = topics.filter((t) => t.pct >= 75);
  const weak = topics.filter((t) => t.pct < 50);
  const middling = topics.filter((t) => t.pct >= 50 && t.pct < 75);

  strong.slice(0, 4).forEach((t) =>
    strengths.push(`Strong grasp of ${t.topic} (${t.pct}% — ${t.correct}/${t.total} correct)`)
  );
  if (strengths.length === 0 && topics.length > 0) {
    const best = topics[0];
    strengths.push(
      `Best performing area: ${best.topic} (${best.pct}%). Build on this while addressing weaker topics.`
    );
  }

  weak.slice(0, 5).forEach((t) =>
    improvements.push(`${t.topic} — only ${t.pct}% (${t.correct}/${t.total}). Needs focused revision.`)
  );
  middling.slice(0, 2).forEach((t) =>
    improvements.push(`${t.topic} is inconsistent (${t.pct}%). A little more practice will solidify it.`)
  );
  if (improvements.length === 0 && topics.length > 0) {
    improvements.push("No major weak areas detected — push toward harder problems to keep improving.");
  }

  // Recommendations based on weak topics + overall difficulty performance
  weak.slice(0, 4).forEach((t) => {
    recommendations.push(`Practice 8–10 ${t.topic} questions at increasing difficulty.`);
  });

  const hardPerf = result.difficultyPerf.find((d) => d.difficulty === "Hard");
  if (hardPerf && hardPerf.total > 0) {
    const hp = Math.round((hardPerf.correct / hardPerf.total) * 100);
    if (hp < 50) {
      recommendations.push("Attempt more Hard-level problems — your accuracy drops on difficult questions.");
    }
  }
  const easyPerf = result.difficultyPerf.find((d) => d.difficulty === "Easy");
  if (easyPerf && easyPerf.total > 0) {
    const ep = Math.round((easyPerf.correct / easyPerf.total) * 100);
    if (ep < 80) {
      recommendations.push("Revisit fundamentals — some Easy questions were missed, which hiring tests weigh heavily.");
    }
  }

  if (result.accuracy < 60) {
    recommendations.push("Take another balanced (Company Screening) test to track improvement over time.");
  }
  if (recommendations.length === 0) {
    recommendations.push("Excellent run! Try a Hard-difficulty test or the Product Company preset next.");
  }

  // Performance bands (grouped high-level categories)
  const performanceBands: AnalysisReport["performanceBands"] = [];
  const overall = result.accuracy;
  if (result.mode === "coding") {
    const tcPct =
      result.testCasesTotal && result.testCasesTotal > 0
        ? Math.round((result.testCasesPassed! / result.testCasesTotal) * 100)
        : overall;
    performanceBands.push({ label: "Coding", band: band(overall) });
    performanceBands.push({ label: "Problem Solving", band: band(tcPct) });
    const dsTopics = topics.filter((t) =>
      /array|string|hash|search|sort|recursion|link|stack|queue|tree|graph/i.test(t.topic)
    );
    const dsPct = dsTopics.length
      ? Math.round(dsTopics.reduce((s, t) => s + t.pct, 0) / dsTopics.length)
      : overall;
    performanceBands.push({ label: "Data Structures", band: band(dsPct) });
    const edgePct = result.testCasesTotal
      ? Math.round((result.testCasesPassed! / result.testCasesTotal) * 100)
      : overall;
    performanceBands.push({ label: "Edge Case Handling", band: band(Math.max(0, edgePct - 10)) });
  } else {
    performanceBands.push({ label: "Core CS Knowledge", band: band(overall) });
    const mediumPerf = result.difficultyPerf.find((d) => d.difficulty === "Medium");
    const mp = mediumPerf && mediumPerf.total ? Math.round((mediumPerf.correct / mediumPerf.total) * 100) : overall;
    performanceBands.push({ label: "Applied Reasoning", band: band(mp) });
    const conceptPct = strong.length >= topics.length / 2 ? overall + 5 : overall - 5;
    performanceBands.push({ label: "Concept Retention", band: band(Math.max(0, Math.min(100, conceptPct))) });
  }

  return { strengths, improvements, recommendations, performanceBands };
}

// Aggregate weak topics across all past results (for "Practice Weak Areas")
export function computeWeakTopics(results: TestResult[]): { topic: string; pct: number }[] {
  const agg: Record<string, { correct: number; total: number }> = {};
  results.forEach((r) => {
    r.topicPerf.forEach((t) => {
      if (!agg[t.topic]) agg[t.topic] = { correct: 0, total: 0 };
      agg[t.topic].correct += t.correct;
      agg[t.topic].total += t.total;
    });
  });
  return Object.entries(agg)
    .filter(([, v]) => v.total > 0)
    .map(([topic, v]) => ({ topic, pct: Math.round((v.correct / v.total) * 100) }))
    .sort((a, b) => a.pct - b.pct);
}
