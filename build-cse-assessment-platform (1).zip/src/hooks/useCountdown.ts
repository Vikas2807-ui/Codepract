import { useEffect, useRef, useState, useCallback } from "react";

interface Options {
  initialSeconds: number; // 0 = untimed
  onExpire: () => void;
  onWarning?: (secondsLeft: number) => void;
  active: boolean;
}

const WARNINGS = [600, 300, 60]; // 10 min, 5 min, 1 min

export function useCountdown({ initialSeconds, onExpire, onWarning, active }: Options) {
  const [secondsLeft, setSecondsLeft] = useState(initialSeconds);
  const firedWarnings = useRef<Set<number>>(new Set());
  const expired = useRef(false);
  const onExpireRef = useRef(onExpire);
  const onWarningRef = useRef(onWarning);
  onExpireRef.current = onExpire;
  onWarningRef.current = onWarning;

  const setRemaining = useCallback((s: number) => setSecondsLeft(s), []);

  // Sync when the initial time becomes known (test built or restored)
  useEffect(() => {
    setSecondsLeft(initialSeconds);
    expired.current = false;
    firedWarnings.current = new Set();
  }, [initialSeconds]);

  useEffect(() => {
    if (!active || initialSeconds === 0) return;
    const id = setInterval(() => {
      setSecondsLeft((prev) => {
        const next = prev - 1;
        if (next <= 0) {
          if (!expired.current) {
            expired.current = true;
            onExpireRef.current();
          }
          clearInterval(id);
          return 0;
        }
        if (WARNINGS.includes(next) && !firedWarnings.current.has(next)) {
          firedWarnings.current.add(next);
          onWarningRef.current?.(next);
        }
        return next;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [active, initialSeconds]);

  return { secondsLeft, setRemaining };
}

export function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  const h = Math.floor(m / 60);
  const mm = m % 60;
  if (h > 0) return `${h}:${String(mm).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
